/**
 * Scannability test — rasterizes every style, shape, eye, logo and frame variant and decodes
 * it with ZXing (plus an inversion pass) and camera-softened jsQR.
 * Run:  npx esbuild scripts/scan-test.ts --bundle --platform=node --format=cjs --outfile=scripts/.scan-test.cjs \
 *         --external:@resvg/resvg-js --external:jsqr --external:qrcode --external:@zxing/library && node scripts/.scan-test.cjs
 */
import { Resvg } from '@resvg/resvg-js';
import jsQR from 'jsqr';
import { BinaryBitmap, HybridBinarizer, QRCodeReader, RGBLuminanceSource, DecodeHintType } from '@zxing/library';
import { createMatrix, effectiveEc, renderSvg, softenRgba, QUIET_ZONE } from '../src/qr/engine';
import { BASE_DESIGN, STYLE_PRESETS, applyPreset } from '../src/qr/presets';
import { DOT_SHAPES, EYE_SHAPES, type FrameStyle, type QrDesign } from '../src/qr/types';

const PAYLOADS = ['https://example.com/scan', 'WIFI:T:WPA;S:Guest-WiFi;P:secret123;;', 'BEGIN:VCARD\nVERSION:3.0\nN:Doe;Jane;;;\nFN:Jane Doe\nTEL;TYPE=CELL:+15550000000\nEMAIL:jane@example.com\nEND:VCARD'];
const PX_PER_MODULE = 10;

function raster(design: QrDesign, payload: string) {
  const n = createMatrix(payload, effectiveEc(design)).size;
  const width = (n + 2 * QUIET_ZONE) * PX_PER_MODULE;
  const r = new Resvg(renderSvg(payload, design), { fitTo: { mode: 'width', value: width }, background: '#ffffff', font: { loadSystemFonts: false } }).render();
  return { px: new Uint8ClampedArray(r.pixels.buffer, r.pixels.byteOffset, r.pixels.length), w: r.width, h: r.height };
}
const toLum = (px: Uint8ClampedArray, invert = false) => { const l = new Uint8ClampedArray(px.length / 4); for (let i = 0; i < l.length; i++) { const v = (px[i * 4] * 299 + px[i * 4 + 1] * 587 + px[i * 4 + 2] * 114) / 1000; l[i] = invert ? 255 - v : v; } return l; };
function zxing(px: Uint8ClampedArray, w: number, h: number, payload: string): 'ok' | 'inverted' | 'fail' {
  const hints = new Map(); hints.set(DecodeHintType.TRY_HARDER, true);
  const attempt = (invert: boolean) => { try { return new QRCodeReader().decode(new BinaryBitmap(new HybridBinarizer(new RGBLuminanceSource(toLum(px, invert), w, h))), hints).getText() === payload; } catch { return false; } };
  return attempt(false) ? 'ok' : attempt(true) ? 'inverted' : 'fail';
}
function jsqrSoft(px: Uint8ClampedArray, w: number, h: number, payload: string): 'ok' | 'inverted' | 'fail' {
  const copy = new Uint8ClampedArray(px); softenRgba(copy, w, h, PX_PER_MODULE * 0.3);
  if (jsQR(copy, w, h, { inversionAttempts: 'dontInvert' })?.data === payload) return 'ok';
  if (jsQR(copy, w, h, { inversionAttempts: 'attemptBoth' })?.data === payload) return 'inverted';
  return 'fail';
}
let zxFails = 0, jsFails = 0, total = 0, mismatches = 0;
const check = (label: string, design: QrDesign, payload: string) => {
  total++;
  const { px, w, h } = raster(design, payload);
  const zx = zxing(px, w, h, payload); const js = jsqrSoft(px, w, h, payload);
  if (zx === 'fail') zxFails++; if (js === 'fail') jsFails++;
  if (zx !== js) mismatches++;
  if (zx === 'fail' || js === 'fail' || zx !== js) console.log(`zxing=${zx.padEnd(8)} jsqr-soft=${js.padEnd(8)} ${label}`);
  else if (zx === 'inverted') console.log(`inverted (both)                   ${label}`);
};
for (const p of STYLE_PRESETS) for (const payload of PAYLOADS) check(`preset ${p.id} [${payload.slice(0, 10)}]`, applyPreset(null, p), payload);
for (const s of DOT_SHAPES) for (const scale of [0.65, 0.8, 1]) check(`shape ${s.value} @${scale}`, { ...BASE_DESIGN, dots: s.value, dotScale: scale }, PAYLOADS[0]);
for (const f of EYE_SHAPES) for (const b of EYE_SHAPES) check(`eye ${f.value}/${b.value}`, { ...BASE_DESIGN, eye: { frame: f.value, ball: b.value } }, PAYLOADS[2]);
const logo = 'data:image/svg+xml;utf8,' + encodeURIComponent('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 10 10"><rect width="10" height="10" rx="2" fill="#e11d48"/></svg>');
for (const scale of [0.18, 0.24, 0.3]) for (const round of [false, true]) for (const payload of PAYLOADS) check(`logo ${scale} round=${round} [${payload.slice(0, 8)}]`, { ...BASE_DESIGN, dots: 'rounded', logo, logoScale: scale, logoRound: round }, payload);
for (const style of ['label-bottom', 'label-top', 'badge', 'outline'] as FrameStyle[]) check(`frame ${style}`, { ...BASE_DESIGN, frame: { ...BASE_DESIGN.frame, style } }, PAYLOADS[0]);
check('transparent + glow', { ...BASE_DESIGN, transparent: true, glow: 0.6, dots: 'dot' }, PAYLOADS[0]);
check('low contrast (should fail)', { ...BASE_DESIGN, fg: { mode: 'solid', from: '#BBBBBB', to: '#BBBBBB', angle: 0 } }, PAYLOADS[0]);
console.log(`\n${total} designs · ZXing failures: ${zxFails} · jsQR(soft) failures: ${jsFails} · disagreements: ${mismatches}`);
