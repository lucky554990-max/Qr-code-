import { useCallback, useEffect, useRef, useState } from 'react';
import { Check } from 'lucide-react';
import { site } from './config/site';
import { PAGE_TITLES, SiteNavContext, parseRoute, routePath, useHashRoute, type Route } from './lib/nav';
import { scrollToId } from './lib/ui';
import { Footer, Navbar } from './components/Layout';
import Home from './pages/Home';
import About from './pages/About';
import Services from './pages/Services';
import Contact from './pages/Contact';
import { PrivacyPage, TermsPage } from './pages/Legal';

export default function App() {
  const route = useHashRoute();
  const [toastMsg, setToastMsg] = useState('');
  const toastTimer = useRef<number | undefined>(undefined);
  const pendingSection = useRef<string | null>(null);

  const toast = useCallback((message: string) => {
    setToastMsg(message);
    window.clearTimeout(toastTimer.current);
    toastTimer.current = window.setTimeout(() => setToastMsg(''), 2800);
  }, []);

  const go = useCallback((target: Route) => {
    if (parseRoute() === target) {
      window.scrollTo({ top: 0, behavior: 'smooth' });
      return;
    }
    window.location.hash = routePath(target);
  }, []);

  const section = useCallback((id: string) => {
    if (parseRoute() === 'home') {
      scrollToId(id);
      return;
    }
    pendingSection.current = id;
    window.location.hash = routePath('home');
  }, []);

  useEffect(() => {
    document.title = `${site.brand} — ${PAGE_TITLES[route]}`;
    if (route === 'home' && pendingSection.current) {
      const id = pendingSection.current;
      pendingSection.current = null;
      window.setTimeout(() => scrollToId(id), 80);
    } else {
      window.scrollTo({ top: 0, behavior: 'instant' });
    }
  }, [route]);

  const page =
    route === 'about' ? <About /> : route === 'services' ? <Services /> : route === 'contact' ? <Contact /> : route === 'privacy' ? <PrivacyPage /> : route === 'terms' ? <TermsPage /> : <Home />;

  return (
    <SiteNavContext.Provider value={{ route, go, section, toast }}>
      <div className="min-h-screen overflow-x-clip bg-[#FBFCF9] text-[#0A0F0D]">
        <a
          href="#main"
          onClick={(e) => {
            e.preventDefault();
            const main = document.getElementById('main');
            main?.focus();
            main?.scrollIntoView();
          }}
          className="sr-only focus:not-sr-only focus:fixed focus:left-3 focus:top-3 focus:z-[100] focus:rounded-full focus:bg-[#0A0F0D] focus:px-4 focus:py-2 focus:text-sm focus:text-white"
        >
          Skip to main content
        </a>

        <div aria-live="polite" className={`fixed bottom-6 left-1/2 z-[90] -translate-x-1/2 transition-all duration-500 ${toastMsg ? 'translate-y-0 opacity-100' : 'pointer-events-none translate-y-4 opacity-0'}`}>
          <div className="flex items-center gap-2 rounded-full bg-[#0A0F0D] py-2.5 pl-3 pr-4 text-sm font-medium text-white shadow-2xl shadow-black/25">
            <span className="grid h-6 w-6 place-items-center rounded-full bg-[#00C389]">
              <Check className="h-3.5 w-3.5" strokeWidth={3} />
            </span>
            {toastMsg}
          </div>
        </div>

        <Navbar />
        <main id="main" tabIndex={-1} className="outline-none">
          {page}
        </main>
        <Footer />
      </div>
    </SiteNavContext.Provider>
  );
}
