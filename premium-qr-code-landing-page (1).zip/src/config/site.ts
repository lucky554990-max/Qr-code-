/**
 * ============================================================
 *  SITE CONFIGURATION — fill in your real information here
 * ============================================================
 *  • Any value left as PLACEHOLDER is shown on the website as
 *    "[ADD REAL INFO HERE]" so you can spot it easily.
 *  • Lists (stats, clientLogos, certifications, reviews, team)
 *    keep their sections HIDDEN until you add real entries.
 *  • Nothing in this file is invented: every value is either a
 *    visible placeholder, an empty list, or a neutral default.
 */

export const PLACEHOLDER = '[ADD REAL INFO HERE]';

/** True once a value has been replaced with real information. */
export const isFilled = (value?: string | null): value is string =>
  !!value && value.trim() !== '' && !value.includes('[ADD REAL INFO HERE]');

export const site = {
  /** Brand / product name used in the logo, page titles and copy. */
  brand: 'QRForge',
  /** Registered legal entity, e.g. "QRForge Ltd." (footer and legal pages). */
  legalName: PLACEHOLDER,
  /** Public website address, e.g. "https://www.yourdomain.com". */
  websiteUrl: PLACEHOLDER,
  /** One-line description shown in the footer. */
  tagline: 'QR codes for the real world — create, brand, and track.',

  /* ---------- Contact details (Contact page and footer) ---------- */
  contactEmail: PLACEHOLDER, // e.g. "hello@yourdomain.com"
  phone: PLACEHOLDER, // e.g. "+1 555 000 0000"
  address: PLACEHOLDER, // e.g. "123 Example Street, City, Country"
  businessHours: PLACEHOLDER, // e.g. "Monday–Friday, 9:00–17:00 (CET)"
  responseTime: PLACEHOLDER, // e.g. "within one business day"

  /* ---------- Contact form delivery ---------- */
  /**
   * Option A (recommended): paste a form endpoint from a service such as
   * Formspree, Basin or Getform, e.g. "https://formspree.io/f/abcdwxyz".
   * Option B: leave this empty and fill in `contactEmail` — the form will
   * open the visitor's email app with the message pre-filled.
   */
  formEndpoint: '',
  /** Name of the form provider used above (shown in the Privacy Policy). */
  formProviderName: PLACEHOLDER,

  /** URL of your customer login / app. Leave empty to hide the "Sign in" link. */
  appUrl: '',

  /** Social profiles. Leave a value empty to hide its icon. */
  social: {
    x: '',
    linkedin: '',
    instagram: '',
    youtube: '',
  },

  /* ---------- About page ---------- */
  founded: PLACEHOLDER, // e.g. "2024"
  location: PLACEHOLDER, // e.g. "Berlin, Germany"

  /* ---------- Legal pages ---------- */
  governingLaw: PLACEHOLDER, // e.g. "the laws of England and Wales"
  privacyUpdated: PLACEHOLDER, // e.g. "1 March 2026"
  termsUpdated: PLACEHOLDER, // e.g. "1 March 2026"
  minimumAge: PLACEHOLDER, // e.g. "16"
};

/* ------------------------------------------------------------------ */
/*  HIDDEN-UNTIL-FILLED SECTIONS                                      */
/*  Add real entries below and the matching section appears.          */
/* ------------------------------------------------------------------ */

/** Key numbers shown under the hero headline. Only use figures you can back up. */
export type Stat = { value: string; label: string };
export const stats: Stat[] = [
  // { value: '1,200', label: 'QR codes created' },
];

/** Logos of real customers or partners (with their permission). */
export type ClientLogo = { name: string; imageUrl?: string; url?: string };
export const clientLogos: ClientLogo[] = [
  // { name: 'Example Co.', imageUrl: '/logos/example.svg', url: 'https://example.com' },
];

/** Real certifications, memberships or awards you hold. */
export type Certification = { name: string; detail?: string; url?: string };
export const certifications: Certification[] = [
  // { name: 'ISO 27001', detail: 'Certified since 2025', url: 'https://…' },
];

/** Real customer reviews (always ask permission before publishing). */
export type Review = {
  quote: string;
  name: string;
  role?: string;
  rating?: 1 | 2 | 3 | 4 | 5;
  date?: string;
};
export const reviews: Review[] = [
  // { quote: 'Short, honest quote.', name: 'Full name', role: 'Title, Company', rating: 5, date: 'March 2026' },
];

/** Team members shown on the About page. */
export type TeamMember = { name: string; role: string; bio?: string; photoUrl?: string };
export const team: TeamMember[] = [
  // { name: 'Full name', role: 'Founder', bio: 'One or two sentences.', photoUrl: '/team/name.jpg' },
];

/* ------------------------------------------------------------------ */
/*  PRICING — prices and limits are placeholders until you confirm them */
/* ------------------------------------------------------------------ */
export type Plan = {
  name: string;
  description: string;
  price: string; // e.g. "$12"
  period: string; // e.g. "per month"
  features: string[];
  limits: string; // e.g. "Up to 50 dynamic codes, 2 team members"
  highlighted?: boolean;
};
export const plans: Plan[] = [
  {
    name: 'Starter',
    description: 'For individuals and small projects.',
    price: PLACEHOLDER,
    period: 'per month',
    features: ['Dynamic QR codes', 'Basic scan statistics', 'PNG and SVG downloads'],
    limits: PLACEHOLDER,
  },
  {
    name: 'Growth',
    description: 'For growing businesses.',
    price: PLACEHOLDER,
    period: 'per month',
    highlighted: true,
    features: ['Everything in Starter', 'Custom colors, logo and frames', 'Detailed scan analytics', 'Bulk creation from a spreadsheet'],
    limits: PLACEHOLDER,
  },
  {
    name: 'Business',
    description: 'For brands and multi-location teams.',
    price: PLACEHOLDER,
    period: 'per month',
    features: ['Everything in Growth', 'Team access and roles', 'API access', 'Priority support'],
    limits: PLACEHOLDER,
  },
];
