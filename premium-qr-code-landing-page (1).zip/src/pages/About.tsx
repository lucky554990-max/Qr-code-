import { Building2, CalendarDays, Mail, MapPin, ShieldCheck, Sparkles, Zap } from 'lucide-react';
import { isFilled, site, team } from '../config/site';
import { ArrowIcon, CtaBand, Info, PageHero, PlaceholderBlock, Reveal, SectionHeading, btn } from '../lib/ui';
import { PageLink, useSiteNav } from '../lib/nav';

export default function About() {
  const { section } = useSiteNav();
  const facts = [
    { icon: CalendarDays, label: 'Founded', value: site.founded },
    { icon: MapPin, label: 'Based in', value: site.location },
    { icon: Building2, label: 'Legal name', value: site.legalName },
    { icon: Mail, label: 'Email', value: site.contactEmail, href: isFilled(site.contactEmail) ? `mailto:${site.contactEmail}` : undefined },
  ];

  return (
    <>
      <PageHero
        label="ABOUT US"
        title={`About ${site.brand}`}
        intro={`${site.brand} helps businesses connect printed materials with digital experiences. We build simple tools for creating QR codes, and dynamic codes that can be edited and measured after they are printed.`}
      >
        <button onClick={() => section('generator')} className={btn.dark}>
          Try the free generator <ArrowIcon />
        </button>
        <PageLink to="contact" className={btn.outline}>
          Contact us
        </PageLink>
      </PageHero>

      <section className="py-16 sm:py-24">
        <div className="mx-auto grid max-w-7xl items-start gap-10 px-4 sm:px-6 lg:grid-cols-[1.1fr_0.9fr] lg:gap-16">
          <div>
            <SectionHeading align="left" label="OUR STORY" title="Who we are and why we started." />
            <Reveal delay={200}>
              <PlaceholderBlock
                className="mt-8"
                hint="Write two or three short paragraphs about your company: who founded it, what problem you set out to solve, and what you are building today. Keep it factual — only include dates, numbers, and achievements you can back up."
              />
            </Reveal>
          </div>
          <Reveal scale delay={150}>
            <dl className="rounded-[26px] border border-black/[0.07] bg-[#F3F5EE] p-7 sm:p-8">
              <p className="font-display text-lg font-bold">Company details</p>
              <div className="mt-5 divide-y divide-black/[0.06]">
                {facts.map((f) => (
                  <div key={f.label} className="flex items-start gap-4 py-4 first:pt-0 last:pb-0">
                    <span className="grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-white shadow-sm">
                      <f.icon className="h-4.5 w-4.5 text-[#009E6E]" />
                    </span>
                    <div className="min-w-0">
                      <dt className="text-[12px] font-semibold uppercase tracking-wide text-neutral-500">{f.label}</dt>
                      <dd className="mt-0.5 break-words text-[15px] font-medium">
                        <Info value={f.value} href={f.href} />
                      </dd>
                    </div>
                  </div>
                ))}
              </div>
            </dl>
          </Reveal>
        </div>
      </section>

      <section className="border-y border-black/[0.05] bg-[#F3F5EE] py-16 sm:py-24">
        <div className="mx-auto max-w-7xl px-4 sm:px-6">
          <SectionHeading label="HOW WE WORK" title="Three principles behind everything we build." />
          <div className="mt-12 grid gap-4 sm:gap-5 md:grid-cols-3">
            {[
              { icon: Zap, title: 'Simple by design', desc: 'The free generator takes seconds to use and needs no account. Everything else should feel just as straightforward.' },
              { icon: ShieldCheck, title: 'Honest by default', desc: 'We publish only real customer reviews, real figures, and real certifications. If we cannot back it up, it is not on this website.' },
              { icon: Sparkles, title: 'Privacy-conscious', desc: 'The free generator runs entirely in your browser. The content you enter is never uploaded to our servers.' },
            ].map((p, i) => (
              <Reveal key={p.title} scale delay={i * 90}>
                <article className="group h-full rounded-[26px] border border-black/[0.07] bg-white p-7 transition-all duration-500 hover:-translate-y-1 hover:shadow-[0_24px_50px_-20px_rgba(10,15,13,0.25)]">
                  <span className="grid h-12 w-12 place-items-center rounded-2xl bg-[#0A0F0D] transition-transform group-hover:-rotate-3 group-hover:scale-110">
                    <p.icon className="h-6 w-6 text-[#C8F169]" />
                  </span>
                  <h3 className="mt-5 font-display text-[21px] font-bold">{p.title}</h3>
                  <p className="mt-2 text-[15px] leading-relaxed text-neutral-600">{p.desc}</p>
                </article>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      {team.length > 0 && (
        <section className="py-16 sm:py-24">
          <div className="mx-auto max-w-7xl px-4 sm:px-6">
            <SectionHeading label="TEAM" title="The people behind the product." />
            <div className="mt-12 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
              {team.map((m, i) => (
                <Reveal key={m.name} scale delay={i * 80}>
                  <article className="h-full rounded-[26px] border border-black/[0.07] bg-white p-6">
                    {m.photoUrl ? (
                      <img src={m.photoUrl} alt={m.name} className="h-20 w-20 rounded-2xl object-cover" loading="lazy" />
                    ) : (
                      <span className="grid h-20 w-20 place-items-center rounded-2xl bg-[#0A0F0D] font-display text-xl font-extrabold text-[#C8F169]">
                        {m.name
                          .split(/\s+/)
                          .map((p) => p[0])
                          .join('')
                          .slice(0, 2)
                          .toUpperCase()}
                      </span>
                    )}
                    <h3 className="mt-5 font-display text-lg font-bold">{m.name}</h3>
                    <p className="text-sm font-medium text-[#007A55]">{m.role}</p>
                    {m.bio && <p className="mt-3 text-[14.5px] leading-relaxed text-neutral-600">{m.bio}</p>}
                  </article>
                </Reveal>
              ))}
            </div>
          </div>
        </section>
      )}

      <CtaBand />
    </>
  );
}
