import { BarChart3, Code2, Layers, Palette, QrCode, RefreshCw } from 'lucide-react';
import { site } from '../config/site';
import { ArrowIcon, CtaBand, PageHero, Reveal, SectionHeading, btn, btnBase } from '../lib/ui';
import { PageLink, useSiteNav } from '../lib/nav';

const SERVICES = [
  {
    icon: QrCode,
    title: 'Free QR code generator',
    badge: 'Available now',
    desc: 'Create URL, text, WiFi, and contact (vCard) codes directly in your browser. Choose a color and frame, then download a PNG or SVG. No account required.',
    points: ['Works with any phone camera', 'PNG for screens, SVG for print', 'Nothing you enter is uploaded'],
    cta: 'generator',
  },
  {
    icon: RefreshCw,
    title: 'Dynamic QR codes',
    desc: 'Codes that point to a short link you control, so you can change the destination after printing. Ideal for menus, packaging, signage, and campaigns.',
    points: ['Edit the destination at any time', 'No reprinting when things change', 'Scheduling and routing options'],
    cta: 'contact',
  },
  {
    icon: Palette,
    title: 'Custom branding',
    desc: 'Codes designed to match your brand — your colors, your logo, and frames with a clear call to action — delivered as files ready for print and screen.',
    points: ['Colors, logo, and frame styles', 'Print-ready vector files', 'Consistent look across locations'],
    cta: 'contact',
  },
  {
    icon: BarChart3,
    title: 'Scan analytics',
    desc: 'See how often your dynamic codes are scanned, when, roughly where, and on which devices — so you can learn which placements and designs work.',
    points: ['Scans over time', 'Location and device breakdown', 'Exports for your team or clients'],
    cta: 'contact',
  },
  {
    icon: Layers,
    title: 'Bulk generation',
    desc: 'Create many codes at once from a spreadsheet — for products, tables, tickets, or locations — and keep them organised in folders.',
    points: ['Spreadsheet import', 'Unique code per item', 'Folders and naming conventions'],
    cta: 'contact',
  },
  {
    icon: Code2,
    title: 'API and integrations',
    desc: 'Create and manage codes from your own systems and connect scan data to the tools your team already uses.',
    points: ['Programmatic code creation', 'Scan data where you need it', 'Technical support for your team'],
    cta: 'contact',
  },
];

export default function Services() {
  const { section } = useSiteNav();
  return (
    <>
      <PageHero
        label="SERVICES"
        title="What we offer"
        intro={`From a free generator you can use right now to dynamic codes with analytics for growing businesses — here is how ${site.brand} can help.`}
      >
        <button onClick={() => section('generator')} className={btn.dark}>
          Open the free generator <ArrowIcon />
        </button>
        <PageLink to="contact" className={btn.outline}>
          Discuss your project
        </PageLink>
      </PageHero>

      <section className="py-16 sm:py-24">
        <div className="mx-auto max-w-7xl px-4 sm:px-6">
          <div className="grid gap-4 sm:gap-5 md:grid-cols-2 lg:grid-cols-3">
            {SERVICES.map((s, i) => (
              <Reveal key={s.title} scale delay={(i % 3) * 90}>
                <article className="group flex h-full flex-col rounded-[26px] border border-black/[0.07] bg-white p-7 transition-all duration-500 hover:-translate-y-1 hover:shadow-[0_24px_50px_-20px_rgba(10,15,13,0.25)]">
                  <div className="flex items-start justify-between gap-3">
                    <span className="grid h-12 w-12 place-items-center rounded-2xl bg-[#0A0F0D] transition-transform group-hover:-rotate-3 group-hover:scale-110">
                      <s.icon className="h-6 w-6 text-[#C8F169]" />
                    </span>
                    {s.badge && <span className="rounded-full bg-[#E6F8F1] px-2.5 py-1 text-[11px] font-bold tracking-wider text-[#007A55]">{s.badge.toUpperCase()}</span>}
                  </div>
                  <h2 className="mt-5 font-display text-[21px] font-bold">{s.title}</h2>
                  <p className="mt-2 text-[15px] leading-relaxed text-neutral-600">{s.desc}</p>
                  <ul className="mt-5 space-y-2 text-[14px] font-medium text-neutral-700">
                    {s.points.map((p) => (
                      <li key={p} className="flex gap-2">
                        <span className="mt-[7px] h-1.5 w-1.5 shrink-0 rounded-full bg-[#00C389]" />
                        {p}
                      </li>
                    ))}
                  </ul>
                  <div className="mt-auto pt-7">
                    {s.cta === 'generator' ? (
                      <button onClick={() => section('generator')} className={`${btnBase} w-full bg-[#00C389] px-5 py-3 text-[14px] text-white hover:bg-[#009E6E]`}>
                        Create a code now <ArrowIcon />
                      </button>
                    ) : (
                      <PageLink to="contact" className={`${btnBase} w-full border border-black/15 px-5 py-3 text-[14px] hover:border-black/40 hover:bg-black/[0.03]`}>
                        Ask about this <ArrowIcon />
                      </PageLink>
                    )}
                  </div>
                </article>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      <section className="border-y border-black/[0.05] bg-[#F3F5EE] py-16 sm:py-24">
        <div className="mx-auto max-w-7xl px-4 sm:px-6">
          <SectionHeading label="HOW IT WORKS" title="Getting started is simple." intro="Whether you need one code or thousands, the path is the same." />
          <div className="mt-12 grid gap-4 sm:gap-5 md:grid-cols-3">
            {[
              { n: '01', title: 'Tell us what you need', desc: 'Use the contact form to describe your project: where the codes will go, how many you need, and what they should link to.' },
              { n: '02', title: 'We set things up', desc: 'We recommend the right type of code, prepare the designs, and make sure everything scans reliably at the sizes you will print.' },
              { n: '03', title: 'You launch and learn', desc: 'Print, share, and — with dynamic codes — watch the scans come in. Change destinations whenever you need to, without reprinting.' },
            ].map((step, i) => (
              <Reveal key={step.n} delay={i * 110}>
                <article className="h-full rounded-[24px] border border-black/[0.07] bg-white p-7 transition-all duration-500 hover:-translate-y-1 hover:shadow-[0_24px_48px_-20px_rgba(10,15,13,0.28)]">
                  <span className="font-mono text-[12px] font-semibold tracking-widest text-[#009E6E]">STEP {step.n}</span>
                  <h3 className="mt-2 font-display text-xl font-bold">{step.title}</h3>
                  <p className="mt-2 text-[15px] leading-relaxed text-neutral-600">{step.desc}</p>
                </article>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      <CtaBand title="Not sure which option fits?" text="Tell us about your project and we will recommend the simplest setup that does the job." />
    </>
  );
}
