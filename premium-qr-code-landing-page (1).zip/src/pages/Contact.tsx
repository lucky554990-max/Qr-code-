import { Clock3, Mail, MapPin, Phone, Timer } from 'lucide-react';
import { isFilled, site } from '../config/site';
import { Info, PageHero, Reveal } from '../lib/ui';
import { ContactForm } from '../components/Forms';

export default function Contact() {
  const details = [
    { icon: Mail, label: 'Email', value: site.contactEmail, href: isFilled(site.contactEmail) ? `mailto:${site.contactEmail}` : undefined },
    { icon: Phone, label: 'Phone', value: site.phone, href: isFilled(site.phone) ? `tel:${site.phone.replace(/[^+\d]/g, '')}` : undefined },
    { icon: MapPin, label: 'Address', value: site.address },
    { icon: Clock3, label: 'Business hours', value: site.businessHours },
    { icon: Timer, label: 'Typical response time', value: site.responseTime },
  ];

  return (
    <>
      <PageHero
        label="CONTACT"
        title="Get in touch"
        intro="Questions about QR codes, plans, or a project you are planning? Send us a message and a real person will reply."
      />

      <section className="py-16 sm:py-24">
        <div className="mx-auto grid max-w-7xl items-start gap-8 px-4 sm:px-6 lg:grid-cols-[0.8fr_1.2fr] lg:gap-12">
          <Reveal scale>
            <div className="rounded-[26px] bg-[#0A0F0D] p-7 text-white sm:p-8 lg:sticky lg:top-28">
              <h2 className="font-display text-2xl font-bold">Contact details</h2>
              <p className="mt-2 text-[15px] leading-relaxed text-white/60">Prefer to reach out directly? Here is how to find us.</p>
              <dl className="mt-7 space-y-5">
                {details.map((d) => (
                  <div key={d.label} className="flex items-start gap-4">
                    <span className="grid h-10 w-10 shrink-0 place-items-center rounded-xl border border-white/10 bg-white/[0.07]">
                      <d.icon className="h-4.5 w-4.5 text-[#C8F169]" />
                    </span>
                    <div className="min-w-0">
                      <dt className="text-[12px] font-semibold uppercase tracking-wide text-white/45">{d.label}</dt>
                      <dd className="mt-0.5 break-words text-[15px] font-medium text-white/90">
                        <Info value={d.value} href={d.href} />
                      </dd>
                    </div>
                  </div>
                ))}
              </dl>
            </div>
          </Reveal>

          <Reveal delay={120}>
            <div className="rounded-[26px] border border-black/[0.07] bg-white p-6 shadow-[0_30px_70px_-28px_rgba(10,15,13,0.3)] sm:p-9">
              <h2 className="font-display text-2xl font-bold">Send us a message</h2>
              <p className="mt-2 text-[15px] text-neutral-600">Fill in the form and we will get back to you {isFilled(site.responseTime) ? site.responseTime : 'as soon as we can'}.</p>
              <div className="mt-7">
                <ContactForm />
              </div>
            </div>
          </Reveal>
        </div>
      </section>
    </>
  );
}
