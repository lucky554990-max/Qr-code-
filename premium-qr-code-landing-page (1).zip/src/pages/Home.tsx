import { useEffect, useState } from 'react';
import {
  ArrowRight,
  ArrowUpRight,
  BarChart3,
  BellRing,
  CalendarDays,
  Check,
  ChevronLeft,
  ChevronRight,
  Clock3,
  Code2,
  Contact,
  CreditCard,
  Eye,
  FileText,
  FolderDown,
  Globe,
  Hotel,
  Image as ImageIcon,
  Layers,
  Link2,
  Lock,
  MapPin,
  Minus,
  MousePointerClick,
  Palette,
  Plus,
  QrCode,
  RefreshCw,
  ScanLine,
  ShieldCheck,
  Smartphone,
  Star,
  Store,
  Ticket,
  TrendingUp,
  Users,
  UtensilsCrossed,
  Wifi,
} from 'lucide-react';
import { certifications, clientLogos, isFilled, plans, reviews, site, stats } from '../config/site';
import { ArrowIcon, CountUp, Placeholder, Reveal, SectionHeading, btn, btnBase } from '../lib/ui';
import { PageLink, useSiteNav } from '../lib/nav';
import { FeedbackForm } from '../components/Forms';
import { Generator } from '../components/Generator';

/* ================================================================== */
/*  Data (descriptive only — no statistics, customers or claims)       */
/* ================================================================== */
const HERO_WORDS = ['menus', 'payments', 'reviews', 'bookings', 'sign-ups', 'connections'];

const SHOWCASE = [
  {
    id: 'restaurants',
    label: 'Restaurants & cafés',
    icon: UtensilsCrossed,
    title: 'Menus, ordering, and feedback — straight from the table.',
    desc: 'Place a code on each table or in the window. Guests open your menu, order, or pay from their phone. With a dynamic code you can change the menu behind it without reprinting anything.',
    img: 'https://images.pexels.com/photos/37594390/pexels-photo-37594390.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200',
    alt: 'Guests paying with a smartphone at a restaurant counter',
    bullets: ['Digital menus you can update at any time', 'Links to ordering or payment pages', 'Feedback and review requests after the meal'],
  },
  {
    id: 'retail',
    label: 'Retail & e-commerce',
    icon: Store,
    title: 'Add a digital layer to shelves, tags, and packaging.',
    desc: 'Link products to care guides, tutorials, loyalty sign-ups, or your online shop. With dynamic codes you can see which displays and products get the most scans.',
    img: 'https://images.pexels.com/photos/6925800/pexels-photo-6925800.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200',
    alt: 'Customer paying at the counter of a modern retail store',
    bullets: ['Product details and guides on the package', 'Loyalty and newsletter sign-ups', 'Scan statistics per store or display'],
  },
  {
    id: 'events',
    label: 'Events & conferences',
    icon: Ticket,
    title: 'Faster check-in and easier connections.',
    desc: 'Use codes on badges, posters, and slides for check-in, schedules, contact exchange, and sponsor pages — and update them while the event is running.',
    img: 'https://images.pexels.com/photos/35138560/pexels-photo-35138560.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200',
    alt: 'Attendees walking through a busy trade show hall',
    bullets: ['Schedules and venue maps in one scan', 'vCard codes for exchanging contact details', 'Sponsor and session pages you can update live'],
  },
  {
    id: 'hospitality',
    label: 'Hotels & hospitality',
    icon: Hotel,
    title: 'Guest information without the front-desk queue.',
    desc: 'Put WiFi access, room service, local tips, and feedback forms behind codes in rooms and common areas — in the language your guest prefers.',
    img: 'https://images.pexels.com/photos/29517898/pexels-photo-29517898.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200',
    alt: 'Warmly lit café and hotel lounge interior',
    bullets: ['WiFi access without typing passwords', 'Room service and local guides', 'Private feedback forms for guests'],
  },
];

type CodeType = 'URL' | 'Text' | 'WiFi' | 'vCard';
const QR_TYPES: { icon: typeof Link2; name: string; desc: string; example: string; free: CodeType | null }[] = [
  { icon: Link2, name: 'Website URL', desc: 'Send people to any web page: your site, shop, menu, or booking form.', example: 'Try it free above', free: 'URL' },
  { icon: Wifi, name: 'WiFi access', desc: 'Guests join your network by scanning — no passwords to spell out.', example: 'Try it free above', free: 'WiFi' },
  { icon: Contact, name: 'vCard contact', desc: 'Your name, phone, and email saved to their contacts in one tap.', example: 'Try it free above', free: 'vCard' },
  { icon: FileText, name: 'PDF & menus', desc: 'Link to a menu, brochure, or manual. With a dynamic code, replace the file and keep the code.', example: 'Link to a hosted file', free: 'URL' },
  { icon: CreditCard, name: 'Payments', desc: 'Link to your payment or tipping page so customers can pay from their phone.', example: 'Link to a payment page', free: 'URL' },
  { icon: MapPin, name: 'Location', desc: 'Open directions to your venue in the visitor\u2019s maps app.', example: 'Link to a maps location', free: 'URL' },
  { icon: Star, name: 'Reviews', desc: 'Make it easy for happy customers to leave a review while they are still with you.', example: 'Link to your review page', free: 'URL' },
  { icon: CalendarDays, name: 'Events', desc: 'Link to an event page with the date, venue, and RSVP details.', example: 'Link to an event page', free: 'URL' },
  { icon: ImageIcon, name: 'Image gallery', desc: 'Share a portfolio, lookbook, or set of photos behind one code.', example: 'Link to a gallery', free: 'URL' },
  { icon: Smartphone, name: 'App download', desc: 'One code that sends iPhone and Android users to the right app store.', example: 'Dynamic code feature', free: null },
  { icon: Users, name: 'Social links', desc: 'All of your profiles on one simple mobile page.', example: 'Link to a profile page', free: 'URL' },
  { icon: Globe, name: 'Multi-URL', desc: 'Send people to different pages based on language, location, or time of day.', example: 'Dynamic code feature', free: null },
];

const FAQS = [
  {
    q: 'What is the difference between a static and a dynamic QR code?',
    a: 'A static code stores your content (for example a web address) directly in the pattern, so it can never change. A dynamic code stores a short link that redirects to your content, which means you can change the destination later and count the scans. The free generator on this page creates static codes.',
  },
  {
    q: 'Is the QR code generator on this page free?',
    a: 'Yes. It runs entirely in your browser, needs no account, and you can download your code as a PNG or SVG file. The content you enter is not sent to our servers.',
  },
  {
    q: 'Do people need a special app to scan my code?',
    a: 'No. The camera app on current iPhones and Android phones recognises QR codes automatically and shows a link to open.',
  },
  {
    q: 'Can I change where a QR code points after it has been printed?',
    a: 'Only with a dynamic code. Because a dynamic code points to a redirect link, you can update the destination at any time and every printed copy keeps working. A static code would need to be generated and printed again.',
  },
  {
    q: 'Which file format should I use?',
    a: 'Use SVG for anything that will be printed — it scales to any size without losing sharpness. Use PNG for screens, documents, and messaging apps.',
  },
  {
    q: 'Why might a QR code fail to scan?',
    a: 'The most common causes are low contrast between the code and its background, printing the code too small for the scanning distance, or removing the white margin (the "quiet zone") around it. Keep the code dark on a light background and test it with a phone before you print in bulk.',
  },
  {
    q: 'How can I get help?',
    a: 'Send us a message through the contact page and we will get back to you.',
  },
];

function Hero() {
  const { section } = useSiteNav();
  const [wordIdx, setWordIdx] = useState(0);
  useEffect(() => {
    const t = setInterval(() => setWordIdx((i) => (i + 1) % HERO_WORDS.length), 2400);
    return () => clearInterval(t);
  }, []);

  return (
    <section id="generator" className="relative scroll-mt-20 pt-[120px] pb-16 sm:pt-[148px] sm:pb-24">
      <div className="absolute inset-0 -z-10 bg-[#F3F5EE]" aria-hidden="true" />
      <div className="dot-grid absolute inset-0 -z-10 opacity-[0.35] [mask-image:radial-gradient(ellipse_75%_60%_at_50%_0%,black,transparent)]" aria-hidden="true" />
      <div className="absolute -top-20 right-[8%] -z-10 h-72 w-72 rounded-full bg-[#C8F169]/40 blur-3xl" aria-hidden="true" />
      <div className="absolute top-64 -left-24 -z-10 h-72 w-72 rounded-full bg-[#00C389]/15 blur-3xl" aria-hidden="true" />

      <div className="mx-auto max-w-7xl px-4 sm:px-6">
        <div className="grid items-center gap-12 lg:grid-cols-[1.05fr_0.95fr] lg:gap-10">
          <div className="max-w-xl">
            <Reveal>
              <div className="inline-flex items-center gap-2 rounded-full border border-black/[0.08] bg-white py-1.5 pl-1.5 pr-3 text-[13px] font-semibold shadow-sm">
                <span className="rounded-full bg-[#0A0F0D] px-2 py-0.5 text-[11px] font-bold tracking-wide text-[#C8F169]">FREE</span>
                QR code generator — no sign-up needed
              </div>
            </Reveal>
            <Reveal delay={90}>
              <h1 className="mt-6 font-display text-[44px] font-extrabold leading-[0.98] tracking-[-0.03em] sm:text-[64px] lg:text-[68px]">
                QR codes that turn scans into{' '}
                <span className="relative inline-flex h-[1.02em] min-w-[4.6ch] overflow-hidden align-bottom text-[#009E6E]">
                  <span key={wordIdx} className="animate-hero-word inline-block">
                    {HERO_WORDS[wordIdx]}
                  </span>
                </span>
                <span className="relative -mt-3 ml-2 inline-block align-middle">
                  <span className="animate-ping-soft absolute inset-0 rounded-full bg-[#C8F169]" />
                  <ScanLine className="relative h-8 w-8 text-[#0A0F0D] sm:h-11 sm:w-11" />
                </span>
              </h1>
            </Reveal>
            <Reveal delay={180}>
              <p className="mt-6 text-[17px] leading-relaxed text-neutral-600 sm:text-lg">
                Create a QR code in seconds with the free generator — right here, no account needed. Need codes you can edit after printing and measure scan by scan?
                That is what dynamic QR codes are for.
              </p>
            </Reveal>
            <Reveal delay={260}>
              <div className="mt-8 flex flex-col gap-3 sm:flex-row">
                <button onClick={() => section('generator-card')} className={btn.mint}>
                  Create a free QR code <ArrowIcon />
                </button>
                <PageLink to="contact" className={btn.outline}>
                  Contact us
                </PageLink>
              </div>
              <p className="mt-4 flex flex-wrap items-center gap-x-4 gap-y-1 text-[13px] font-medium text-neutral-500">
                {['Free to use', 'No sign-up required', 'Runs in your browser'].map((t) => (
                  <span key={t} className="inline-flex items-center gap-1.5">
                    <Check className="h-3.5 w-3.5 text-[#009E6E]" strokeWidth={3} /> {t}
                  </span>
                ))}
              </p>
            </Reveal>
            {stats.length > 0 && (
              <Reveal delay={340}>
                <dl className="mt-10 grid max-w-md grid-cols-3 gap-4 border-t border-black/[0.08] pt-8">
                  {stats.slice(0, 3).map((s) => (
                    <div key={s.label}>
                      <dd className="font-display text-[26px] font-extrabold tracking-tight sm:text-3xl">{s.value}</dd>
                      <dt className="mt-0.5 text-[12px] font-semibold uppercase tracking-wide text-neutral-500">{s.label}</dt>
                    </div>
                  ))}
                </dl>
              </Reveal>
            )}
          </div>
          <Reveal scale delay={200} className="relative">
            <Generator />
          </Reveal>
        </div>
      </div>
    </section>
  );
}

/* ================================================================== */
/*  Social proof — hidden until real logos / certifications exist      */
/* ================================================================== */
function SocialProof() {
  if (clientLogos.length === 0 && certifications.length === 0) return null;
  const marquee = clientLogos.length >= 5;
  const logoItems = (marquee ? [...clientLogos, ...clientLogos] : clientLogos).map((l, i) => {
    const content = l.imageUrl ? (
      <img src={l.imageUrl} alt={l.name} className="h-8 w-auto opacity-70 grayscale transition hover:opacity-100 hover:grayscale-0" loading="lazy" />
    ) : (
      <span className="whitespace-nowrap font-display text-[19px] font-bold text-neutral-400 transition-colors hover:text-[#0A0F0D]">{l.name}</span>
    );
    return l.url ? (
      <a key={`${l.name}-${i}`} href={l.url} target="_blank" rel="noreferrer">
        {content}
      </a>
    ) : (
      <span key={`${l.name}-${i}`}>{content}</span>
    );
  });

  return (
    <section aria-label="Customers and certifications" className="border-y border-black/[0.06] bg-white py-10 sm:py-12">
      <div className="mx-auto max-w-7xl px-4 sm:px-6">
        {clientLogos.length > 0 && (
          <>
            <Reveal>
              <p className="text-center text-[12px] font-bold tracking-[0.22em] text-neutral-400">TRUSTED BY</p>
            </Reveal>
            <Reveal delay={100}>
              {marquee ? (
                <div className="marquee-mask marquee-paused relative mt-7 overflow-hidden">
                  <div className="animate-marquee flex w-max items-center gap-14 pr-14">{logoItems}</div>
                </div>
              ) : (
                <div className="mt-7 flex flex-wrap items-center justify-center gap-x-14 gap-y-6">{logoItems}</div>
              )}
            </Reveal>
          </>
        )}
        {certifications.length > 0 && (
          <Reveal delay={160}>
            <ul className="mt-8 flex flex-wrap justify-center gap-x-8 gap-y-3 text-[13px] font-semibold text-neutral-600">
              {certifications.map((c) => (
                <li key={c.name} className="inline-flex items-center gap-2">
                  <ShieldCheck className="h-4 w-4 text-[#009E6E]" />
                  {c.url ? (
                    <a href={c.url} target="_blank" rel="noreferrer" className="hover:underline">
                      {c.name}
                    </a>
                  ) : (
                    c.name
                  )}
                  {c.detail && <span className="font-normal text-neutral-400">· {c.detail}</span>}
                </li>
              ))}
            </ul>
          </Reveal>
        )}
      </div>
    </section>
  );
}

/* ================================================================== */
/*  Features                                                           */
/* ================================================================== */
function Features() {
  const { section } = useSiteNav();
  const card = 'group h-full rounded-[26px] border border-black/[0.07] bg-white p-7 transition-all duration-500 hover:-translate-y-1 hover:shadow-[0_24px_50px_-20px_rgba(10,15,13,0.25)]';
  return (
    <section id="features" className="scroll-mt-24 py-20 sm:py-28">
      <div className="mx-auto max-w-7xl px-4 sm:px-6">
        <SectionHeading
          label="WHAT DYNAMIC CODES ADD"
          title={
            <>
              Not just a QR code.
              <br />A link you control.
            </>
          }
          intro="A standard QR code is fixed the moment you create it. A dynamic code points to a link you manage — so you can change the destination, brand the design, and see how it performs."
        />

        <div className="mt-12 grid gap-4 sm:mt-16 sm:gap-5 md:grid-cols-3">
          <Reveal scale className="md:col-span-2">
            <article className="relative h-full overflow-hidden rounded-[26px] bg-[#0A0F0D] p-7 text-white transition-shadow duration-500 hover:shadow-[0_30px_60px_-20px_rgba(10,15,13,0.55)] sm:p-9">
              <div className="dot-grid-light absolute inset-0 opacity-40 [mask-image:radial-gradient(ellipse_60%_55%_at_85%_10%,black,transparent)]" aria-hidden="true" />
              <div className="relative grid items-end gap-8 sm:grid-cols-2">
                <div>
                  <span className="grid h-12 w-12 place-items-center rounded-2xl bg-[#C8F169] shadow-lg">
                    <BarChart3 className="h-6 w-6 text-[#0A0F0D]" />
                  </span>
                  <h3 className="mt-5 font-display text-2xl font-bold">Scan analytics</h3>
                  <p className="mt-2 text-[15px] leading-relaxed text-white/65">
                    See when your dynamic codes are scanned, roughly where, and on which devices. Compare codes and campaigns to learn which placements work.
                  </p>
                  <ul className="mt-6 space-y-2 text-[14px] text-white/80">
                    {['Scans over time, per code or campaign', 'Location and device breakdown', 'Export for your team or clients'].map((t) => (
                      <li key={t} className="flex gap-2">
                        <Check className="mt-0.5 h-4 w-4 shrink-0 text-[#C8F169]" strokeWidth={3} /> {t}
                      </li>
                    ))}
                  </ul>
                </div>
                <div className="rounded-2xl border border-white/10 bg-white/[0.06] p-4 backdrop-blur" aria-hidden="true">
                  <div className="flex justify-between text-[11px] font-semibold text-white/50">
                    <span>SCANS · LAST 7 DAYS</span>
                    <span className="rounded bg-white/10 px-1.5 py-0.5 text-[10px] tracking-wider text-white/60">SAMPLE DATA</span>
                  </div>
                  <div className="mt-3 flex h-28 items-end gap-2">
                    {[42, 58, 48, 72, 64, 88, 100].map((h, i) => (
                      <div key={i} className="bar-grow flex-1 rounded-t-md" style={{ height: `${h}%`, backgroundColor: i === 6 ? '#C8F169' : 'rgba(255,255,255,0.22)', animationDelay: `${i * 90}ms` }} />
                    ))}
                  </div>
                  <div className="mt-2 flex justify-between text-[10px] font-medium text-white/40">
                    {['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'].map((d) => (
                      <span key={d}>{d}</span>
                    ))}
                  </div>
                </div>
              </div>
            </article>
          </Reveal>

          <Reveal scale delay={100}>
            <article className={card}>
              <span className="grid h-12 w-12 place-items-center rounded-2xl bg-[#E6F8F1] transition-transform group-hover:scale-110">
                <RefreshCw className="h-6 w-6 text-[#009E6E]" />
              </span>
              <h3 className="mt-5 font-display text-[21px] font-bold">Edit after printing</h3>
              <p className="mt-2 text-[15px] leading-relaxed text-neutral-600">Fix a typo, swap the destination, or launch a weekend offer. Every printed copy of a dynamic code keeps working.</p>
              <button onClick={() => section('generator')} className="mt-5 inline-flex items-center gap-1.5 text-sm font-bold text-[#009E6E]">
                Try the generator <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-1" />
              </button>
            </article>
          </Reveal>

          {[
            { icon: Palette, bg: 'bg-amber-100', fg: 'text-amber-700', title: 'Match your brand', desc: 'Choose colors and frames, add your logo, and download files that are ready for print and screen.' },
            { icon: Layers, bg: 'bg-teal-100', fg: 'text-teal-700', title: 'Bulk creation', desc: 'Create many codes at once from a spreadsheet — for products, tables, tickets, or locations — and keep them organised in folders.' },
            { icon: Lock, bg: 'bg-emerald-100', fg: 'text-emerald-700', title: 'Access controls', desc: 'Protect codes with a password, set an expiry date, and decide who on your team can edit them.' },
          ].map((f, i) => (
            <Reveal key={f.title} scale delay={i * 90}>
              <article className={card}>
                <span className={`grid h-12 w-12 place-items-center rounded-2xl ${f.bg} transition-transform group-hover:-rotate-3 group-hover:scale-110`}>
                  <f.icon className={`h-6 w-6 ${f.fg}`} />
                </span>
                <h3 className="mt-5 font-display text-[21px] font-bold">{f.title}</h3>
                <p className="mt-2 text-[15px] leading-relaxed text-neutral-600">{f.desc}</p>
              </article>
            </Reveal>
          ))}

          <Reveal scale delay={120} className="md:col-span-2">
            <article className="group relative h-full overflow-hidden rounded-[26px] bg-[#C8F169] p-7 transition-all duration-500 hover:-translate-y-1 hover:shadow-[0_24px_50px_-18px_rgba(140,180,40,0.6)] sm:p-8">
              <div className="relative flex flex-col gap-6 sm:flex-row sm:items-center">
                <span className="grid h-12 w-12 shrink-0 place-items-center rounded-2xl bg-[#0A0F0D] transition-transform group-hover:rotate-6">
                  <Code2 className="h-6 w-6 text-[#C8F169]" />
                </span>
                <div className="flex-1">
                  <h3 className="font-display text-[21px] font-bold">API and integrations</h3>
                  <p className="mt-1 text-[15px] leading-relaxed text-[#243012]/80">Create and manage codes from your own systems, and connect scan data to the tools your team already uses.</p>
                </div>
                <PageLink to="contact" className={`${btnBase} shrink-0 bg-[#0A0F0D] px-5 py-3 text-[14px] text-white`}>
                  Ask about the API <ArrowUpRight className="h-4 w-4" />
                </PageLink>
              </div>
            </article>
          </Reveal>
        </div>
      </div>
    </section>
  );
}

/* ================================================================== */
/*  Use cases                                                          */
/* ================================================================== */
function Showcase() {
  const { section } = useSiteNav();
  const [active, setActive] = useState(0);
  const s = SHOWCASE[active];
  return (
    <section id="showcase" className="scroll-mt-20 border-y border-black/[0.05] bg-[#F3F5EE] py-20 sm:py-28">
      <div className="mx-auto max-w-7xl px-4 sm:px-6">
        <div className="flex flex-col justify-between gap-6 lg:flex-row lg:items-end">
          <div className="max-w-xl">
            <Reveal>
              <span className="inline-flex rounded-full border border-black/[0.07] bg-white px-3 py-1.5 text-[12px] font-bold tracking-[0.18em]">USE CASES</span>
            </Reveal>
            <Reveal delay={80}>
              <h2 className="mt-5 font-display text-4xl font-extrabold leading-[1.05] tracking-[-0.02em] sm:text-5xl">
                One platform, every
                <br className="hidden sm:block" /> physical touchpoint.
              </h2>
            </Reveal>
          </div>
          <Reveal delay={140}>
            <p className="max-w-md text-lg leading-relaxed text-neutral-600">From table cards to packaging and posters — a few of the ways businesses put QR codes to work.</p>
          </Reveal>
        </div>

        <Reveal delay={120}>
          <div className="no-scrollbar -mx-4 mt-10 flex gap-2 overflow-x-auto px-4 pb-1 sm:mx-0 sm:px-0" role="tablist" aria-label="Industry use cases">
            {SHOWCASE.map((item, i) => (
              <button
                key={item.id}
                role="tab"
                aria-selected={active === i}
                onClick={() => setActive(i)}
                className={`inline-flex shrink-0 items-center gap-2 rounded-full px-5 py-3 text-[14px] font-semibold transition-all focus:outline-none focus-visible:ring-2 focus-visible:ring-[#00C389] ${
                  active === i ? 'scale-[1.02] bg-[#0A0F0D] text-white shadow-lg' : 'border border-black/[0.08] bg-white hover:border-black/30'
                }`}
              >
                <item.icon className="h-4 w-4" /> {item.label}
              </button>
            ))}
          </div>
        </Reveal>

        <div key={s.id} className="mt-6 grid items-stretch gap-6 lg:grid-cols-2 lg:gap-10">
          <Reveal scale className="relative">
            <figure className="group relative h-full min-h-[320px] overflow-hidden rounded-[26px] shadow-[0_30px_60px_-24px_rgba(10,15,13,0.4)] lg:min-h-[440px]">
              <img src={s.img} alt={s.alt} className="absolute inset-0 h-full w-full object-cover transition-transform duration-[1400ms] ease-out group-hover:scale-105" loading="lazy" />
              <div className="absolute inset-0 bg-black/15" aria-hidden="true" />
              <figcaption className="glass absolute bottom-4 left-4 rounded-full px-3.5 py-1.5 text-[12px] font-semibold text-neutral-700 shadow">Example setting · stock photo</figcaption>
            </figure>
          </Reveal>
          <Reveal delay={110}>
            <div className="flex h-full flex-col rounded-[26px] border border-black/[0.07] bg-white p-7 shadow-sm sm:p-10">
              <h3 className="font-display text-[28px] font-extrabold leading-[1.12] tracking-tight sm:text-[34px]">{s.title}</h3>
              <p className="mt-4 text-[16px] leading-relaxed text-neutral-600">{s.desc}</p>
              <ul className="mt-7 space-y-3.5">
                {s.bullets.map((b) => (
                  <li key={b} className="flex gap-3 text-[15px] font-medium">
                    <span className="grid h-6 w-6 shrink-0 place-items-center rounded-full bg-[#E6F8F1]">
                      <Check className="h-3.5 w-3.5 text-[#009E6E]" strokeWidth={3} />
                    </span>
                    {b}
                  </li>
                ))}
              </ul>
              <div className="mt-auto flex flex-wrap gap-3 pt-8">
                <button onClick={() => section('generator')} className={btn.dark}>
                  Create a QR code <ArrowIcon />
                </button>
                <PageLink to="contact" className={btn.outline}>
                  Talk to us
                </PageLink>
              </div>
            </div>
          </Reveal>
        </div>
      </div>
    </section>
  );
}

/* ================================================================== */
/*  QR code types + how it works                                       */
/* ================================================================== */
function Types() {
  const { section } = useSiteNav();
  const [selected, setSelected] = useState(0);
  const t = QR_TYPES[selected];
  return (
    <section id="types" className="scroll-mt-24 py-20 sm:py-28">
      <div className="mx-auto max-w-7xl px-4 sm:px-6">
        <SectionHeading
          label="QR CODE TYPES"
          title={
            <>
              If it matters, it can
              <br />
              start with a scan.
            </>
          }
          intro="Select a type to see what it is for. Most of them can be created with the free generator right now."
        />

        <div className="mt-12 grid items-start gap-6 lg:grid-cols-[1fr_380px]">
          <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 sm:gap-4">
            {QR_TYPES.map((item, i) => (
              <Reveal key={item.name} scale delay={(i % 3) * 70}>
                <button
                  onClick={() => setSelected(i)}
                  aria-pressed={selected === i}
                  className={`h-full w-full rounded-[20px] border p-5 text-left transition-all duration-300 focus:outline-none focus-visible:ring-2 focus-visible:ring-[#00C389] ${
                    selected === i
                      ? 'scale-[1.02] border-[#0A0F0D] bg-[#0A0F0D] text-white shadow-[0_20px_40px_-16px_rgba(10,15,13,0.5)]'
                      : 'border-black/[0.07] bg-white hover:-translate-y-1 hover:border-black/25 hover:shadow-lg'
                  }`}
                >
                  <div className="flex items-start justify-between gap-2">
                    <item.icon className={`h-6 w-6 ${selected === i ? 'text-[#C8F169]' : 'text-[#009E6E]'}`} />
                    {item.free && (
                      <span className={`rounded-full px-2 py-0.5 text-[10px] font-bold tracking-wider ${selected === i ? 'bg-white/10 text-[#C8F169]' : 'bg-[#E6F8F1] text-[#007A55]'}`}>FREE</span>
                    )}
                  </div>
                  <span className="mt-3.5 block font-display text-[15px] font-bold leading-snug">{item.name}</span>
                  <span className={`mt-1 hidden text-[12.5px] leading-relaxed sm:block ${selected === i ? 'text-white/60' : 'text-neutral-500'}`}>{item.desc}</span>
                </button>
              </Reveal>
            ))}
          </div>

          <Reveal scale delay={120} className="lg:sticky lg:top-28">
            <div className="rounded-[24px] border border-black/[0.06] bg-[#F3F5EE] p-7">
              <div className="flex items-center gap-3">
                <span className="grid h-12 w-12 shrink-0 place-items-center rounded-2xl bg-[#0A0F0D]">
                  <t.icon className="h-6 w-6 text-[#C8F169]" />
                </span>
                <div>
                  <h3 className="font-display text-lg font-bold leading-tight">{t.name}</h3>
                  <p className="mt-0.5 font-mono text-[11.5px] text-[#007A55]">{t.example}</p>
                </div>
              </div>
              <p className="mt-4 text-[15px] leading-relaxed text-neutral-600">
                {t.desc}{' '}
                {t.free
                  ? 'As a dynamic code, you can also change the destination after printing and see how often it is scanned.'
                  : 'This type needs a dynamic code, because the destination is decided at the moment of the scan.'}
              </p>
              <div className="mt-6 grid grid-cols-3 gap-2 text-center">
                {[
                  ['Dynamic', 'Editable'],
                  ['Tracked', 'Scan statistics'],
                  ['Branded', 'Your design'],
                ].map(([a, b]) => (
                  <div key={a} className="rounded-xl border border-black/[0.05] bg-white px-1 py-3">
                    <p className="font-display text-[13px] font-bold">{a}</p>
                    <p className="text-[11px] font-medium text-neutral-500">{b}</p>
                  </div>
                ))}
              </div>
              {t.free ? (
                <button onClick={() => section('generator')} className={`${btn.mint} mt-6 w-full`}>
                  Create this code free <ArrowIcon />
                </button>
              ) : (
                <PageLink to="contact" className={`${btn.dark} mt-6 w-full`}>
                  Ask about dynamic codes <ArrowIcon />
                </PageLink>
              )}
            </div>
          </Reveal>
        </div>

        <div className="mt-20 sm:mt-24">
          <Reveal>
            <h3 className="text-center font-display text-3xl font-extrabold tracking-tight sm:text-4xl">
              Three steps. <span className="text-neutral-400">Under a minute.</span>
            </h3>
          </Reveal>
          <div className="relative mt-10 grid gap-4 sm:gap-5 md:grid-cols-3">
            <div className="absolute left-[18%] right-[18%] top-[52px] hidden border-t-2 border-dashed border-black/15 md:block" aria-hidden="true" />
            {[
              { n: '01', icon: MousePointerClick, title: 'Create and customise', desc: 'Choose a code type, add your content, and pick a color and frame.' },
              { n: '02', icon: FolderDown, title: 'Download and share', desc: 'Export a PNG for screens or an SVG for print — packaging, signage, slides, and more.' },
              { n: '03', icon: BellRing, title: 'Track and improve', desc: 'With dynamic codes, watch scans come in and change the destination whenever you need to.' },
            ].map((step, i) => (
              <Reveal key={step.n} delay={i * 110}>
                <article className="group relative h-full rounded-[24px] border border-black/[0.07] bg-white p-7 text-center transition-all duration-500 hover:-translate-y-1 hover:shadow-[0_24px_48px_-20px_rgba(10,15,13,0.28)]">
                  <span className="relative z-10 mx-auto grid h-[72px] w-[72px] place-items-center rounded-[22px] bg-[#0A0F0D] shadow-xl transition-transform group-hover:-rotate-3 group-hover:scale-105">
                    <step.icon className="h-8 w-8 text-[#C8F169]" />
                  </span>
                  <span className="mt-5 block font-mono text-[12px] font-semibold tracking-widest text-[#009E6E]">STEP {step.n}</span>
                  <h4 className="mt-1.5 font-display text-xl font-bold">{step.title}</h4>
                  <p className="mt-2 text-[15px] leading-relaxed text-neutral-600">{step.desc}</p>
                </article>
              </Reveal>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}

/* ================================================================== */
/*  Analytics preview (clearly labelled sample data)                   */
/* ================================================================== */
function Analytics() {
  return (
    <section id="analytics" className="relative scroll-mt-20 overflow-hidden bg-[#0A0F0D] py-20 text-white sm:py-28">
      <div className="dot-grid-light absolute inset-0 opacity-30 [mask-image:radial-gradient(ellipse_65%_60%_at_80%_0%,black,transparent)]" aria-hidden="true" />
      <div className="absolute -bottom-32 -left-32 h-96 w-96 rounded-full bg-[#00C389]/15 blur-3xl" aria-hidden="true" />
      <div className="relative mx-auto max-w-7xl px-4 sm:px-6">
        <div className="grid items-center gap-12 lg:grid-cols-2 lg:gap-16">
          <div>
            <SectionHeading
              dark
              align="left"
              label={
                <>
                  <Eye className="h-3.5 w-3.5" /> ANALYTICS
                </>
              }
              title="Know what your print is doing."
              intro="Flyers, packaging, and signage used to be a black box. Dynamic codes attach simple, readable statistics to every physical asset, so you can see what gets scanned and when."
            />
            <div className="mt-8 space-y-2">
              {[
                { icon: Clock3, title: 'Scans over time', desc: 'See daily and hourly patterns so you know when people engage.' },
                { icon: MapPin, title: 'Location and device insights', desc: 'Understand roughly where scans happen and which devices people use.' },
                { icon: TrendingUp, title: 'Compare campaigns', desc: 'Put codes side by side to learn which placements and designs perform best.' },
                { icon: Users, title: 'Share with your team', desc: 'Export the data for colleagues, clients, or franchise partners.' },
              ].map((b, i) => (
                <Reveal key={b.title} delay={i * 80}>
                  <div className="group flex cursor-default gap-4 rounded-2xl border border-transparent p-4 transition-all hover:border-white/10 hover:bg-white/[0.05]">
                    <span className="grid h-11 w-11 shrink-0 place-items-center rounded-xl border border-white/10 bg-white/[0.07] transition-colors group-hover:bg-[#C8F169]">
                      <b.icon className="h-5 w-5 text-[#C8F169] transition-colors group-hover:text-[#0A0F0D]" />
                    </span>
                    <span>
                      <span className="block font-display font-bold">{b.title}</span>
                      <span className="mt-0.5 block text-[14px] leading-relaxed text-white/55">{b.desc}</span>
                    </span>
                  </div>
                </Reveal>
              ))}
            </div>
          </div>

          <Reveal scale delay={140}>
            <div className="glass-dark rounded-[26px] border border-white/12 p-5 shadow-[0_40px_90px_-30px_rgba(0,0,0,0.8)] sm:p-7" aria-label="Illustration of an analytics dashboard with sample data">
              <div className="flex items-center justify-between gap-3">
                <div className="flex items-center gap-2.5">
                  <span className="grid h-8 w-8 place-items-center rounded-lg bg-[#C8F169]">
                    <QrCode className="h-4.5 w-4.5 text-[#0A0F0D]" />
                  </span>
                  <div>
                    <p className="font-display text-[14px] font-bold leading-none">Example campaign</p>
                    <p className="mt-1 text-[11px] text-white/45">Illustration of the dashboard view</p>
                  </div>
                </div>
                <span className="rounded-full border border-white/15 bg-white/10 px-2.5 py-1 text-[11px] font-bold tracking-wider text-white/70">SAMPLE DATA</span>
              </div>
              <div className="mt-6 grid grid-cols-3 gap-3">
                <div className="rounded-2xl border border-white/[0.06] bg-white/[0.05] p-3.5">
                  <p className="font-display text-[22px] font-extrabold leading-none">
                    <CountUp end={48.2} decimals={1} suffix="k" />
                  </p>
                  <p className="mt-1.5 text-[11px] font-semibold text-white/45">TOTAL SCANS</p>
                </div>
                <div className="rounded-2xl border border-white/[0.06] bg-white/[0.05] p-3.5">
                  <p className="font-display text-[22px] font-extrabold leading-none">
                    <CountUp end={91} suffix="%" />
                  </p>
                  <p className="mt-1.5 text-[11px] font-semibold text-white/45">UNIQUE</p>
                </div>
                <div className="rounded-2xl border border-white/[0.06] bg-white/[0.05] p-3.5">
                  <p className="font-display text-[22px] font-extrabold leading-none">
                    7–9<span className="text-sm">pm</span>
                  </p>
                  <p className="mt-1.5 text-[11px] font-semibold text-white/45">PEAK HOURS</p>
                </div>
              </div>
              <div className="mt-3 rounded-2xl border border-white/[0.06] bg-white/[0.05] p-4" aria-hidden="true">
                <div className="flex justify-between text-[11px] font-semibold text-white/45">
                  <span>HOURLY SCANS</span>
                  <span className="text-[#C8F169]">Today</span>
                </div>
                <div className="mt-3 flex h-24 items-end gap-1.5">
                  {[18, 24, 20, 34, 46, 38, 52, 66, 58, 74, 92, 100, 84, 62].map((h, i) => (
                    <div key={i} className="bar-grow flex-1 rounded-t" style={{ height: `${h}%`, backgroundColor: h === 100 ? '#C8F169' : 'rgba(0,195,137,0.55)', animationDelay: `${i * 60}ms` }} />
                  ))}
                </div>
              </div>
              <ul className="mt-4 space-y-2.5 text-[13.5px]" aria-hidden="true">
                {[
                  ['Table card', 'iPhone · 2 min ago'],
                  ['Window poster', 'Android · 5 min ago'],
                  ['Flyer', 'iPhone · 9 min ago'],
                ].map(([source, meta]) => (
                  <li key={source} className="flex items-center gap-3 rounded-xl border border-white/[0.05] bg-white/[0.04] px-3.5 py-3">
                    <span className="h-2 w-2 rounded-full bg-[#00C389]" />
                    <span className="flex-1 font-semibold">{source}</span>
                    <span className="text-[11.5px] font-medium text-white/40">{meta}</span>
                  </li>
                ))}
              </ul>
              <PageLink to="contact" className={`${btn.lime} mt-5 w-full`}>
                Ask about analytics <ArrowIcon />
              </PageLink>
            </div>
          </Reveal>
        </div>
      </div>
    </section>
  );
}

/* ================================================================== */
/*  Reviews — hidden until real reviews exist; feedback form instead   */
/* ================================================================== */
function Reviews() {
  const [idx, setIdx] = useState(0);
  const hasReviews = reviews.length > 0;

  useEffect(() => {
    if (reviews.length < 2) return;
    const t = setInterval(() => setIdx((i) => (i + 1) % reviews.length), 7000);
    return () => clearInterval(t);
  }, []);

  if (!hasReviews) {
    return (
      <section id="reviews" className="scroll-mt-24 py-20 sm:py-28">
        <div className="mx-auto max-w-7xl px-4 sm:px-6">
          <div className="grid items-start gap-10 lg:grid-cols-[0.9fr_1.1fr] lg:gap-16">
            <div className="lg:sticky lg:top-28">
              <SectionHeading
                align="left"
                label="CUSTOMER FEEDBACK"
                title={
                  <>
                    Used {site.brand}?
                    <br />
                    Tell us how it went.
                  </>
                }
                intro="We only publish real reviews from real customers, with their permission. Share your experience and we may feature it here."
              />
              <Reveal delay={200}>
                <ul className="mt-8 space-y-3 text-[15px] text-neutral-600">
                  {['Your email address is never published.', 'We will ask before publishing anything.', 'You can withdraw permission at any time.'].map((t) => (
                    <li key={t} className="flex gap-3">
                      <span className="grid h-6 w-6 shrink-0 place-items-center rounded-full bg-[#E6F8F1]">
                        <Check className="h-3.5 w-3.5 text-[#009E6E]" strokeWidth={3} />
                      </span>
                      {t}
                    </li>
                  ))}
                </ul>
              </Reveal>
            </div>
            <Reveal scale delay={120}>
              <div className="rounded-[28px] border border-black/[0.07] bg-white p-6 shadow-[0_30px_70px_-28px_rgba(10,15,13,0.3)] sm:p-9">
                <FeedbackForm />
              </div>
            </Reveal>
          </div>
        </div>
      </section>
    );
  }

  const r = reviews[idx];
  return (
    <section id="reviews" className="scroll-mt-24 overflow-hidden py-20 sm:py-28">
      <div className="mx-auto max-w-7xl px-4 sm:px-6">
        <div className="flex flex-col justify-between gap-6 sm:flex-row sm:items-end">
          <SectionHeading align="left" label="CUSTOMER REVIEWS" title={`What customers say about ${site.brand}`} />
          {reviews.length > 1 && (
            <Reveal delay={120}>
              <div className="flex items-center gap-2">
                <button onClick={() => setIdx((idx - 1 + reviews.length) % reviews.length)} className="grid h-12 w-12 place-items-center rounded-full border border-black/12 transition-all hover:border-[#0A0F0D] hover:bg-[#0A0F0D] hover:text-white active:scale-95" aria-label="Previous review">
                  <ChevronLeft className="h-5 w-5" />
                </button>
                <button onClick={() => setIdx((idx + 1) % reviews.length)} className="grid h-12 w-12 place-items-center rounded-full border border-black/12 transition-all hover:border-[#0A0F0D] hover:bg-[#0A0F0D] hover:text-white active:scale-95" aria-label="Next review">
                  <ChevronRight className="h-5 w-5" />
                </button>
              </div>
            </Reveal>
          )}
        </div>
        <Reveal scale delay={100}>
          <div className="relative mt-10 overflow-hidden rounded-[28px] border border-black/[0.07] bg-white shadow-[0_30px_70px_-28px_rgba(10,15,13,0.35)]">
            <div className="absolute bottom-0 left-0 top-0 w-1.5 bg-[#00C389]" aria-hidden="true" />
            <div key={idx} className="animate-fade-up p-7 sm:p-12">
              {r.rating && (
                <div className="flex gap-0.5 text-amber-500" aria-label={`${r.rating} out of 5 stars`}>
                  {Array.from({ length: r.rating }).map((_, i) => (
                    <Star key={i} className="h-5 w-5 fill-current" />
                  ))}
                </div>
              )}
              <blockquote className="mt-5 max-w-3xl font-display text-[22px] font-semibold leading-[1.35] tracking-tight sm:text-[30px]">“{r.quote}”</blockquote>
              <div className="mt-8 flex flex-wrap items-center gap-4">
                <span className="grid h-12 w-12 place-items-center rounded-2xl bg-[#0A0F0D] font-display font-extrabold text-white sm:h-14 sm:w-14">
                  {r.name
                    .split(/\s+/)
                    .map((p) => p[0])
                    .join('')
                    .slice(0, 2)
                    .toUpperCase()}
                </span>
                <div>
                  <p className="font-display font-bold">{r.name}</p>
                  <p className="text-sm text-neutral-500">{[r.role, r.date].filter(Boolean).join(' · ')}</p>
                </div>
              </div>
            </div>
            {reviews.length > 1 && (
              <div className="flex gap-2 px-7 pb-7 sm:px-12">
                {reviews.map((item, i) => (
                  <button key={item.name + i} onClick={() => setIdx(i)} aria-label={`Show review from ${item.name}`} aria-current={i === idx} className={`h-2 rounded-full transition-all duration-500 ${i === idx ? 'w-10 bg-[#0A0F0D]' : 'w-2 bg-black/15 hover:bg-black/30'}`} />
                ))}
              </div>
            )}
          </div>
        </Reveal>
      </div>
    </section>
  );
}

/* ================================================================== */
/*  Pricing — prices are placeholders until confirmed                  */
/* ================================================================== */
function Pricing() {
  return (
    <section id="pricing" className="scroll-mt-20 border-y border-black/[0.05] bg-[#F3F5EE] py-20 sm:py-28">
      <div className="mx-auto max-w-7xl px-4 sm:px-6">
        <SectionHeading
          label="PRICING"
          title={
            <>
              Plans for every stage.
            </>
          }
          intro="Final prices and plan limits are being confirmed. Contact us and we will send you current details."
        />

        <div className="mx-auto mt-12 grid max-w-5xl items-stretch gap-5 lg:max-w-none lg:grid-cols-3">
          {plans.map((p, i) => (
            <Reveal key={p.name} scale delay={i * 100} className="h-full">
              <article
                className={`relative flex h-full flex-col rounded-[26px] p-7 transition-all duration-500 hover:-translate-y-1.5 sm:p-8 ${
                  p.highlighted ? 'bg-[#0A0F0D] text-white shadow-[0_35px_70px_-24px_rgba(10,15,13,0.6)]' : 'border border-black/[0.08] bg-white hover:shadow-[0_28px_55px_-22px_rgba(10,15,13,0.3)]'
                }`}
              >
                <h3 className="font-display text-xl font-extrabold">{p.name}</h3>
                <p className={`mt-1 text-sm ${p.highlighted ? 'text-white/55' : 'text-neutral-500'}`}>{p.description}</p>
                <div className="mt-6 flex items-end gap-2">
                  {isFilled(p.price) ? (
                    <span className="font-display text-[52px] font-extrabold leading-none tracking-tight">{p.price}</span>
                  ) : (
                    <Placeholder className="mb-1" />
                  )}
                  <span className={`pb-1 text-sm font-medium ${p.highlighted ? 'text-white/50' : 'text-neutral-500'}`}>{p.period}</span>
                </div>
                <PageLink to="contact" className={`mt-7 w-full ${p.highlighted ? btn.lime : btn.dark}`}>
                  Contact us about {p.name}
                </PageLink>
                <ul className="mt-8 space-y-3 text-[14.5px]">
                  {p.features.map((f) => (
                    <li key={f} className="flex gap-2.5">
                      <span className={`mt-px grid h-5 w-5 shrink-0 place-items-center rounded-full ${p.highlighted ? 'bg-[#C8F169]/15' : 'bg-[#E6F8F1]'}`}>
                        <Check className={`h-3 w-3 ${p.highlighted ? 'text-[#C8F169]' : 'text-[#009E6E]'}`} strokeWidth={3.5} />
                      </span>
                      <span className={p.highlighted ? 'text-white/85' : 'text-neutral-700'}>{f}</span>
                    </li>
                  ))}
                </ul>
                <p className={`mt-6 text-[13px] ${p.highlighted ? 'text-white/50' : 'text-neutral-500'}`}>
                  Limits: {isFilled(p.limits) ? p.limits : <Placeholder />}
                </p>
              </article>
            </Reveal>
          ))}
        </div>

        <Reveal delay={140}>
          <p className="mt-9 text-center text-sm font-medium text-neutral-500">
            Need something custom or have a question about a plan?{' '}
            <PageLink to="contact" className="font-semibold text-[#007A55] underline-offset-4 hover:underline">
              Contact us
            </PageLink>
            .
          </p>
        </Reveal>
      </div>
    </section>
  );
}

/* ================================================================== */
/*  FAQ                                                                */
/* ================================================================== */
function Faq() {
  const [open, setOpen] = useState<number | null>(0);
  return (
    <section id="faq" className="scroll-mt-24 py-20 sm:py-28">
      <div className="mx-auto grid max-w-7xl gap-10 px-4 sm:px-6 lg:grid-cols-[0.85fr_1.15fr] lg:gap-16">
        <div className="self-start lg:sticky lg:top-28">
          <SectionHeading align="left" label="QUESTIONS" title="Common questions about QR codes." intro="Did not find what you were looking for? Send us a message and we will help." />
          <Reveal delay={210}>
            <PageLink to="contact" className={`${btn.dark} mt-6`}>
              Contact us <ArrowUpRight className="h-4 w-4" />
            </PageLink>
          </Reveal>
        </div>
        <div className="space-y-3">
          {FAQS.map((f, i) => {
            const isOpen = open === i;
            return (
              <Reveal key={f.q} delay={i * 55}>
                <div className={`overflow-hidden rounded-[20px] border transition-all duration-400 ${isOpen ? 'border-black/[0.12] bg-white shadow-[0_20px_45px_-20px_rgba(10,15,13,0.3)]' : 'border-black/[0.07] bg-white/60 hover:border-black/20 hover:bg-white'}`}>
                  <button onClick={() => setOpen(isOpen ? null : i)} aria-expanded={isOpen} aria-controls={`faq-${i}`} className="flex w-full items-center gap-4 px-6 py-5 text-left focus:outline-none focus-visible:ring-2 focus-visible:ring-inset focus-visible:ring-[#00C389]">
                    <span className="flex-1 font-display text-[16px] font-bold leading-snug sm:text-[17px]">{f.q}</span>
                    <span className={`grid h-8 w-8 shrink-0 place-items-center rounded-full transition-all duration-400 ${isOpen ? 'rotate-180 bg-[#0A0F0D] text-[#C8F169]' : 'bg-black/[0.05]'}`}>{isOpen ? <Minus className="h-4 w-4" /> : <Plus className="h-4 w-4" />}</span>
                  </button>
                  <div id={`faq-${i}`} className={`grid transition-all duration-500 ease-out ${isOpen ? 'grid-rows-[1fr] opacity-100' : 'grid-rows-[0fr] opacity-0'}`}>
                    <div className="overflow-hidden">
                      <p className="px-6 pb-6 text-[15px] leading-relaxed text-neutral-600">{f.a}</p>
                    </div>
                  </div>
                </div>
              </Reveal>
            );
          })}
        </div>
      </div>
    </section>
  );
}

/* ================================================================== */
/*  Final call to action                                               */
/* ================================================================== */
function FinalCta() {
  const { section } = useSiteNav();
  return (
    <section className="pb-20 pt-2 sm:pb-28">
      <div className="mx-auto max-w-7xl px-4 sm:px-6">
        <Reveal scale>
          <div className="relative overflow-hidden rounded-[32px] bg-[#0A0F0D] px-6 py-14 text-center text-white shadow-[0_45px_90px_-30px_rgba(10,15,13,0.65)] sm:p-16">
            <div className="dot-grid-light absolute inset-0 opacity-35 [mask-image:radial-gradient(ellipse_60%_70%_at_50%_40%,black,transparent)]" aria-hidden="true" />
            <div className="absolute -top-24 left-1/2 h-[280px] w-[480px] -translate-x-1/2 rounded-full bg-[#00C389]/20 blur-3xl" aria-hidden="true" />
            <div className="absolute left-8 top-8 hidden rotate-[-6deg] grid-cols-5 gap-1.5 opacity-25 md:grid" aria-hidden="true">
              {Array.from({ length: 25 }).map((_, i) => (
                <span key={i} className={`h-3 w-3 rounded-[3px] ${[0, 1, 4, 6, 12, 18, 20, 24].includes(i) ? 'bg-[#C8F169]' : 'bg-white/50'}`} />
              ))}
            </div>
            <div className="absolute bottom-8 right-8 hidden rotate-[8deg] grid-cols-5 gap-1.5 opacity-25 md:grid" aria-hidden="true">
              {Array.from({ length: 25 }).map((_, i) => (
                <span key={i} className={`h-3 w-3 rounded-[3px] ${[2, 5, 9, 13, 17, 21].includes(i) ? 'bg-[#C8F169]' : 'bg-white/50'}`} />
              ))}
            </div>
            <div className="relative mx-auto max-w-2xl">
              <h2 className="font-display text-[38px] font-extrabold leading-[1.02] tracking-[-0.025em] sm:text-[54px]">Your next customer is already pointing their camera.</h2>
              <p className="mx-auto mt-5 max-w-xl text-lg leading-relaxed text-white/65">Create a QR code with the free generator, or get in touch to talk about dynamic codes for your business.</p>
              <div className="mt-9 flex flex-col justify-center gap-3 sm:flex-row">
                <button onClick={() => section('generator')} className={`${btn.lime} px-8 py-4 text-[15px]`}>
                  Create my free QR code <ArrowIcon />
                </button>
                <PageLink to="contact" className={`${btn.outlineLight} px-8 py-4 text-[15px]`}>
                  Contact us
                </PageLink>
              </div>
              <p className="mt-5 text-[13px] font-medium text-white/40">Free generator · No sign-up required</p>
            </div>
          </div>
        </Reveal>
      </div>
    </section>
  );
}

export default function Home() {
  return (
    <>
      <Hero />
      <SocialProof />
      <Features />
      <Showcase />
      <Types />
      <Analytics />
      <Reviews />
      <Pricing />
      <Faq />
      <FinalCta />
    </>
  );
}
