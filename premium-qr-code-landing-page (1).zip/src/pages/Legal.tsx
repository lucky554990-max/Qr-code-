import type { ReactNode } from 'react';
import { AlertTriangle } from 'lucide-react';
import { isFilled, site } from '../config/site';
import { Info, PageHero, Placeholder, Reveal } from '../lib/ui';
import { PageLink } from '../lib/nav';

/* ------------------------------------------------------------------ */
/*  Shared building blocks                                             */
/* ------------------------------------------------------------------ */
function TemplateNotice() {
  return (
    <div role="note" className="flex items-start gap-3 rounded-2xl border border-amber-500/40 bg-amber-50 p-5 text-[14px] leading-relaxed text-amber-900">
      <AlertTriangle className="mt-0.5 h-5 w-5 shrink-0" />
      <p>
        <strong>Template notice.</strong> This page is a starting template, not legal advice. Replace every <Placeholder /> marker, delete anything that does not apply to your
        business, and have the final text reviewed by a legal professional before publishing. Remove this notice when you are done.
      </p>
    </div>
  );
}

function LegalLayout({ label, title, updated, children }: { label: string; title: string; updated: string; children: ReactNode }) {
  return (
    <>
      <PageHero label={label} title={title} intro={<>Last updated: <Info value={updated} /></>} />
      <section className="py-14 sm:py-20">
        <div className="mx-auto max-w-3xl px-4 sm:px-6">
          <Reveal>
            <TemplateNotice />
          </Reveal>
          <div className="mt-10 space-y-10">{children}</div>
          <Reveal>
            <p className="mt-14 border-t border-black/[0.07] pt-6 text-sm text-neutral-500">
              Questions about this page? <PageLink to="contact" className="font-semibold text-[#007A55] underline-offset-4 hover:underline">Contact us</PageLink>.
            </p>
          </Reveal>
        </div>
      </section>
    </>
  );
}

function Block({ title, children }: { title: string; children: ReactNode }) {
  return (
    <Reveal>
      <section className="space-y-3 text-[15.5px] leading-relaxed text-neutral-700 [&_ul]:list-disc [&_ul]:space-y-1.5 [&_ul]:pl-5">
        <h2 className="font-display text-xl font-bold text-[#0A0F0D] sm:text-2xl">{title}</h2>
        {children}
      </section>
    </Reveal>
  );
}

const company = () => (isFilled(site.legalName) ? site.legalName : <Placeholder />);

/* ------------------------------------------------------------------ */
/*  Privacy Policy                                                     */
/* ------------------------------------------------------------------ */
export function PrivacyPage() {
  return (
    <LegalLayout label="LEGAL" title="Privacy Policy" updated={site.privacyUpdated}>
      <Block title="1. Who we are">
        <p>
          This Privacy Policy explains how {company()} ("{site.brand}", "we", "us") handles personal information when you use our website at <Info value={site.websiteUrl} /> (the "Site").
          If you have any questions, contact us at <Info value={site.contactEmail} href={isFilled(site.contactEmail) ? `mailto:${site.contactEmail}` : undefined} />.
        </p>
      </Block>

      <Block title="2. Information we collect">
        <p>
          <strong>Information you give us.</strong> When you use the contact or feedback forms we receive the details you enter: your name, email address, company or role (optional),
          your message, and — for feedback — an optional rating and whether you allow us to publish your review.
        </p>
        <p>
          <strong>Free QR code generator.</strong> The content you type into the generator (for example a web address, WiFi name, or contact details) is processed locally in your
          browser to draw the code. It is not transmitted to or stored on our servers.
        </p>
        <p>
          <strong>Automatically collected data.</strong> <Placeholder /> — describe any server logs, analytics tools, or cookies you use. If you use none, say so here.
        </p>
      </Block>

      <Block title="3. How we use information">
        <ul>
          <li>To reply to your enquiries and provide the services you ask for.</li>
          <li>To publish customer reviews on the Site — only when you have given permission, and only with the name and role you provided.</li>
          <li>To keep the Site secure and to comply with legal obligations.</li>
        </ul>
        <p>
          Legal basis (where GDPR or similar laws apply): <Placeholder /> — typically your consent, our legitimate interest in responding to you, or the performance of a contract.
        </p>
      </Block>

      <Block title="4. How form submissions are delivered">
        <p>
          {site.formEndpoint.trim() ? (
            <>
              Form submissions are delivered through a third-party form service, {isFilled(site.formProviderName) ? site.formProviderName : <Placeholder />}, which processes them on our
              behalf. Please refer to that provider's privacy policy for details of its processing.
            </>
          ) : (
            <>
              Submitting a form opens your own email application with the message pre-filled. The message is sent by you, directly to{' '}
              <Info value={site.contactEmail} />, and is handled by your email provider and ours.
            </>
          )}
        </p>
      </Block>

      <Block title="5. Third-party content">
        <p>
          The Site loads web fonts from Google Fonts and example photographs from the Pexels content network. Your browser requests these files directly from those providers, which
          means they receive your IP address and standard request information. <Placeholder /> — list any other third-party services (for example analytics or embedded media).
        </p>
      </Block>

      <Block title="6. Sharing of information">
        <p>
          We do not sell personal information. We share it only with service providers that help us run the Site (such as hosting, email, or form providers), when required by law, or to
          protect our rights.
        </p>
      </Block>

      <Block title="7. Retention">
        <p>
          <Placeholder /> — state how long you keep enquiries, feedback, and published reviews (for example: "We keep enquiries for 12 months after our last contact with you").
        </p>
      </Block>

      <Block title="8. Your rights">
        <p>
          Depending on where you live, you may have the right to access, correct, delete, or restrict the use of your personal information, to object to processing, to data portability,
          and to withdraw consent at any time (for example, to have a published review removed). To exercise these rights, contact us at <Info value={site.contactEmail} />. You may also
          have the right to lodge a complaint with your local data protection authority.
        </p>
      </Block>

      <Block title="9. Children">
        <p>
          The Site is not directed at children under the age of <Info value={site.minimumAge} />, and we do not knowingly collect personal information from them.
        </p>
      </Block>

      <Block title="10. Changes to this policy">
        <p>We may update this policy from time to time. We will post the new version on this page and update the "Last updated" date above.</p>
      </Block>

      <Block title="11. Contact">
        <p>
          {company()}
          <br />
          <Info value={site.address} />
          <br />
          <Info value={site.contactEmail} href={isFilled(site.contactEmail) ? `mailto:${site.contactEmail}` : undefined} />
        </p>
      </Block>
    </LegalLayout>
  );
}

/* ------------------------------------------------------------------ */
/*  Terms of Service                                                   */
/* ------------------------------------------------------------------ */
export function TermsPage() {
  return (
    <LegalLayout label="LEGAL" title="Terms of Service" updated={site.termsUpdated}>
      <Block title="1. Agreement">
        <p>
          These Terms of Service ("Terms") govern your use of the website at <Info value={site.websiteUrl} /> (the "Site") and the services offered on it, operated by {company()} ("
          {site.brand}", "we", "us"). By using the Site you agree to these Terms. If you do not agree, please do not use the Site.
        </p>
      </Block>

      <Block title="2. The service">
        <p>
          The Site provides a free QR code generator that runs in your browser, information about dynamic QR codes and related services, and ways to contact us.{' '}
          <Placeholder /> — if you offer paid plans or an online account, describe them here or link to their specific terms.
        </p>
      </Block>

      <Block title="3. Accounts and payments">
        <p>
          <Placeholder /> — if applicable, describe how accounts are created, billing cycles, renewals, refunds, cancellation, and what happens to dynamic codes when a subscription
          ends. Delete this section if you do not offer paid services.
        </p>
      </Block>

      <Block title="4. Acceptable use">
        <p>You agree not to use the Site or any QR code created with it to:</p>
        <ul>
          <li>link to or distribute content that is unlawful, misleading, defamatory, or infringes the rights of others;</li>
          <li>carry out phishing, distribute malware, or otherwise harm people or systems;</li>
          <li>interfere with the operation or security of the Site; or</li>
          <li>misrepresent who you are or who a QR code belongs to.</li>
        </ul>
      </Block>

      <Block title="5. Your content">
        <p>
          You keep all rights to the content you encode in a QR code or submit through our forms. You are responsible for that content, for having the right to use it, and for the
          destinations your codes point to.
        </p>
      </Block>

      <Block title="6. Reviews and feedback">
        <p>
          If you submit a review and give permission to publish it, you grant us a non-exclusive, royalty-free licence to display it on the Site together with the name and role you
          provided. You can withdraw this permission at any time by contacting us, and we will remove the review within a reasonable time.
        </p>
      </Block>

      <Block title="7. Intellectual property">
        <p>
          The design, text, graphics, and software of the Site belong to {company()} or its licensors and are protected by applicable intellectual property laws. QR codes you create with
          the free generator are yours to use for any lawful purpose.
        </p>
      </Block>

      <Block title="8. Disclaimer">
        <p>
          The Site and the free generator are provided "as is" and "as available", without warranties of any kind to the extent permitted by law. Whether a QR code scans reliably
          depends on factors outside our control, such as print size, contrast, and the scanning device. Always test a code before printing it in volume.
        </p>
      </Block>

      <Block title="9. Limitation of liability">
        <p>
          To the fullest extent permitted by law, {company()} will not be liable for any indirect, incidental, special, or consequential loss, or for any loss of profits, revenue, or data,
          arising from your use of the Site. <Placeholder /> — confirm the appropriate limitation wording and any caps with a legal professional for your jurisdiction.
        </p>
      </Block>

      <Block title="10. Termination">
        <p>We may suspend or end your access to the Site if you breach these Terms or misuse the service.</p>
      </Block>

      <Block title="11. Governing law">
        <p>
          These Terms are governed by <Info value={site.governingLaw} />, and any disputes will be subject to the exclusive jurisdiction of the courts there, unless mandatory consumer
          law in your country provides otherwise.
        </p>
      </Block>

      <Block title="12. Changes to these Terms">
        <p>We may update these Terms from time to time. The current version will always be available on this page, with the "Last updated" date shown above.</p>
      </Block>

      <Block title="13. Contact">
        <p>
          {company()}
          <br />
          <Info value={site.address} />
          <br />
          <Info value={site.contactEmail} href={isFilled(site.contactEmail) ? `mailto:${site.contactEmail}` : undefined} />
        </p>
      </Block>
    </LegalLayout>
  );
}
