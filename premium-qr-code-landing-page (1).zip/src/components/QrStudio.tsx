import { useCallback, useEffect, useMemo, useRef, useState, type Dispatch, type ReactNode, type SetStateAction } from 'react';
import {
  ArrowLeftRight,
  ArrowRight,
  Download,
  Eye,
  FileCode2,
  Frame as FrameIcon,
  Image as ImageIcon,
  ImagePlus,
  LayoutGrid,
  Loader2,
  Palette,
  RotateCcw,
  Shapes,
  ShieldCheck,
  Trash2,
  Upload,
  X,
} from 'lucide-react';
import { contrastRatio, fillStops, idealTextColor, minContrast, normalizeHex } from '../qr/color';
import { dotGlyphSvg, eyeGlyphSvg, type RenderInfo } from '../qr/engine';
import { fileToDataUrl, useMediaQuery, type DownloadKind, type Downloads } from '../qr/hooks';
import { CATEGORY_LABELS, STYLE_PRESETS, applyPreset, findPreset, type StyleCategory } from '../qr/presets';
import { DOT_SHAPES, EYE_LABELS, EYE_SHAPES, FRAME_STYLES, FRAME_TEXTS, type EyeKey, type EyeShape, type Fill, type FrameOptions, type QrDesign } from '../qr/types';
import type { ScanStatus } from '../qr/verify';
import { inputCls } from '../lib/ui';
import { QrPreview, ScanBadge, StyleThumb } from './QrWidgets';

export type StudioTab = 'styles' | 'shape' | 'eyes' | 'colors' | 'logo' | 'frame' | 'background';
const TABS: { id: StudioTab; label: string; icon: typeof LayoutGrid }[] = [
  { id: 'styles', label: 'Styles', icon: LayoutGrid },
  { id: 'shape', label: 'Shape', icon: Shapes },
  { id: 'eyes', label: 'Eyes', icon: Eye },
  { id: 'colors', label: 'Colors', icon: Palette },
  { id: 'logo', label: 'Logo', icon: ImagePlus },
  { id: 'frame', label: 'Frame', icon: FrameIcon },
  { id: 'background', label: 'Background', icon: ImageIcon },
];

type Patch = (p: Partial<QrDesign>) => void;
const pct = (v: number) => `${Math.round(v * 100)}%`;

/* ------------------------------------------------------------------ */
/*  Design helpers shared with the generator card                      */
/* ------------------------------------------------------------------ */
export function autoFixDesign(d: QrDesign): QrDesign {
  return {
    ...d,
    fg: { mode: 'solid', from: '#0A0F0D', to: '#0A0F0D', angle: d.fg.angle },
    eyeColor: null,
    bgColor: '#FFFFFF',
    bgImageOpacity: Math.min(d.bgImageOpacity, 0.2),
    glow: Math.min(d.glow, 0.3),
    dotScale: Math.max(d.dotScale, 0.85),
    frame: d.frame.style !== 'none' ? { ...d.frame, color: '#0A0F0D', textColor: '#FFFFFF' } : d.frame,
  };
}

export function swapDesignColors(d: QrDesign): QrDesign {
  const first = fillStops(d.fg)[0].color;
  return { ...d, fg: { mode: 'solid', from: d.bgColor, to: d.bgColor, angle: d.fg.angle }, bgColor: first, eyeColor: null, transparent: false };
}

/* ------------------------------------------------------------------ */
/*  Small form controls                                                */
/* ------------------------------------------------------------------ */
function Field({ label, hint, children }: { label: string; hint?: string; children: ReactNode }) {
  return (
    <div>
      <p className="mb-2 text-[13px] font-semibold">{label}</p>
      {children}
      {hint && <p className="mt-2 text-[12px] leading-relaxed text-neutral-500">{hint}</p>}
    </div>
  );
}

function Chips<T extends string>({ options, value, onChange, disabled }: { options: ReadonlyArray<{ value: T; label: string }>; value: T; onChange: (v: T) => void; disabled?: boolean }) {
  return (
    <div className="flex flex-wrap gap-1.5" role="radiogroup">
      {options.map((o) => (
        <button
          key={o.value}
          type="button"
          role="radio"
          aria-checked={value === o.value}
          disabled={disabled}
          onClick={() => onChange(o.value)}
          className={`rounded-full border px-3 py-1.5 text-[12.5px] font-semibold transition focus:outline-none focus-visible:ring-2 focus-visible:ring-[#00C389] disabled:opacity-50 ${
            value === o.value ? 'border-[#0A0F0D] bg-[#0A0F0D] text-white' : 'border-black/15 bg-white hover:border-black/35'
          }`}
        >
          {o.label}
        </button>
      ))}
    </div>
  );
}

function ShapeGrid<T extends string>({ options, value, onChange }: { options: ReadonlyArray<{ value: T; label: string; glyph: string }>; value: T; onChange: (v: T) => void }) {
  return (
    <div className="grid grid-cols-4 gap-2 sm:grid-cols-5 md:grid-cols-6 xl:grid-cols-8" role="radiogroup">
      {options.map((o) => {
        const selected = value === o.value;
        return (
          <button
            key={o.value}
            type="button"
            role="radio"
            aria-checked={selected}
            aria-label={o.label}
            onClick={() => onChange(o.value)}
            className={`flex flex-col items-center gap-1.5 rounded-2xl border p-2 transition focus:outline-none focus-visible:ring-2 focus-visible:ring-[#00C389] ${
              selected ? 'border-[#0A0F0D] bg-[#0A0F0D] text-white shadow-md' : 'border-black/[0.08] bg-white text-[#0A0F0D] hover:-translate-y-0.5 hover:border-black/30'
            }`}
          >
            <span className="h-9 w-9" dangerouslySetInnerHTML={{ __html: o.glyph }} />
            <span className="text-[10.5px] font-semibold leading-tight">{o.label}</span>
          </button>
        );
      })}
    </div>
  );
}

function ColorField({ label, value, onChange, disabled, hint }: { label: string; value: string; onChange: (v: string) => void; disabled?: boolean; hint?: string }) {
  const [text, setText] = useState(value);
  useEffect(() => setText(value), [value]);
  const commit = () => {
    const hex = normalizeHex(text);
    if (hex) onChange(hex);
    else setText(value);
  };
  const pickerValue = (normalizeHex(value) ?? '#000000').toLowerCase();
  return (
    <div className={disabled ? 'opacity-50' : ''}>
      <p className="mb-1.5 text-[13px] font-semibold">{label}</p>
      <div className="flex items-center gap-2 rounded-xl border border-black/10 bg-white p-1.5 pr-3 focus-within:border-[#00C389] focus-within:ring-4 focus-within:ring-[#00C389]/15">
        <span className="relative h-8 w-8 shrink-0 overflow-hidden rounded-lg border border-black/10" style={{ background: value }}>
          <input type="color" value={pickerValue} disabled={disabled} onChange={(e) => onChange(e.target.value.toUpperCase())} aria-label={`${label} picker`} className="absolute inset-0 h-full w-full cursor-pointer opacity-0 disabled:cursor-not-allowed" />
        </span>
        <input
          value={text}
          disabled={disabled}
          onChange={(e) => setText(e.target.value)}
          onBlur={commit}
          onKeyDown={(e) => e.key === 'Enter' && commit()}
          aria-label={`${label} hex value`}
          spellCheck={false}
          className="w-full min-w-0 bg-transparent font-mono text-[13px] font-semibold uppercase outline-none"
        />
      </div>
      {hint && <p className="mt-1.5 text-[12px] text-neutral-500">{hint}</p>}
    </div>
  );
}

function Slider({ label, value, min, max, step, format, onChange, disabled, hint }: { label: string; value: number; min: number; max: number; step: number; format: (v: number) => string; onChange: (v: number) => void; disabled?: boolean; hint?: string }) {
  return (
    <div className={disabled ? 'opacity-50' : ''}>
      <div className="mb-1.5 flex items-center justify-between text-[13px]">
        <span className="font-semibold">{label}</span>
        <span className="font-mono text-[12px] text-neutral-500">{format(value)}</span>
      </div>
      <input type="range" min={min} max={max} step={step} value={value} disabled={disabled} onChange={(e) => onChange(Number(e.target.value))} aria-label={label} className="w-full accent-[#00C389] disabled:cursor-not-allowed" />
      {hint && <p className="mt-1.5 text-[12px] leading-relaxed text-neutral-500">{hint}</p>}
    </div>
  );
}

function Switch({ label, checked, onChange, hint, disabled }: { label: string; checked: boolean; onChange: (v: boolean) => void; hint?: string; disabled?: boolean }) {
  return (
    <div className={`flex items-start justify-between gap-4 rounded-2xl border border-black/[0.07] bg-white px-4 py-3 ${disabled ? 'opacity-50' : ''}`}>
      <div>
        <p className="text-[13.5px] font-semibold">{label}</p>
        {hint && <p className="mt-0.5 text-[12px] leading-relaxed text-neutral-500">{hint}</p>}
      </div>
      <button
        type="button"
        role="switch"
        aria-checked={checked}
        aria-label={label}
        disabled={disabled}
        onClick={() => onChange(!checked)}
        className={`relative mt-0.5 h-6 w-11 shrink-0 rounded-full transition focus:outline-none focus-visible:ring-2 focus-visible:ring-[#00C389] focus-visible:ring-offset-2 ${checked ? 'bg-[#00C389]' : 'bg-neutral-300'}`}
      >
        <span className={`absolute top-0.5 h-5 w-5 rounded-full bg-white shadow transition-all ${checked ? 'left-[22px]' : 'left-0.5'}`} />
      </button>
    </div>
  );
}

function UploadField({ label, value, onChange, hint, disabled }: { label: string; value: string | null; onChange: (v: string | null) => void; hint?: string; disabled?: boolean }) {
  const inputRef = useRef<HTMLInputElement>(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const handle = async (file?: File) => {
    if (!file) return;
    if (file.size > 3 * 1024 * 1024) {
      setError('Please choose an image under 3 MB.');
      return;
    }
    setBusy(true);
    setError(null);
    try {
      onChange(await fileToDataUrl(file));
    } catch {
      setError('That file could not be read. Try a PNG, JPG, SVG or WebP image.');
    } finally {
      setBusy(false);
      if (inputRef.current) inputRef.current.value = '';
    }
  };
  return (
    <div className={disabled ? 'opacity-50' : ''}>
      <p className="mb-2 text-[13px] font-semibold">{label}</p>
      <div className="flex items-center gap-3">
        <span className="checker grid h-16 w-16 shrink-0 place-items-center overflow-hidden rounded-xl border border-black/10">
          {value ? <img src={value} alt="" className="h-full w-full object-contain" /> : <ImageIcon className="h-5 w-5 text-neutral-400" />}
        </span>
        <div className="flex flex-wrap gap-2">
          <button
            type="button"
            disabled={disabled || busy}
            onClick={() => inputRef.current?.click()}
            className="inline-flex items-center gap-1.5 rounded-full bg-[#0A0F0D] px-4 py-2 text-[12.5px] font-semibold text-white transition hover:-translate-y-px focus:outline-none focus-visible:ring-2 focus-visible:ring-[#00C389] disabled:opacity-50"
          >
            {busy ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Upload className="h-3.5 w-3.5" />}
            {busy ? 'Reading…' : value ? 'Replace image' : 'Upload image'}
          </button>
          {value && (
            <button type="button" onClick={() => onChange(null)} className="inline-flex items-center gap-1.5 rounded-full border border-black/15 px-4 py-2 text-[12.5px] font-semibold transition hover:border-black/40">
              <Trash2 className="h-3.5 w-3.5" /> Remove
            </button>
          )}
        </div>
        <input ref={inputRef} type="file" accept="image/png,image/jpeg,image/svg+xml,image/webp" className="hidden" onChange={(e) => handle(e.target.files?.[0])} aria-label={label} />
      </div>
      {error ? <p className="mt-2 text-[12px] font-medium text-red-700">{error}</p> : hint ? <p className="mt-2 text-[12px] leading-relaxed text-neutral-500">{hint}</p> : null}
    </div>
  );
}

function Note({ children }: { children: ReactNode }) {
  return (
    <p className="flex items-start gap-2 rounded-2xl bg-[#E6F8F1] px-4 py-3 text-[12.5px] leading-relaxed text-[#06513A]">
      <ShieldCheck className="mt-0.5 h-4 w-4 shrink-0" />
      <span>{children}</span>
    </p>
  );
}

/* ------------------------------------------------------------------ */
/*  Panels                                                             */
/* ------------------------------------------------------------------ */
function StylesPanel({ design, setDesign }: { design: QrDesign; setDesign: Dispatch<SetStateAction<QrDesign>> }) {
  const [category, setCategory] = useState<'all' | StyleCategory>('all');
  const list = STYLE_PRESETS.filter((p) => category === 'all' || p.category === category);
  return (
    <div className="space-y-4">
      <Chips options={[{ value: 'all', label: `All styles (${STYLE_PRESETS.length})` }, ...(Object.keys(CATEGORY_LABELS) as StyleCategory[]).map((c) => ({ value: c, label: CATEGORY_LABELS[c] }))]} value={category} onChange={setCategory} />
      <div className="grid grid-cols-3 gap-3 sm:grid-cols-4 xl:grid-cols-5">
        {list.map((p) => (
          <StyleThumb key={p.id} preset={p} selected={design.styleId === p.id} onSelect={() => setDesign((d) => applyPreset(d, p))} />
        ))}
      </div>
      <Note>Switching styles keeps your content, uploaded logo and background image. Every style is a real, working QR code — the scan test runs again after each change.</Note>
    </div>
  );
}

function ShapePanel({ design, patch }: { design: QrDesign; patch: Patch }) {
  const options = useMemo(() => DOT_SHAPES.map((s) => ({ ...s, glyph: dotGlyphSvg(s.value) })), []);
  const liquid = design.dots === 'liquid';
  return (
    <div className="space-y-6">
      <Field label="Dot shape" hint="How each data module is drawn. The three eyes are styled on the Eyes tab.">
        <ShapeGrid options={options} value={design.dots} onChange={(v) => patch({ dots: v })} />
      </Field>
      <Slider
        label="Pattern size"
        value={liquid ? 1 : design.dotScale}
        min={0.7}
        max={1}
        step={0.01}
        format={pct}
        disabled={liquid}
        onChange={(v) => patch({ dotScale: v })}
        hint={liquid ? 'Liquid modules always connect at full size.' : 'Smaller modules look lighter. Stay at 80% or above for the most reliable scans.'}
      />
      <Field label="Error correction" hint="Higher levels survive more damage or a larger logo, but make the code denser. Auto uses M, Q for light patterns, or H whenever a logo is added.">
        <Chips
          options={[
            { value: 'auto', label: 'Auto' },
            { value: 'L', label: 'L · 7%' },
            { value: 'M', label: 'M · 15%' },
            { value: 'Q', label: 'Q · 25%' },
            { value: 'H', label: 'H · 30%' },
          ]}
          value={design.ec}
          onChange={(v) => patch({ ec: v })}
          disabled={!!design.logo}
        />
        {design.logo && <p className="mt-2 text-[12px] text-neutral-500">A logo is in use, so level H is applied automatically.</p>}
      </Field>
    </div>
  );
}

function EyesPanel({ design, patch, setDesign }: { design: QrDesign; patch: Patch; setDesign: Dispatch<SetStateAction<QrDesign>> }) {
  const frameOptions = useMemo(() => EYE_SHAPES.map((s) => ({ ...s, glyph: eyeGlyphSvg(s.value, s.value) })), []);
  const ballOptions = useMemo(() => EYE_SHAPES.map((s) => ({ ...s, glyph: eyeGlyphSvg('square', s.value) })), []);
  const setEye = (key: EyeKey | 'all', part: 'frame' | 'ball', v: EyeShape) =>
    setDesign((d) => (key === 'all' ? { ...d, eye: { ...d.eye, [part]: v } } : { ...d, eyes: { ...d.eyes, [key]: { ...d.eyes[key], [part]: v } } }));
  return (
    <div className="space-y-6">
      {!design.eyesIndependent ? (
        <>
          <Field label="Corner square shape" hint="The outer ring of each finder pattern.">
            <ShapeGrid options={frameOptions} value={design.eye.frame} onChange={(v) => setEye('all', 'frame', v)} />
          </Field>
          <Field label="Corner dot shape" hint="The solid center of each finder pattern.">
            <ShapeGrid options={ballOptions} value={design.eye.ball} onChange={(v) => setEye('all', 'ball', v)} />
          </Field>
        </>
      ) : (
        <div className="space-y-3">
          {(['tl', 'tr', 'bl'] as EyeKey[]).map((k) => (
            <div key={k} className="rounded-2xl border border-black/[0.07] bg-white p-4">
              <div className="flex items-center gap-3">
                <span className="h-9 w-9 shrink-0 text-[#0A0F0D]" dangerouslySetInnerHTML={{ __html: eyeGlyphSvg(design.eyes[k].frame, design.eyes[k].ball) }} />
                <p className="font-display text-[14px] font-bold">{EYE_LABELS[k]}</p>
              </div>
              <div className="mt-3 grid gap-3 sm:grid-cols-2">
                <Field label="Corner square">
                  <Chips options={EYE_SHAPES} value={design.eyes[k].frame} onChange={(v) => setEye(k, 'frame', v)} />
                </Field>
                <Field label="Corner dot">
                  <Chips options={EYE_SHAPES} value={design.eyes[k].ball} onChange={(v) => setEye(k, 'ball', v)} />
                </Field>
              </div>
            </div>
          ))}
        </div>
      )}
      <Switch
        label="Style each eye separately"
        hint="Choose a different shape for the top-left, top-right and bottom-left eyes."
        checked={design.eyesIndependent}
        onChange={(on) => setDesign((d) => ({ ...d, eyesIndependent: on, eyes: on && !d.eyesIndependent ? { tl: d.eye, tr: d.eye, bl: d.eye } : d.eyes }))}
      />
      <Switch label="Custom eye color" hint="Give the eyes their own solid color instead of the pattern fill." checked={!!design.eyeColor} onChange={(on) => patch({ eyeColor: on ? fillStops(design.fg)[0].color : null })} />
      {design.eyeColor && <ColorField label="Eye color" value={design.eyeColor} onChange={(v) => patch({ eyeColor: v })} />}
      <Note>Eyes always keep the exact 7×7 proportions scanners look for; only their outline changes.</Note>
    </div>
  );
}

const DIRECTIONS = [0, 45, 90, 135, 180, 225, 270, 315];

function ColorsPanel({ design, patch, setDesign }: { design: QrDesign; patch: Patch; setDesign: Dispatch<SetStateAction<QrDesign>> }) {
  const fg = design.fg;
  const setFg = (p: Partial<Fill>) => setDesign((d) => ({ ...d, fg: { ...d.fg, ...p, stops: undefined } }));
  const contrast = minContrast(fg, design.bgColor);
  const contrastNote = design.transparent
    ? 'Transparent background — contrast depends on the surface you place the code on. Use it on light, plain backgrounds.'
    : contrast >= 7
      ? `Contrast ${contrast.toFixed(1)}:1 — excellent.`
      : contrast >= 4.5
        ? `Contrast ${contrast.toFixed(1)}:1 — good.`
        : contrast >= 3
          ? `Contrast ${contrast.toFixed(1)}:1 — fair. Test a printed sample before using it widely.`
          : `Contrast ${contrast.toFixed(1)}:1 — too low for reliable scanning.`;
  return (
    <div className="space-y-6">
      <Field label="Fill">
        <Chips
          options={[
            { value: 'solid', label: 'Solid' },
            { value: 'linear', label: 'Linear gradient' },
            { value: 'radial', label: 'Radial gradient' },
          ]}
          value={fg.mode}
          onChange={(mode) => setDesign((d) => ({ ...d, fg: { ...d.fg, mode, stops: mode === 'solid' ? undefined : d.fg.stops } }))}
        />
      </Field>
      <div className="grid gap-4 sm:grid-cols-2">
        <ColorField label={fg.mode === 'solid' ? 'Foreground color' : 'Start color'} value={fg.from} onChange={(v) => setFg({ from: v })} />
        {fg.mode !== 'solid' && <ColorField label="End color" value={fg.to} onChange={(v) => setFg({ to: v })} />}
      </div>
      {fg.stops && <p className="text-[12px] text-neutral-500">This style uses a multi-stop gradient. Changing a color switches to a simple two-color gradient.</p>}
      <div className="flex flex-wrap gap-2">
        {fg.mode !== 'solid' && (
          <button type="button" onClick={() => setFg({ from: fg.to, to: fg.from })} className="inline-flex items-center gap-1.5 rounded-full border border-black/15 bg-white px-3.5 py-2 text-[12.5px] font-semibold transition hover:border-black/40">
            <ArrowLeftRight className="h-3.5 w-3.5" /> Reverse gradient
          </button>
        )}
        <button type="button" onClick={() => setDesign(swapDesignColors)} className="inline-flex items-center gap-1.5 rounded-full border border-black/15 bg-white px-3.5 py-2 text-[12.5px] font-semibold transition hover:border-black/40">
          <ArrowLeftRight className="h-3.5 w-3.5" /> Swap with background
        </button>
      </div>
      {fg.mode === 'linear' && (
        <Field label="Gradient direction">
          <div className="flex flex-wrap gap-2" role="radiogroup">
            {DIRECTIONS.map((a) => (
              <button
                key={a}
                type="button"
                role="radio"
                aria-checked={fg.angle === a}
                aria-label={`${a} degrees`}
                onClick={() => setFg({ angle: a })}
                className={`grid h-10 w-10 place-items-center rounded-xl border transition focus:outline-none focus-visible:ring-2 focus-visible:ring-[#00C389] ${fg.angle === a ? 'border-[#0A0F0D] bg-[#0A0F0D] text-white' : 'border-black/15 bg-white hover:border-black/40'}`}
              >
                <ArrowRight className="h-4 w-4" style={{ transform: `rotate(${a}deg)` }} />
              </button>
            ))}
          </div>
        </Field>
      )}
      <Field label="Effects">
        <div className="space-y-4">
          <Slider label="Glow" value={design.glow} min={0} max={1} step={0.05} format={pct} onChange={(v) => patch({ glow: v })} hint="A soft halo around the pattern. Strong glows reduce contrast." />
          <Switch label="Glass effect" hint="Adds a glossy highlight across the pattern." checked={design.glass} onChange={(v) => patch({ glass: v })} />
        </div>
      </Field>
      <p className={`rounded-2xl px-4 py-3 text-[12.5px] font-medium ${!design.transparent && contrast < 3 ? 'bg-red-50 text-red-700' : 'bg-[#F3F5EE] text-neutral-700'}`}>{contrastNote}</p>
    </div>
  );
}

function LogoPanel({ design, patch }: { design: QrDesign; patch: Patch }) {
  return (
    <div className="space-y-6">
      <UploadField label="Center logo" value={design.logo} onChange={(v) => patch({ logo: v })} hint="PNG, JPG, SVG or WebP up to 3 MB. Square logos with a plain background work best." />
      {design.logo && (
        <>
          <Slider label="Logo size" value={design.logoScale} min={0.14} max={0.3} step={0.01} format={pct} onChange={(v) => patch({ logoScale: v })} hint="Relative to the code width. Larger logos cover more data, which level H error correction compensates for." />
          <Switch label="Clear space behind the logo" hint="Hides the modules under the logo and adds a plate in the background color (no plate when the background is transparent)." checked={design.logoKnockout} onChange={(v) => patch({ logoKnockout: v })} />
          <Switch label="Round plate" checked={design.logoRound} onChange={(v) => patch({ logoRound: v })} disabled={!design.logoKnockout} />
        </>
      )}
      <Note>With a logo, error correction switches to level H (30% recovery) automatically and the live scan test confirms the result.</Note>
    </div>
  );
}

function FramePanel({ design, patch, setDesign }: { design: QrDesign; patch: Patch; setDesign: Dispatch<SetStateAction<QrDesign>> }) {
  const fr = design.frame;
  const setFrame = (p: Partial<FrameOptions>) => setDesign((d) => ({ ...d, frame: { ...d.frame, ...p } }));
  const isPreset = (FRAME_TEXTS as readonly string[]).includes(fr.text);
  return (
    <div className="space-y-6">
      <Field label="Frame style">
        <Chips options={FRAME_STYLES} value={fr.style} onChange={(v) => setFrame({ style: v })} />
      </Field>
      {fr.style !== 'none' && (
        <>
          <Field label="Frame text">
            <Chips options={[...FRAME_TEXTS.map((t) => ({ value: t as string, label: t })), { value: '__custom', label: 'Custom…' }]} value={isPreset ? fr.text : '__custom'} onChange={(v) => setFrame({ text: v === '__custom' ? '' : v })} />
            {!isPreset && <input value={fr.text} maxLength={28} onChange={(e) => setFrame({ text: e.target.value })} placeholder="Your text, e.g. VIEW MENU" aria-label="Custom frame text" className={`${inputCls} mt-3`} />}
          </Field>
          <div className="grid gap-4 sm:grid-cols-2">
            <ColorField label="Frame color" value={fr.color} onChange={(v) => setFrame({ color: v, textColor: fr.style !== 'outline' && contrastRatio(v, fr.textColor) < 3 ? idealTextColor(v) : fr.textColor })} />
            <ColorField label="Text color" value={fr.textColor} onChange={(v) => setFrame({ textColor: v })} disabled={fr.style === 'outline'} hint={fr.style === 'outline' ? 'Outline text uses the frame color.' : undefined} />
          </div>
        </>
      )}
      <Slider label="Corner radius" value={design.cardRadius} min={0} max={0.15} step={0.01} format={pct} onChange={(v) => patch({ cardRadius: v })} hint="Rounds the corners of the code panel and frame." />
    </div>
  );
}

function BackgroundPanel({ design, patch }: { design: QrDesign; patch: Patch }) {
  return (
    <div className="space-y-6">
      <Switch label="Transparent background" hint="Exports with no background. Place the code on a light, plain surface so it stays readable." checked={design.transparent} onChange={(v) => patch({ transparent: v })} />
      <ColorField label="Background color" value={design.bgColor} onChange={(v) => patch({ bgColor: v })} disabled={design.transparent} />
      <UploadField label="Background image" value={design.bgImage} onChange={(v) => patch({ bgImage: v })} disabled={design.transparent} hint="Shown faded behind the pattern. Keep it light so the code stays readable." />
      {design.bgImage && <Slider label="Image opacity" value={design.bgImageOpacity} min={0.05} max={0.6} step={0.05} format={pct} onChange={(v) => patch({ bgImageOpacity: v })} disabled={design.transparent} />}
    </div>
  );
}

/* ------------------------------------------------------------------ */
/*  Studio dialog                                                      */
/* ------------------------------------------------------------------ */
export function QrStudio({
  onClose,
  payload,
  contentLabel,
  design,
  setDesign,
  scan,
  tab,
  setTab,
  downloads,
}: {
  onClose: () => void;
  payload: string;
  contentLabel: string;
  design: QrDesign;
  setDesign: Dispatch<SetStateAction<QrDesign>>;
  scan: ScanStatus;
  tab: StudioTab;
  setTab: (t: StudioTab) => void;
  downloads: Downloads;
}) {
  const dialogRef = useRef<HTMLDivElement>(null);
  const isDesktop = useMediaQuery('(min-width: 1024px)');
  const [info, setInfo] = useState<RenderInfo | null>(null);
  const patch = useCallback<Patch>((p) => setDesign((d) => ({ ...d, ...p })), [setDesign]);
  const preset = findPreset(design.styleId);

  useEffect(() => {
    const previousOverflow = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    const dialog = dialogRef.current;
    dialog?.querySelector<HTMLElement>('[data-autofocus]')?.focus();
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        e.preventDefault();
        onClose();
        return;
      }
      if (e.key !== 'Tab' || !dialog) return;
      const focusable = Array.from(dialog.querySelectorAll<HTMLElement>('button:not([disabled]), [href], input:not([disabled]), select, textarea, [tabindex]:not([tabindex="-1"])')).filter((el) => el.offsetParent !== null);
      if (!focusable.length) return;
      const first = focusable[0];
      const last = focusable[focusable.length - 1];
      if (e.shiftKey && document.activeElement === first) {
        e.preventDefault();
        last.focus();
      } else if (!e.shiftKey && document.activeElement === last) {
        e.preventDefault();
        first.focus();
      }
    };
    document.addEventListener('keydown', onKey);
    return () => {
      document.body.style.overflow = previousOverflow;
      document.removeEventListener('keydown', onKey);
    };
  }, [onClose]);

  const downloadButton = (kind: DownloadKind, label: string, Icon: typeof Download, primary = false) => (
    <button
      type="button"
      onClick={() => downloads.run(kind)}
      disabled={!!downloads.busy || scan === 'error'}
      className={`inline-flex items-center justify-center gap-1.5 rounded-full px-3 py-2.5 text-[12.5px] font-semibold transition hover:-translate-y-px focus:outline-none focus-visible:ring-2 focus-visible:ring-[#00C389] disabled:opacity-50 disabled:hover:translate-y-0 ${
        primary ? 'bg-[#0A0F0D] text-white shadow-lg shadow-black/20' : 'border border-black/15 bg-white hover:border-black/40'
      }`}
    >
      {downloads.busy === kind ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Icon className="h-3.5 w-3.5" />}
      {label}
    </button>
  );

  return (
    <div className="fixed inset-0 z-[100] flex items-stretch justify-center bg-[#0A0F0D]/60 backdrop-blur-sm sm:items-center sm:p-4" onMouseDown={(e) => e.target === e.currentTarget && onClose()}>
      <div ref={dialogRef} role="dialog" aria-modal="true" aria-labelledby="qr-studio-title" className="relative flex h-[100dvh] w-full max-w-6xl flex-col overflow-hidden bg-[#FBFCF9] shadow-2xl sm:h-[min(92vh,940px)] sm:rounded-[28px]">
        <header className="flex items-center justify-between gap-3 border-b border-black/[0.07] bg-white px-4 py-3 sm:px-6">
          <div className="min-w-0">
            <h2 id="qr-studio-title" className="font-display text-[17px] font-extrabold leading-tight">
              QR Design Studio
            </h2>
            <p className="truncate text-[12px] text-neutral-500">
              Style: <span className="font-semibold text-[#0A0F0D]">{preset.name}</span> · Encoding {contentLabel}
            </p>
          </div>
          <div className="flex items-center gap-2">
            <button type="button" onClick={() => setDesign((d) => applyPreset(d, preset))} className="hidden items-center gap-1.5 rounded-full border border-black/15 px-3 py-1.5 text-[12px] font-semibold transition hover:border-black/40 sm:inline-flex">
              <RotateCcw className="h-3.5 w-3.5" /> Reset style
            </button>
            <button type="button" data-autofocus onClick={onClose} aria-label="Close design studio" className="grid h-10 w-10 place-items-center rounded-full border border-black/10 transition hover:bg-black/5 focus:outline-none focus-visible:ring-2 focus-visible:ring-[#00C389]">
              <X className="h-5 w-5" />
            </button>
          </div>
        </header>

        <div className="flex min-h-0 flex-1 flex-col lg:flex-row">
          <aside className="shrink-0 border-b border-black/[0.07] bg-white p-4 sm:p-5 lg:order-last lg:w-[360px] lg:overflow-y-auto lg:border-b-0 lg:border-l">
            <div className="flex items-start gap-4 lg:block">
              <div className={`mx-auto grid w-[132px] shrink-0 place-items-center rounded-2xl border border-black/[0.06] p-2 sm:w-[150px] lg:w-full lg:p-4 ${design.transparent ? 'checker' : 'bg-[#F3F5EE]'}`}>
                <QrPreview payload={payload} design={design} size={isDesktop ? 280 : 128} onInfo={setInfo} />
              </div>
              <div className="min-w-0 flex-1 lg:mt-4">
                <ScanBadge status={scan} detailed onFix={() => setDesign(autoFixDesign)} onSwap={() => setDesign(swapDesignColors)} />
                {info && (
                  <p className="mt-2 font-mono text-[11px] text-neutral-500">
                    {info.modules}×{info.modules} modules · version {info.version} · EC {info.ec}
                  </p>
                )}
              </div>
            </div>
            <div className="mt-4 grid grid-cols-2 gap-2">
              {downloadButton('png', 'PNG', Download, true)}
              {downloadButton('svg', 'SVG', FileCode2)}
              {downloadButton('hires', 'High-res PNG', Download)}
              {downloadButton('transparent', 'Transparent PNG', Download)}
            </div>
            <p className="mt-3 text-[11.5px] leading-relaxed text-neutral-500">Downloads match the preview exactly. High-res PNG is 3000px wide; SVG scales to any size.</p>
          </aside>

          <section className="min-h-0 flex-1 overflow-y-auto">
            <div className="sticky top-0 z-10 border-b border-black/[0.06] bg-[#FBFCF9]/95 px-4 py-2 backdrop-blur sm:px-6">
              <div className="no-scrollbar -mx-1 flex gap-1 overflow-x-auto px-1" role="tablist" aria-label="Design options">
                {TABS.map((t) => (
                  <button
                    key={t.id}
                    type="button"
                    role="tab"
                    aria-selected={tab === t.id}
                    onClick={() => setTab(t.id)}
                    className={`inline-flex shrink-0 items-center gap-1.5 rounded-full px-3.5 py-2 text-[13px] font-semibold transition focus:outline-none focus-visible:ring-2 focus-visible:ring-[#00C389] ${
                      tab === t.id ? 'bg-[#0A0F0D] text-white shadow' : 'text-neutral-600 hover:bg-black/[0.05] hover:text-black'
                    }`}
                  >
                    <t.icon className="h-4 w-4" /> {t.label}
                  </button>
                ))}
              </div>
            </div>
            <div className="px-4 py-5 sm:px-6 sm:py-6">
              {tab === 'styles' && <StylesPanel design={design} setDesign={setDesign} />}
              {tab === 'shape' && <ShapePanel design={design} patch={patch} />}
              {tab === 'eyes' && <EyesPanel design={design} patch={patch} setDesign={setDesign} />}
              {tab === 'colors' && <ColorsPanel design={design} patch={patch} setDesign={setDesign} />}
              {tab === 'logo' && <LogoPanel design={design} patch={patch} />}
              {tab === 'frame' && <FramePanel design={design} patch={patch} setDesign={setDesign} />}
              {tab === 'background' && <BackgroundPanel design={design} patch={patch} />}
              <button type="button" onClick={() => setDesign((d) => applyPreset(d, preset))} className="mt-6 inline-flex items-center gap-1.5 text-[12.5px] font-semibold text-neutral-500 hover:text-black sm:hidden">
                <RotateCcw className="h-3.5 w-3.5" /> Reset to {preset.name}
              </button>
            </div>
          </section>
        </div>
      </div>
    </div>
  );
}

