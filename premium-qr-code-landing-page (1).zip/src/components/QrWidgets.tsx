import { useEffect, useRef, useState, type ReactNode } from 'react';
import { AlertTriangle, ArrowLeftRight, Check, Loader2, Wand2, X } from 'lucide-react';
import { isDarkOnLight } from '../qr/color';
import { FONT_WEIGHT, renderToCanvas, type RenderInfo } from '../qr/engine';
import { getThumbnail, peekThumbnail } from '../qr/hooks';
import { applyPreset, type StylePreset } from '../qr/presets';
import type { QrDesign } from '../qr/types';
import type { ScanStatus } from '../qr/verify';

/* ---------------- Live canvas preview ---------------- */
export function QrPreview({
  payload,
  design,
  size,
  className = '',
  onInfo,
}: {
  payload: string;
  design: QrDesign;
  /** CSS width of the code panel in pixels (rendered at device pixel ratio). */
  size: number;
  className?: string;
  onInfo?: (info: RenderInfo | null) => void;
}) {
  const ref = useRef<HTMLCanvasElement>(null);
  const seq = useRef(0);
  const [fontsReady, setFontsReady] = useState(false);

  useEffect(() => {
    let alive = true;
    document.fonts
      ?.load(`${FONT_WEIGHT} 20px Sora`)
      .then(() => alive && setFontsReady(true))
      .catch(() => alive && setFontsReady(true));
    return () => {
      alive = false;
    };
  }, []);

  useEffect(() => {
    const canvas = ref.current;
    if (!canvas) return;
    const id = ++seq.current;
    const dpr = Math.min(window.devicePixelRatio || 1, 3);
    renderToCanvas(canvas, payload, design, { panelWidth: Math.round(size * dpr) })
      .then((info) => seq.current === id && onInfo?.(info))
      .catch(() => seq.current === id && onInfo?.(null));
  }, [payload, design, size, fontsReady, onInfo]);

  return <canvas ref={ref} className={`checker-none block h-auto max-w-full ${className}`} role="img" aria-label="Live QR code preview" />;
}

/* ---------------- Scan status ---------------- */
const STATUS: Record<ScanStatus, { label: string; detail: string; cls: string; icon: typeof Check }> = {
  checking: { label: 'Running scan test…', detail: 'Decoding the current design with a QR reader.', cls: 'bg-neutral-100 text-neutral-600', icon: Loader2 },
  ok: { label: 'Scan test passed', detail: 'Decoded correctly in a browser test. Always test a printed sample with your phone.', cls: 'bg-[#E6F8F1] text-[#06513A]', icon: Check },
  inverted: {
    label: 'Inverted colors',
    detail: 'Light pattern on a dark background. Modern phone cameras read this, but some older scanners do not. Swap the colors for maximum compatibility.',
    cls: 'bg-amber-50 text-amber-800',
    icon: AlertTriangle,
  },
  fail: {
    label: 'Scan test failed',
    detail: 'This design could not be decoded. Increase contrast, enlarge the pattern, or reduce glow and image opacity.',
    cls: 'bg-red-50 text-red-700',
    icon: X,
  },
  error: { label: 'Content too long', detail: 'Shorten the content or lower the error correction level.', cls: 'bg-red-50 text-red-700', icon: AlertTriangle },
};

export function ScanBadge({
  status,
  detailed = false,
  onFix,
  onSwap,
  onClick,
}: {
  status: ScanStatus;
  detailed?: boolean;
  onFix?: () => void;
  onSwap?: () => void;
  onClick?: () => void;
}) {
  const s = STATUS[status];
  const Icon = s.icon;
  const chip = (
    <span className={`inline-flex items-center gap-1.5 rounded-full px-2.5 py-1 text-[11.5px] font-bold ${s.cls}`}>
      <Icon className={`h-3.5 w-3.5 ${status === 'checking' ? 'animate-spin' : ''}`} strokeWidth={2.5} />
      {s.label}
    </span>
  );
  if (!detailed) {
    return onClick ? (
      <button type="button" onClick={onClick} title={s.detail} className="rounded-full focus:outline-none focus-visible:ring-2 focus-visible:ring-[#00C389]">
        {chip}
      </button>
    ) : (
      <span title={s.detail}>{chip}</span>
    );
  }
  return (
    <div role="status" className="space-y-2">
      {chip}
      <p className="text-[12.5px] leading-relaxed text-neutral-600">{s.detail}</p>
      {(status === 'fail' || status === 'inverted') && (
        <div className="flex flex-wrap gap-2">
          {status === 'fail' && onFix && (
            <ActionButton onClick={onFix}>
              <Wand2 className="h-3.5 w-3.5" /> Auto-fix contrast
            </ActionButton>
          )}
          {onSwap && (
            <ActionButton onClick={onSwap}>
              <ArrowLeftRight className="h-3.5 w-3.5" /> Swap colors
            </ActionButton>
          )}
        </div>
      )}
    </div>
  );
}

function ActionButton({ onClick, children }: { onClick: () => void; children: ReactNode }) {
  return (
    <button
      type="button"
      onClick={onClick}
      className="inline-flex items-center gap-1.5 rounded-full border border-black/15 bg-white px-3 py-1.5 text-[12px] font-semibold transition hover:border-black/40 focus:outline-none focus-visible:ring-2 focus-visible:ring-[#00C389]"
    >
      {children}
    </button>
  );
}

/* ---------------- Style thumbnail ---------------- */
export function StyleThumb({ preset, selected, onSelect, compact = false }: { preset: StylePreset; selected: boolean; onSelect: () => void; compact?: boolean }) {
  const [src, setSrc] = useState<string | null>(() => peekThumbnail(preset.id));
  useEffect(() => {
    if (src) return;
    let alive = true;
    getThumbnail(preset)
      .then((url) => alive && setSrc(url))
      .catch(() => {});
    return () => {
      alive = false;
    };
  }, [preset, src]);
  const d = applyPreset(null, preset);
  const inverted = !isDarkOnLight(d.fg, d.bgColor);
  return (
    <button
      type="button"
      onClick={onSelect}
      aria-pressed={selected}
      title={`${preset.name} — ${preset.blurb}`}
      className={`group flex shrink-0 flex-col items-center rounded-2xl border bg-white p-1.5 text-center transition-all focus:outline-none focus-visible:ring-2 focus-visible:ring-[#00C389] ${
        compact ? 'w-[72px]' : 'w-full p-2'
      } ${selected ? 'border-[#0A0F0D] shadow-md ring-1 ring-[#0A0F0D]' : 'border-black/[0.08] hover:-translate-y-0.5 hover:border-black/30 hover:shadow-md'}`}
    >
      <span className="relative aspect-square w-full overflow-hidden rounded-xl bg-[#F3F5EE]">
        {src ? <img src={src} alt="" className="h-full w-full object-contain" draggable={false} /> : <span className="block h-full w-full animate-pulse bg-neutral-100" />}
        {selected && (
          <span className="absolute right-1 top-1 grid h-5 w-5 place-items-center rounded-full bg-[#00C389] text-white shadow">
            <Check className="h-3 w-3" strokeWidth={3} />
          </span>
        )}
        {inverted && !compact && <span className="absolute bottom-1 left-1 rounded-md bg-amber-100 px-1.5 py-0.5 text-[9px] font-bold tracking-wide text-amber-800">INVERTED</span>}
      </span>
      <span className={`mt-1.5 line-clamp-1 font-semibold leading-tight ${compact ? 'text-[10px]' : 'text-[11.5px]'}`}>{preset.name}</span>
    </button>
  );
}
