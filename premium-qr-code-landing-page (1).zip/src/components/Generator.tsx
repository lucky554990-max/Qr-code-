import { useCallback, useMemo, useRef, useState, type ChangeEvent } from 'react';
import { createPortal } from 'react-dom';
import { ArrowRight, BarChart3, Check, Copy, Download, FileCode2, Info as InfoIcon, Link2, RefreshCw, Sparkles, Wand2 } from 'lucide-react';
import { isFilled, site } from '../config/site';
import { useSiteNav } from '../lib/nav';
import { btnBase, inputCls } from '../lib/ui';
import { contrastRatio, idealTextColor } from '../qr/color';
import { useQrDownloads, useScanCheck } from '../qr/hooks';
import { FEATURED_STYLE_IDS, STYLE_PRESETS, applyPreset, findPreset } from '../qr/presets';
import type { QrDesign } from '../qr/types';
import { QrPreview, ScanBadge, StyleThumb } from './QrWidgets';
import { QrStudio, type StudioTab } from './QrStudio';

/* ---------------- Content ---------------- */
type CodeType = 'URL' | 'Text' | 'WiFi' | 'vCard';
type Fields = { url: string; message: string; ssid: string; password: string; name: string; phone: string; email: string };
const TYPE_LABELS: Record<CodeType, string> = { URL: 'Website URL', Text: 'Text', WiFi: 'WiFi network', vCard: 'Contact card' };

function buildPayload(type: CodeType, f: Fields): string {
  const esc = (s: string) => s.replace(/([\\;,:"])/g, '\\$1');
  switch (type) {
    case 'URL': {
      const t = f.url.trim();
      if (!t) return 'https://example.com';
      return /^[a-z][a-z0-9+.-]*:/i.test(t) ? t : `https://${t}`;
    }
    case 'Text':
      return f.message.trim() || `Hello from ${site.brand}!`;
    case 'WiFi': {
      const ssid = f.ssid.trim() || 'Guest-WiFi';
      const pw = f.password;
      return `WIFI:T:${pw ? 'WPA' : 'nopass'};S:${esc(ssid)};${pw ? `P:${esc(pw)};` : ''};`;
    }
    case 'vCard': {
      const name = f.name.trim() || 'Your Name';
      const parts = name.split(/\s+/);
      const last = parts.length > 1 ? parts[parts.length - 1] : '';
      const first = parts.length > 1 ? parts.slice(0, -1).join(' ') : parts[0];
      return ['BEGIN:VCARD', 'VERSION:3.0', `N:${last};${first};;;`, `FN:${name}`, f.phone.trim() ? `TEL;TYPE=CELL:${f.phone.trim()}` : '', f.email.trim() ? `EMAIL:${f.email.trim()}` : '', 'END:VCARD']
        .filter(Boolean)
        .join('\n');
    }
  }
}

const describeContent = (type: CodeType, f: Fields, payload: string): string => {
  const value = type === 'URL' ? payload : type === 'WiFi' ? f.ssid.trim() || 'Guest-WiFi' : type === 'vCard' ? f.name.trim() || 'Your Name' : payload;
  return `${TYPE_LABELS[type]}: ${value.length > 48 ? `${value.slice(0, 48)}…` : value}`;
};

/* ---------------- Quick options on the card ---------------- */
const QUICK_COLORS = [
  { name: 'Ink black', hex: '#0A0F0D' },
  { name: 'Forest green', hex: '#047857' },
  { name: 'Midnight blue', hex: '#1E3A5F' },
  { name: 'Crimson', hex: '#B42318' },
  { name: 'Royal plum', hex: '#6D28D9' },
];
type QuickFrame = 'classic' | 'rounded' | 'label';
const FEATURED = FEATURED_STYLE_IDS.map(findPreset);

export function Generator() {
  const { toast, section } = useSiteNav();
  const [type, setType] = useState<CodeType>('URL');
  const [f, setF] = useState<Fields>({
    url: isFilled(site.websiteUrl) ? site.websiteUrl : 'https://example.com',
    message: `Hello from ${site.brand}!`,
    ssid: '',
    password: '',
    name: '',
    phone: '',
    email: '',
  });
  const [design, setDesign] = useState<QrDesign>(() => applyPreset(null, STYLE_PRESETS[0]));
  const [studio, setStudio] = useState<{ open: boolean; tab: StudioTab }>({ open: false, tab: 'styles' });
  const [copied, setCopied] = useState(false);
  const studioTrigger = useRef<HTMLButtonElement>(null);

  const payload = useMemo(() => buildPayload(type, f), [type, f]);
  const scan = useScanCheck(payload, design);
  const downloads = useQrDownloads(payload, design, scan, toast);
  const set = (key: keyof Fields) => (e: ChangeEvent<HTMLInputElement>) => setF((v) => ({ ...v, [key]: e.target.value }));
  const openStudio = (tab: StudioTab = 'styles') => setStudio({ open: true, tab });
  const closeStudio = useCallback(() => {
    setStudio((s) => ({ ...s, open: false }));
    window.setTimeout(() => studioTrigger.current?.focus(), 0);
  }, []);

  const copyContent = async () => {
    try {
      await navigator.clipboard.writeText(payload);
      setCopied(true);
      toast('Content copied to clipboard');
      setTimeout(() => setCopied(false), 2000);
    } catch {
      toast('Copy is not available in this browser');
    }
  };

  /** Quick color: solid foreground; keeps the background unless it would lose contrast. */
  const pickQuickColor = (hex: string) =>
    setDesign((d) => ({
      ...d,
      fg: { mode: 'solid', from: hex, to: hex, angle: d.fg.angle },
      eyeColor: null,
      bgColor: contrastRatio(hex, d.bgColor) >= 3 ? d.bgColor : '#FFFFFF',
      frame: d.frame.style !== 'none' ? { ...d.frame, color: hex, textColor: idealTextColor(hex) } : d.frame,
    }));
  const activeColor = design.fg.mode === 'solid' ? design.fg.from.toUpperCase() : null;

  const quickFrame: QuickFrame = design.frame.style !== 'none' ? 'label' : design.cardRadius > 0.02 ? 'rounded' : 'classic';
  const pickQuickFrame = (v: QuickFrame) =>
    setDesign((d) => {
      if (v === 'label') {
        const color = d.fg.mode === 'solid' ? d.fg.from : d.frame.color;
        return { ...d, cardRadius: Math.max(d.cardRadius, 0.08), frame: { ...d.frame, style: 'label-bottom', text: 'SCAN ME', color, textColor: idealTextColor(color) } };
      }
      return { ...d, cardRadius: v === 'rounded' ? 0.08 : 0, frame: { ...d.frame, style: 'none' } };
    });

  const contentLabel = describeContent(type, f, payload);
  const label = (text: string, id: string) => (
    <label htmlFor={id} className="mb-1.5 block text-[13px] font-semibold">
      {text}
    </label>
  );

  return (
    <div id="generator-card" className="relative mx-auto max-w-[520px] scroll-mt-28">
      <div className="animate-floaty absolute -left-10 top-16 z-20 hidden items-center gap-2.5 rounded-2xl border border-black/[0.06] bg-white px-3.5 py-3 shadow-[0_20px_50px_-16px_rgba(10,15,13,0.35)] md:flex" aria-hidden="true">
        <span className="grid h-9 w-9 place-items-center rounded-xl bg-[#E6F8F1]">
          <BarChart3 className="h-4.5 w-4.5 text-[#009E6E]" />
        </span>
        <span>
          <span className="block font-display text-sm font-bold leading-none">Scan analytics</span>
          <span className="text-[11px] font-medium text-neutral-500">with dynamic codes</span>
        </span>
      </div>
      <div className="animate-floaty2 absolute -right-6 bottom-28 z-20 hidden items-center gap-2.5 rounded-2xl bg-[#0A0F0D] px-3.5 py-3 text-white shadow-2xl md:flex" aria-hidden="true">
        <span className="grid h-9 w-9 place-items-center rounded-xl bg-white/10">
          <RefreshCw className="h-4 w-4 text-[#C8F169]" />
        </span>
        <span>
          <span className="block font-display text-sm font-bold leading-none">Edit after printing</span>
          <span className="text-[11px] font-medium text-white/60">with dynamic codes</span>
        </span>
      </div>

      <div className="relative overflow-hidden rounded-[28px] border border-black/[0.07] bg-white p-5 shadow-[0_35px_80px_-24px_rgba(10,15,13,0.35)] sm:p-6">
        <div className="absolute inset-x-0 top-0 h-1 bg-[#C8F169]" aria-hidden="true" />
        <div className="flex items-center justify-between gap-3">
          <div className="flex items-center gap-2.5">
            <span className="grid h-9 w-9 place-items-center rounded-xl bg-[#0A0F0D]">
              <Sparkles className="h-4.5 w-4.5 text-[#C8F169]" />
            </span>
            <div>
              <p className="font-display font-bold leading-none">Free QR code generator</p>
              <p className="mt-1 text-[12px] text-neutral-500">Real, scannable code — point your camera at it</p>
            </div>
          </div>
          <span className="shrink-0 rounded-full bg-[#E6F8F1] px-2.5 py-1 text-[11px] font-bold tracking-wider text-[#007A55]">NO SIGN-UP</span>
        </div>

        <div className="mt-5 flex gap-1.5 rounded-full bg-[#F3F5EE] p-1" role="tablist" aria-label="QR code type">
          {(['URL', 'Text', 'WiFi', 'vCard'] as const).map((t) => (
            <button
              key={t}
              role="tab"
              aria-selected={type === t}
              onClick={() => setType(t)}
              className={`flex-1 rounded-full py-2 text-[13px] font-semibold transition-all focus:outline-none focus-visible:ring-2 focus-visible:ring-[#00C389] ${type === t ? 'bg-[#0A0F0D] text-white shadow' : 'text-neutral-600 hover:text-black'}`}
            >
              {t}
            </button>
          ))}
        </div>

        <div className="mt-5">
          {type === 'URL' && (
            <>
              {label('Destination URL', 'qr-url')}
              <div className="flex gap-2">
                <div className="relative flex-1">
                  <Link2 className="absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-neutral-400" />
                  <input id="qr-url" inputMode="url" className={`${inputCls} pl-10`} value={f.url} onChange={set('url')} placeholder="https://your-website.com" />
                </div>
                <CopyButton copied={copied} onClick={copyContent} />
              </div>
            </>
          )}
          {type === 'Text' && (
            <>
              {label('Your message', 'qr-text')}
              <div className="flex gap-2">
                <input id="qr-text" className={inputCls} value={f.message} onChange={set('message')} placeholder="Type any text" />
                <CopyButton copied={copied} onClick={copyContent} />
              </div>
            </>
          )}
          {type === 'WiFi' && (
            <div className="grid grid-cols-2 gap-2">
              <div>
                {label('Network name (SSID)', 'qr-ssid')}
                <input id="qr-ssid" className={inputCls} value={f.ssid} onChange={set('ssid')} placeholder="Guest-WiFi" />
              </div>
              <div>
                {label('Password', 'qr-password')}
                <input id="qr-password" className={inputCls} value={f.password} onChange={set('password')} placeholder="Leave empty if open" autoComplete="off" />
              </div>
            </div>
          )}
          {type === 'vCard' && (
            <div className="grid grid-cols-2 gap-2">
              <div className="col-span-2">
                {label('Full name', 'qr-name')}
                <input id="qr-name" className={inputCls} value={f.name} onChange={set('name')} placeholder="Your name" />
              </div>
              <div>
                {label('Phone', 'qr-phone')}
                <input id="qr-phone" inputMode="tel" className={inputCls} value={f.phone} onChange={set('phone')} placeholder="+1 555 000 0000" />
              </div>
              <div>
                {label('Email', 'qr-email')}
                <input id="qr-email" inputMode="email" className={inputCls} value={f.email} onChange={set('email')} placeholder="you@company.com" />
              </div>
            </div>
          )}
        </div>

        {/* Quick style strip */}
        <div className="mt-5">
          <div className="flex items-center justify-between">
            <p className="text-[13px] font-semibold">Style</p>
            <button type="button" onClick={() => openStudio('styles')} className="inline-flex items-center gap-1 text-[12px] font-bold text-[#007A55] hover:underline focus:outline-none focus-visible:ring-2 focus-visible:ring-[#00C389]">
              All {STYLE_PRESETS.length} styles <ArrowRight className="h-3.5 w-3.5" />
            </button>
          </div>
          <div className="no-scrollbar -mx-1 mt-2 flex gap-2 overflow-x-auto px-1 pb-1">
            {FEATURED.map((p) => (
              <StyleThumb key={p.id} preset={p} compact selected={design.styleId === p.id} onSelect={() => setDesign((d) => applyPreset(d, p))} />
            ))}
            <button
              type="button"
              onClick={() => openStudio('styles')}
              className="flex w-[72px] shrink-0 flex-col items-center justify-center gap-1 rounded-2xl border border-dashed border-black/20 p-1.5 text-center text-[10px] font-semibold text-neutral-600 transition hover:border-black/50 hover:text-black focus:outline-none focus-visible:ring-2 focus-visible:ring-[#00C389]"
            >
              <span className="grid h-8 w-8 place-items-center rounded-full bg-[#F3F5EE] font-display text-[13px] font-extrabold text-[#0A0F0D]">+{STYLE_PRESETS.length - FEATURED.length}</span>
              More styles
            </button>
          </div>
        </div>

        <div className="mt-5 grid grid-cols-[1fr_auto] items-start gap-4">
          <div>
            <p className="mb-2 text-[13px] font-semibold">Color</p>
            <div className="flex gap-2" role="radiogroup" aria-label="QR code color">
              {QUICK_COLORS.map((c) => (
                <button
                  key={c.name}
                  role="radio"
                  aria-checked={activeColor === c.hex}
                  aria-label={c.name}
                  onClick={() => pickQuickColor(c.hex)}
                  className={`h-9 w-9 rounded-full transition-all hover:scale-110 focus:outline-none active:scale-95 ${activeColor === c.hex ? 'scale-105 ring-2 ring-[#0A0F0D] ring-offset-2' : 'ring-1 ring-black/10'}`}
                  style={{ backgroundColor: c.hex }}
                />
              ))}
            </div>
            <p className="mb-2 mt-4 text-[13px] font-semibold">Frame</p>
            <div className="flex flex-wrap gap-1.5">
              {(
                [
                  ['classic', 'Classic'],
                  ['rounded', 'Rounded'],
                  ['label', '"Scan me" label'],
                ] as [QuickFrame, string][]
              ).map(([v, text]) => (
                <button
                  key={v}
                  onClick={() => pickQuickFrame(v)}
                  aria-pressed={quickFrame === v}
                  className={`rounded-full border px-3 py-1.5 text-[12px] font-semibold transition focus:outline-none focus-visible:ring-2 focus-visible:ring-[#00C389] ${quickFrame === v ? 'border-[#0A0F0D] bg-[#0A0F0D] text-white' : 'border-black/15 hover:border-black/35'}`}
                >
                  {text}
                </button>
              ))}
            </div>
            <ul className="mt-5 space-y-2 text-[13px] font-medium text-neutral-600">
              <li className="flex gap-2">
                <Check className="mt-px h-4 w-4 shrink-0 text-[#009E6E]" strokeWidth={3} /> Works with any phone camera
              </li>
              <li className="flex gap-2">
                <Check className="mt-px h-4 w-4 shrink-0 text-[#009E6E]" strokeWidth={3} /> Download as PNG or SVG
              </li>
              <li className="flex gap-2">
                <Check className="mt-px h-4 w-4 shrink-0 text-[#009E6E]" strokeWidth={3} /> Created in your browser — nothing is uploaded
              </li>
            </ul>
          </div>

          <div className="text-center">
            <div className={`relative mx-auto w-[168px] overflow-hidden rounded-[22px] border border-black/[0.07] p-2 shadow-[0_16px_40px_-14px_rgba(10,15,13,0.3)] sm:w-[184px] ${design.transparent ? 'checker' : 'bg-[#F3F5EE]'}`}>
              <div className="animate-scan pointer-events-none absolute left-3 right-3 z-10 h-[3px] rounded-full bg-[#00C389] shadow-[0_0_14px_2px_rgba(0,195,137,0.65)]" aria-hidden="true" />
              <QrPreview payload={payload} design={design} size={184} className="mx-auto" />
            </div>
            <div className="mt-2">
              <ScanBadge status={scan} onClick={() => openStudio('colors')} />
            </div>
          </div>
        </div>

        <div className="mt-6 flex gap-2">
          <button onClick={() => downloads.run('png')} disabled={!!downloads.busy} className={`${btnBase} flex-1 bg-[#0A0F0D] px-4 py-3.5 text-[14px] text-white shadow-lg shadow-black/20 hover:shadow-xl`}>
            <Download className="h-4 w-4" /> {downloads.busy === 'png' ? 'Preparing…' : 'Download PNG'}
          </button>
          <button onClick={() => downloads.run('svg')} disabled={!!downloads.busy} className={`${btnBase} flex-1 border border-black/15 px-4 py-3.5 text-[14px] hover:border-black/40 hover:bg-black/[0.03]`}>
            <FileCode2 className="h-4 w-4" /> Download SVG
          </button>
        </div>
        <div className="mt-2 grid grid-cols-3 gap-2">
          <button onClick={() => downloads.run('hires')} disabled={!!downloads.busy} className="rounded-full border border-black/10 px-2 py-2 text-[11.5px] font-semibold text-neutral-700 transition hover:border-black/40 disabled:opacity-50">
            {downloads.busy === 'hires' ? 'Preparing…' : 'High-res PNG'}
          </button>
          <button onClick={() => downloads.run('transparent')} disabled={!!downloads.busy} className="rounded-full border border-black/10 px-2 py-2 text-[11.5px] font-semibold text-neutral-700 transition hover:border-black/40 disabled:opacity-50">
            {downloads.busy === 'transparent' ? 'Preparing…' : 'Transparent PNG'}
          </button>
          <button ref={studioTrigger} onClick={() => openStudio('styles')} className="inline-flex items-center justify-center gap-1 rounded-full bg-[#C8F169] px-2 py-2 text-[11.5px] font-bold text-[#0A0F0D] transition hover:bg-[#d6f78a] focus:outline-none focus-visible:ring-2 focus-visible:ring-lime-500">
            <Wand2 className="h-3.5 w-3.5" /> Design studio
          </button>
        </div>
        <p className="mt-4 flex items-start gap-2 text-[12.5px] leading-relaxed text-neutral-500">
          <InfoIcon className="mt-0.5 h-3.5 w-3.5 shrink-0" />
          <span>
            This free tool creates a standard QR code that stores your content directly. Want a code you can edit after printing and track?{' '}
            <button onClick={() => section('features')} className="font-semibold text-[#007A55] underline-offset-4 hover:underline">
              Learn about dynamic codes
            </button>
          </span>
        </p>
      </div>

      {studio.open &&
        createPortal(
          <QrStudio onClose={closeStudio} payload={payload} contentLabel={contentLabel} design={design} setDesign={setDesign} scan={scan} tab={studio.tab} setTab={(tab) => setStudio({ open: true, tab })} downloads={downloads} />,
          document.body,
        )}
    </div>
  );
}

function CopyButton({ copied, onClick }: { copied: boolean; onClick: () => void }) {
  return (
    <button onClick={onClick} className="grid h-[46px] w-11 shrink-0 place-items-center rounded-xl border border-black/10 transition hover:bg-black/[0.04] active:scale-95" aria-label="Copy content">
      {copied ? <Check className="h-4.5 w-4.5 text-[#009E6E]" strokeWidth={3} /> : <Copy className="h-4.5 w-4.5" />}
    </button>
  );
}
