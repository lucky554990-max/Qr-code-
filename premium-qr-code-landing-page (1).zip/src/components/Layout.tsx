import { useEffect, useState } from 'react';
import { ArrowRight, Menu, QrCode, X } from 'lucide-react';
import { isFilled, site } from '../config/site';
import { PageLink, useSiteNav, type Route } from '../lib/nav';
import { Info } from '../lib/ui';

const SECTION_LINKS: [string, string][] = [
  ['Features', 'features'],
  ['Use cases', 'showcase'],
  ['Pricing', 'pricing'],
  ['FAQ', 'faq'],
];
const PAGE_LINKS: [string, Route][] = [
  ['Services', 'services'],
  ['About', 'about'],
  ['Contact', 'contact'],
];

function Logo({ onDark = false }: { onDark?: boolean }) {
  return (
    <PageLink to="home" className="flex shrink-0 items-center gap-2.5 rounded-xl focus:outline-none focus-visible:ring-2 focus-visible:ring-[#00C389]">
      <span className={`relative grid h-9 w-9 place-items-center rounded-[11px] shadow-lg shadow-black/20 ${onDark ? 'bg-[#C8F169]' : 'bg-[#0A0F0D]'}`}>
        <QrCode className={`h-5 w-5 ${onDark ? 'text-[#0A0F0D]' : 'text-[#C8F169]'}`} strokeWidth={2.4} />
      </span>
      <span className="font-display text-[19px] font-extrabold leading-none tracking-tight">
        {site.brand}
        <span className="text-[#00C389]">.</span>
      </span>
    </PageLink>
  );
}

export function Navbar() {
  const { route, section } = useSiteNav();
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 24);
    onScroll();
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  useEffect(() => setOpen(false), [route]);

  const linkCls = 'rounded-full px-3 py-2 transition hover:bg-black/[0.05] hover:text-black focus:outline-none focus-visible:ring-2 focus-visible:ring-[#00C389]';
  const activeCls = 'bg-black/[0.06] text-black';

  return (
    <header className={`fixed inset-x-0 top-0 z-50 transition-all duration-500 ${scrolled ? 'py-2' : 'py-4'}`}>
      <div className="mx-auto max-w-7xl px-4 sm:px-6">
        <nav
          aria-label="Main"
          className={`flex items-center justify-between gap-3 rounded-2xl px-4 transition-all duration-500 sm:px-5 ${
            scrolled || open ? 'glass border border-white/60 py-2.5 shadow-[0_12px_40px_-12px_rgba(10,15,13,0.25)]' : 'border border-transparent bg-transparent py-2'
          }`}
        >
          <Logo />
          <div className="hidden items-center gap-0.5 text-[13.5px] font-medium text-neutral-700 lg:flex">
            {SECTION_LINKS.map(([label, id]) => (
              <button key={id} onClick={() => section(id)} className={linkCls}>
                {label}
              </button>
            ))}
            <span className="mx-1.5 h-4 w-px bg-black/10" aria-hidden="true" />
            {PAGE_LINKS.map(([label, to]) => (
              <PageLink key={to} to={to} className={`${linkCls} ${route === to ? activeCls : ''}`}>
                {label}
              </PageLink>
            ))}
          </div>
          <div className="flex items-center gap-2">
            {site.appUrl && (
              <a href={site.appUrl} className="hidden rounded-full px-4 py-2 text-sm font-semibold transition hover:bg-black/[0.05] sm:inline-flex">
                Sign in
              </a>
            )}
            <button
              onClick={() => section('generator')}
              className="group inline-flex items-center gap-1.5 rounded-full bg-[#0A0F0D] py-2.5 pl-4 pr-3 text-sm font-semibold text-white shadow-lg shadow-black/20 transition-all hover:-translate-y-px hover:shadow-xl focus:outline-none focus-visible:ring-2 focus-visible:ring-[#00C389] focus-visible:ring-offset-2 active:translate-y-0"
            >
              Create QR code <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-0.5" />
            </button>
            <button
              className="grid h-10 w-10 place-items-center rounded-full hover:bg-black/5 lg:hidden"
              onClick={() => setOpen((v) => !v)}
              aria-expanded={open}
              aria-controls="mobile-menu"
              aria-label="Toggle menu"
            >
              {open ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
            </button>
          </div>
        </nav>
        {open && (
          <div id="mobile-menu" className="glass mt-2 rounded-2xl border border-white/70 p-3 shadow-xl lg:hidden">
            {SECTION_LINKS.map(([label, id]) => (
              <button
                key={id}
                onClick={() => {
                  section(id);
                  setOpen(false);
                }}
                className="w-full rounded-xl px-4 py-3 text-left font-medium hover:bg-black/5"
              >
                {label}
              </button>
            ))}
            <div className="my-2 h-px bg-black/[0.07]" />
            {PAGE_LINKS.map(([label, to]) => (
              <PageLink key={to} to={to} onClick={() => setOpen(false)} className={`block w-full rounded-xl px-4 py-3 font-medium hover:bg-black/5 ${route === to ? activeCls : ''}`}>
                {label}
              </PageLink>
            ))}
            {site.appUrl && (
              <a href={site.appUrl} className="block w-full rounded-xl px-4 py-3 font-medium hover:bg-black/5">
                Sign in
              </a>
            )}
          </div>
        )}
      </div>
    </header>
  );
}

export function Footer() {
  const { section } = useSiteNav();
  const year = new Date().getFullYear();
  const socials = (
    [
      ['X', 'X (Twitter)', site.social.x],
      ['in', 'LinkedIn', site.social.linkedin],
      ['IG', 'Instagram', site.social.instagram],
      ['YT', 'YouTube', site.social.youtube],
    ] as [string, string, string][]
  ).filter(([, , url]) => url.trim() !== '');

  const colTitle = 'font-display text-[13px] font-bold tracking-[0.14em] text-white/40';
  const colLink = 'text-[14px] text-white/65 transition-colors hover:text-[#C8F169]';

  return (
    <footer className="relative overflow-hidden bg-[#0A0F0D] pt-16 pb-8 text-white">
      <div className="absolute inset-x-0 top-0 h-px bg-white/10" aria-hidden="true" />
      <div className="relative mx-auto max-w-7xl px-4 sm:px-6">
        <div className="grid gap-10 md:grid-cols-[1.4fr_repeat(3,1fr)] md:gap-8">
          <div>
            <Logo onDark />
            <p className="mt-4 max-w-xs text-[14px] leading-relaxed text-white/50">{site.tagline}</p>
            <dl className="mt-6 space-y-2 text-[14px]">
              <div className="flex flex-wrap gap-x-2">
                <dt className="text-white/40">Email:</dt>
                <dd>
                  <Info value={site.contactEmail} href={`mailto:${site.contactEmail}`} className="text-white/80" />
                </dd>
              </div>
              {isFilled(site.phone) && (
                <div className="flex flex-wrap gap-x-2">
                  <dt className="text-white/40">Phone:</dt>
                  <dd>
                    <a href={`tel:${site.phone.replace(/[^+\d]/g, '')}`} className="text-white/80 hover:underline">
                      {site.phone}
                    </a>
                  </dd>
                </div>
              )}
            </dl>
            {socials.length > 0 && (
              <div className="mt-6 flex gap-2">
                {socials.map(([short, name, url]) => (
                  <a
                    key={name}
                    href={url}
                    target="_blank"
                    rel="noreferrer"
                    aria-label={`${site.brand} on ${name}`}
                    className="grid h-9 w-9 place-items-center rounded-full border border-white/15 text-[11px] font-extrabold transition-all hover:border-[#C8F169] hover:bg-[#C8F169] hover:text-[#0A0F0D]"
                  >
                    {short}
                  </a>
                ))}
              </div>
            )}
          </div>

          <nav aria-label="Product">
            <h3 className={colTitle}>PRODUCT</h3>
            <ul className="mt-4 space-y-2.5">
              {[
                ['Free QR generator', 'generator'],
                ['Features', 'features'],
                ['Use cases', 'showcase'],
                ['QR code types', 'types'],
                ['Analytics', 'analytics'],
                ['Pricing', 'pricing'],
                ['FAQ', 'faq'],
              ].map(([label, id]) => (
                <li key={id}>
                  <button onClick={() => section(id)} className={colLink}>
                    {label}
                  </button>
                </li>
              ))}
            </ul>
          </nav>

          <nav aria-label="Company">
            <h3 className={colTitle}>COMPANY</h3>
            <ul className="mt-4 space-y-2.5">
              {PAGE_LINKS.map(([label, to]) => (
                <li key={to}>
                  <PageLink to={to} className={colLink}>
                    {label}
                  </PageLink>
                </li>
              ))}
              <li>
                <button onClick={() => section('reviews')} className={colLink}>
                  Leave feedback
                </button>
              </li>
            </ul>
          </nav>

          <nav aria-label="Legal">
            <h3 className={colTitle}>LEGAL</h3>
            <ul className="mt-4 space-y-2.5">
              <li>
                <PageLink to="privacy" className={colLink}>
                  Privacy Policy
                </PageLink>
              </li>
              <li>
                <PageLink to="terms" className={colLink}>
                  Terms of Service
                </PageLink>
              </li>
            </ul>
          </nav>
        </div>

        <div className="mt-12 flex flex-col items-start justify-between gap-3 border-t border-white/10 pt-7 text-[13px] font-medium text-white/40 sm:flex-row sm:items-center">
          <p>
            © {year} {isFilled(site.legalName) ? site.legalName : site.brand}. All rights reserved.
          </p>
          <p>Made with care for people who still love print.</p>
        </div>
        <p
          className="pointer-events-none -mb-[4vw] mt-6 select-none text-center font-display text-[19vw] font-extrabold leading-none tracking-tight text-white/[0.045] lg:text-[168px]"
          aria-hidden="true"
        >
          SCAN ME
        </p>
      </div>
    </footer>
  );
}
