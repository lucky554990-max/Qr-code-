import { useState, type FormEvent, type ReactNode } from 'react';
import { AlertTriangle, Check, Loader2, Mail, Send, Star } from 'lucide-react';
import { isFilled, site } from '../config/site';
import { Placeholder, btn, inputCls, submitForm, type SubmitResult } from '../lib/ui';

type Status = 'idle' | 'sending' | 'error' | SubmitResult;

function Field({
  id,
  label,
  optional,
  hint,
  children,
  className = '',
}: {
  id: string;
  label: string;
  optional?: boolean;
  hint?: string;
  children: ReactNode;
  className?: string;
}) {
  return (
    <div className={className}>
      <label htmlFor={id} className="mb-1.5 block text-[13px] font-semibold">
        {label}
        {optional && <span className="ml-1 font-medium text-neutral-400">(optional)</span>}
      </label>
      {children}
      {hint && <p className="mt-1 text-[12px] text-neutral-500">{hint}</p>}
    </div>
  );
}

function Notice({ tone, icon: Icon, children }: { tone: 'ok' | 'warn'; icon: typeof Check; children: ReactNode }) {
  return (
    <div
      role="status"
      className={`mt-4 flex items-start gap-3 rounded-2xl border p-4 text-[14px] leading-relaxed ${
        tone === 'ok' ? 'border-[#00C389]/30 bg-[#E6F8F1] text-[#06513A]' : 'border-amber-500/40 bg-amber-50 text-amber-900'
      }`}
    >
      <Icon className="mt-0.5 h-4.5 w-4.5 shrink-0" />
      <p>{children}</p>
    </div>
  );
}

function StatusNotice({ status }: { status: Status }) {
  const emailLink = isFilled(site.contactEmail) ? (
    <a href={`mailto:${site.contactEmail}`} className="font-semibold underline underline-offset-4">
      {site.contactEmail}
    </a>
  ) : null;

  if (status === 'sent')
    return (
      <Notice tone="ok" icon={Check}>
        Thank you — your message has been sent. We will reply {isFilled(site.responseTime) ? site.responseTime : 'as soon as we can'}.
      </Notice>
    );
  if (status === 'mailto')
    return (
      <Notice tone="ok" icon={Mail}>
        Your email app should now open with the message ready to send. If it does not, please email us at {emailLink}.
      </Notice>
    );
  if (status === 'unconfigured')
    return (
      <Notice tone="warn" icon={AlertTriangle}>
        This form is not connected yet. <Placeholder /> — set <code className="font-mono text-[12px]">formEndpoint</code> or{' '}
        <code className="font-mono text-[12px]">contactEmail</code> in <code className="font-mono text-[12px]">src/config/site.ts</code>.
      </Notice>
    );
  if (status === 'error')
    return (
      <Notice tone="warn" icon={AlertTriangle}>
        Something went wrong and your message was not sent. Please try again{emailLink ? <> or email us at {emailLink}</> : null}.
      </Notice>
    );
  return null;
}

/* ------------------------------------------------------------------ */
/*  Contact form                                                       */
/* ------------------------------------------------------------------ */
const TOPICS = ['General question', 'Plans and pricing', 'Help with a QR code', 'Partnership', 'Other'];

export function ContactForm() {
  const [status, setStatus] = useState<Status>('idle');
  const [values, setValues] = useState({ name: '', email: '', company: '', topic: TOPICS[0], message: '', website: '' });
  const update = (key: keyof typeof values) => (e: { target: { value: string } }) => setValues((v) => ({ ...v, [key]: e.target.value }));

  const onSubmit = async (e: FormEvent) => {
    e.preventDefault();
    if (values.website) return; // honeypot: bots fill hidden fields, people do not
    setStatus('sending');
    try {
      const result = await submitForm(`[${site.brand}] ${values.topic} — ${values.name}`, {
        name: values.name,
        email: values.email,
        company: values.company,
        topic: values.topic,
        message: values.message,
      });
      setStatus(result);
      if (result === 'sent') setValues({ name: '', email: '', company: '', topic: TOPICS[0], message: '', website: '' });
    } catch {
      setStatus('error');
    }
  };

  return (
    <form onSubmit={onSubmit} className="space-y-4" noValidate={false}>
      <div className="grid gap-4 sm:grid-cols-2">
        <Field id="contact-name" label="Your name">
          <input id="contact-name" required autoComplete="name" className={inputCls} value={values.name} onChange={update('name')} placeholder="First and last name" />
        </Field>
        <Field id="contact-email" label="Email address">
          <input id="contact-email" type="email" required autoComplete="email" className={inputCls} value={values.email} onChange={update('email')} placeholder="you@company.com" />
        </Field>
      </div>
      <div className="grid gap-4 sm:grid-cols-2">
        <Field id="contact-company" label="Company" optional>
          <input id="contact-company" autoComplete="organization" className={inputCls} value={values.company} onChange={update('company')} placeholder="Company or project" />
        </Field>
        <Field id="contact-topic" label="Topic">
          <select id="contact-topic" className={inputCls} value={values.topic} onChange={update('topic')}>
            {TOPICS.map((t) => (
              <option key={t}>{t}</option>
            ))}
          </select>
        </Field>
      </div>
      <Field id="contact-message" label="Message">
        <textarea id="contact-message" required rows={5} className={`${inputCls} resize-y`} value={values.message} onChange={update('message')} placeholder="How can we help?" />
      </Field>
      <div className="hidden" aria-hidden="true">
        <label htmlFor="contact-website">Website</label>
        <input id="contact-website" tabIndex={-1} autoComplete="off" value={values.website} onChange={update('website')} />
      </div>
      <div className="flex flex-col gap-3 pt-1 sm:flex-row sm:items-center sm:justify-between">
        <button type="submit" disabled={status === 'sending'} className={`${btn.dark} w-full sm:w-auto`}>
          {status === 'sending' ? <Loader2 className="h-4 w-4 animate-spin" /> : <Send className="h-4 w-4" />}
          {status === 'sending' ? 'Sending…' : 'Send message'}
        </button>
        <p className="text-[12.5px] text-neutral-500">We only use your details to reply to you.</p>
      </div>
      <StatusNotice status={status} />
    </form>
  );
}

/* ------------------------------------------------------------------ */
/*  Customer feedback / review form                                     */
/* ------------------------------------------------------------------ */
export function FeedbackForm() {
  const [status, setStatus] = useState<Status>('idle');
  const [rating, setRating] = useState(0);
  const [hover, setHover] = useState(0);
  const [consent, setConsent] = useState(false);
  const [values, setValues] = useState({ name: '', email: '', role: '', message: '', website: '' });
  const update = (key: keyof typeof values) => (e: { target: { value: string } }) => setValues((v) => ({ ...v, [key]: e.target.value }));

  const onSubmit = async (e: FormEvent) => {
    e.preventDefault();
    if (values.website) return;
    setStatus('sending');
    try {
      const result = await submitForm(`[${site.brand}] Customer feedback — ${values.name}`, {
        name: values.name,
        email: values.email,
        role: values.role,
        rating: rating ? `${rating}/5` : 'not given',
        message: values.message,
        permission_to_publish: consent ? 'yes' : 'no',
      });
      setStatus(result);
      if (result === 'sent') {
        setValues({ name: '', email: '', role: '', message: '', website: '' });
        setRating(0);
        setConsent(false);
      }
    } catch {
      setStatus('error');
    }
  };

  return (
    <form onSubmit={onSubmit} className="space-y-4">
      <div className="grid gap-4 sm:grid-cols-2">
        <Field id="fb-name" label="Your name">
          <input id="fb-name" required autoComplete="name" className={inputCls} value={values.name} onChange={update('name')} placeholder="First and last name" />
        </Field>
        <Field id="fb-email" label="Email address" hint="Never published — only used to confirm your review.">
          <input id="fb-email" type="email" required autoComplete="email" className={inputCls} value={values.email} onChange={update('email')} placeholder="you@company.com" />
        </Field>
      </div>
      <Field id="fb-role" label="Role and company" optional>
        <input id="fb-role" autoComplete="organization-title" className={inputCls} value={values.role} onChange={update('role')} placeholder="e.g. Owner, Example Café" />
      </Field>
      <div>
        <p className="mb-1.5 text-[13px] font-semibold">
          Rating <span className="ml-1 font-medium text-neutral-400">(optional)</span>
        </p>
        <div className="flex gap-1" role="radiogroup" aria-label="Rating out of 5">
          {[1, 2, 3, 4, 5].map((n) => (
            <button
              key={n}
              type="button"
              role="radio"
              aria-checked={rating === n}
              aria-label={`${n} out of 5`}
              onMouseEnter={() => setHover(n)}
              onMouseLeave={() => setHover(0)}
              onClick={() => setRating(n === rating ? 0 : n)}
              className="rounded-md p-1 transition-transform hover:scale-110 focus:outline-none focus-visible:ring-2 focus-visible:ring-[#00C389]"
            >
              <Star className={`h-7 w-7 transition-colors ${(hover || rating) >= n ? 'fill-amber-400 text-amber-400' : 'text-neutral-300'}`} />
            </button>
          ))}
        </div>
      </div>
      <Field id="fb-message" label="Your experience">
        <textarea
          id="fb-message"
          required
          rows={4}
          className={`${inputCls} resize-y`}
          value={values.message}
          onChange={update('message')}
          placeholder={`What did you use ${site.brand} for, and how did it go?`}
        />
      </Field>
      <label className="flex cursor-pointer items-start gap-3 text-[13.5px] leading-relaxed text-neutral-700">
        <input type="checkbox" required checked={consent} onChange={(e) => setConsent(e.target.checked)} className="mt-1 h-4 w-4 accent-[#00C389]" />
        <span>
          I agree that {site.brand} may publish this review, together with my name and role, on this website. I can withdraw this permission at any time by contacting you.
        </span>
      </label>
      <div className="hidden" aria-hidden="true">
        <label htmlFor="fb-website">Website</label>
        <input id="fb-website" tabIndex={-1} autoComplete="off" value={values.website} onChange={update('website')} />
      </div>
      <button type="submit" disabled={status === 'sending'} className={`${btn.mint} w-full sm:w-auto`}>
        {status === 'sending' ? <Loader2 className="h-4 w-4 animate-spin" /> : <Send className="h-4 w-4" />}
        {status === 'sending' ? 'Sending…' : 'Submit feedback'}
      </button>
      <StatusNotice status={status} />
    </form>
  );
}
