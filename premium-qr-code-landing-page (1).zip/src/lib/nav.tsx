import { createContext, useContext, useEffect, useState, type ReactNode } from 'react';

export type Route = 'home' | 'about' | 'services' | 'contact' | 'privacy' | 'terms';
const ROUTES: Route[] = ['home', 'about', 'services', 'contact', 'privacy', 'terms'];

export const PAGE_TITLES: Record<Route, string> = {
  home: 'Free QR Code Generator & Dynamic QR Codes',
  about: 'About',
  services: 'Services',
  contact: 'Contact',
  privacy: 'Privacy Policy',
  terms: 'Terms of Service',
};

/** Routes look like "#/about". Anything else is treated as the home page. */
export function parseRoute(hash: string = window.location.hash): Route {
  const match = hash.match(/^#\/([a-z-]*)/i);
  if (!match) return 'home';
  const path = match[1].toLowerCase() as Route;
  return ROUTES.includes(path) ? path : 'home';
}

export const routePath = (route: Route) => (route === 'home' ? '#/' : `#/${route}`);

export function useHashRoute(): Route {
  const [route, setRoute] = useState<Route>(() => parseRoute());
  useEffect(() => {
    const onChange = () => setRoute(parseRoute());
    window.addEventListener('hashchange', onChange);
    return () => window.removeEventListener('hashchange', onChange);
  }, []);
  return route;
}

export type SiteNav = {
  route: Route;
  /** Navigate to a page. */
  go: (route: Route) => void;
  /** Scroll to a section of the home page (navigates home first if needed). */
  section: (id: string) => void;
  /** Show a short confirmation message. */
  toast: (message: string) => void;
};

export const SiteNavContext = createContext<SiteNav>({
  route: 'home',
  go: () => {},
  section: () => {},
  toast: () => {},
});

export const useSiteNav = () => useContext(SiteNavContext);

/** Accessible link to another page of the site. */
export function PageLink({
  to,
  className = '',
  children,
  onClick,
}: {
  to: Route;
  className?: string;
  children: ReactNode;
  onClick?: () => void;
}) {
  const { route, go } = useSiteNav();
  return (
    <a
      href={routePath(to)}
      aria-current={route === to ? 'page' : undefined}
      className={className}
      onClick={(e) => {
        onClick?.();
        if (route === to) {
          e.preventDefault();
          go(to);
        }
      }}
    >
      {children}
    </a>
  );
}
