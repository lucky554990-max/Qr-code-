import { useEffect, useRef, useState, type CSSProperties, type ReactNode } from 'react';
import { ArrowRight } from 'lucide-react';
import { PLACEHOLDER, isFilled, site } from '../config/site';
import { PageLink, useSiteNav } from './nav';

/* ------------------------------------------------------------------ */
/*  Motion helpers                                                     */
/* ------------------------------------------------------------------ */
export function useInView<T extends HTMLElement>(threshold = 0.15) {
  const ref = useRef<T | null>(null);
  const [inView, setInView] = useState(false);
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const obs = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setInView(true);
          obs.disconnect();
        }
      },
      { threshold, rootMargin: '0px 0px -40px 0px' },
    );
    obs.observe(el);
    return () => obs.disconnect();
  }, [threshold]);
  return { ref, inView };
}

export function Reveal({
  children,
  className = '',
  delay = 0,
  scale = false,
}: {
  children: ReactNode;
  className?: string;
  delay?: number;
  scale?: boolean;
}) {
  const { ref, inView } = useInView<HTMLDivElement>(0.12);
  return (
    <div
      ref={ref}
      style={{ '--delay': `${delay}ms` } as CSSProperties}
      className={`${scale ? 'reveal-scale' : 'reveal'} ${inView ? 'is-visible' : ''} ${className}`}
    >
      {children}
    </div>
  );
}

export function CountUp({
  end,
  suffix = '',
  prefix = '',
  decimals = 0,
  duration = 1600,
}: {
  end: number;
  suffix?: string;
  prefix?: string;
  decimals?: number;
  duration?: number;
}) {
  const { ref, inView } = useInView<HTMLSpanElement>(0.4);
  const [val, setVal] = useState(0);
  useEffect(() => {
    if (!inView) return;
    let raf = 0;
    const start = performance.now();
    const tick = (now: number) => {
      const p = Math.min((now - start) / duration, 1);
      setVal(end * (1 - Math.pow(1 - p, 4)));
      if (p < 1) raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [inView, end, duration]);
  return (
    <span ref={ref}>
      {prefix}
      {val.toFixed(decimals)}
      {suffix}
    </span>
  );
}

export const scrollToId = (id: string) => {
  const el = document.getElementById(id);
  if (el) el.scrollIntoView({ behavior: 'smooth', block: 'start' });
};

/* ------------------------------------------------------------------ */
/*  Placeholders for information that still has to be filled in       */
/* ------------------------------------------------------------------ */
export function Placeholder({ label = PLACEHOLDER, className = '' }: { label?: string; className?: string }) {
  return (
    <span
      title="Replace this value in src/config/site.ts"
      className={`inline-flex max-w-full items-center rounded-md border border-dashed border-amber-500/70 bg-amber-50 px-2 py-0.5 align-middle font-mono text-[12px] font-semibold leading-5 text-amber-800 ${className}`}
    >
      {label}
    </span>
  );
}

/** Shows a real value, or the placeholder marker when it is missing. */
export function Info({ value, href, className = '' }: { value?: string; href?: string; className?: string }) {
  if (!isFilled(value)) return <Placeholder className={className} />;
  return href ? (
    <a href={href} className={`underline-offset-4 hover:underline ${className}`}>
      {value}
    </a>
  ) : (
    <span className={className}>{value}</span>
  );
}

/** A larger placeholder area with a hint about what to write. */
export function PlaceholderBlock({ hint, className = '' }: { hint: string; className?: string }) {
  return (
    <div className={`rounded-2xl border border-dashed border-amber-500/60 bg-amber-50/70 p-5 ${className}`}>
      <Placeholder />
      <p className="mt-2 text-sm leading-relaxed text-amber-900/80">{hint}</p>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/*  Consistent styles                                                  */
/* ------------------------------------------------------------------ */
export const btnBase =
  'group inline-flex items-center justify-center gap-2 rounded-full font-semibold transition-all hover:-translate-y-px active:translate-y-0 focus:outline-none focus-visible:ring-2 focus-visible:ring-offset-2 focus-visible:ring-[#00C389] disabled:cursor-not-allowed disabled:opacity-60 disabled:hover:translate-y-0';

export const btn = {
  dark: `${btnBase} bg-[#0A0F0D] px-6 py-3.5 text-white shadow-lg shadow-black/20 hover:shadow-xl`,
  mint: `${btnBase} bg-[#00C389] px-6 py-3.5 text-white shadow-lg shadow-emerald-600/25 hover:bg-[#009E6E]`,
  lime: `${btnBase} bg-[#C8F169] px-6 py-3.5 font-bold text-[#0A0F0D] shadow-lg shadow-lime-600/20 hover:bg-[#d6f78a]`,
  outline: `${btnBase} border border-black/15 px-6 py-3.5 hover:border-black/40 hover:bg-black/[0.03]`,
  outlineLight: `${btnBase} border border-white/25 px-6 py-3.5 text-white hover:border-white/50 hover:bg-white/10`,
};

export const inputCls =
  'w-full rounded-xl border border-black/10 bg-[#FBFCF9] px-4 py-3 text-[14px] font-medium outline-none transition placeholder:text-neutral-400 focus:border-[#00C389] focus:ring-4 focus:ring-[#00C389]/15';

export function ArrowIcon() {
  return <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-0.5" />;
}

/* ------------------------------------------------------------------ */
/*  Layout building blocks                                             */
/* ------------------------------------------------------------------ */
export function SectionHeading({
  label,
  title,
  intro,
  align = 'center',
  dark = false,
  className = '',
}: {
  label?: ReactNode;
  title: ReactNode;
  intro?: ReactNode;
  align?: 'center' | 'left';
  dark?: boolean;
  className?: string;
}) {
  const center = align === 'center';
  return (
    <div className={`${center ? 'mx-auto max-w-2xl text-center' : 'max-w-2xl'} ${className}`}>
      {label && (
        <Reveal>
          <span
            className={`inline-flex items-center gap-1.5 rounded-full px-3 py-1.5 text-[12px] font-bold tracking-[0.18em] ${
              dark ? 'border border-white/10 bg-white/[0.08] text-[#C8F169]' : 'bg-[#E6F8F1] text-[#007A55]'
            }`}
          >
            {label}
          </span>
        </Reveal>
      )}
      <Reveal delay={80}>
        <h2 className={`mt-5 font-display text-4xl font-extrabold leading-[1.05] tracking-[-0.02em] sm:text-5xl ${dark ? 'text-white' : ''}`}>{title}</h2>
      </Reveal>
      {intro && (
        <Reveal delay={150}>
          <p className={`mt-4 text-lg leading-relaxed ${dark ? 'text-white/65' : 'text-neutral-600'}`}>{intro}</p>
        </Reveal>
      )}
    </div>
  );
}

export function PageHero({
  label,
  title,
  intro,
  children,
}: {
  label: string;
  title: ReactNode;
  intro?: ReactNode;
  children?: ReactNode;
}) {
  return (
    <section className="relative overflow-hidden bg-[#F3F5EE] pt-[132px] pb-14 sm:pt-[160px] sm:pb-20">
      <div className="dot-grid absolute inset-0 opacity-[0.35] [mask-image:radial-gradient(ellipse_75%_60%_at_50%_0%,black,transparent)]" aria-hidden="true" />
      <div className="absolute -top-20 right-[8%] h-72 w-72 rounded-full bg-[#C8F169]/40 blur-3xl" aria-hidden="true" />
      <div className="relative mx-auto max-w-7xl px-4 sm:px-6">
        <div className="max-w-3xl">
          <Reveal>
            <span className="inline-flex rounded-full border border-black/[0.07] bg-white px-3 py-1.5 text-[12px] font-bold tracking-[0.18em]">{label}</span>
          </Reveal>
          <Reveal delay={80}>
            <h1 className="mt-5 font-display text-[40px] font-extrabold leading-[1.02] tracking-[-0.03em] sm:text-[58px]">{title}</h1>
          </Reveal>
          {intro && (
            <Reveal delay={150}>
              <p className="mt-5 max-w-2xl text-lg leading-relaxed text-neutral-600">{intro}</p>
            </Reveal>
          )}
          {children && (
            <Reveal delay={220}>
              <div className="mt-8 flex flex-wrap gap-3">{children}</div>
            </Reveal>
          )}
        </div>
      </div>
    </section>
  );
}

/** Dark call-to-action band used at the bottom of every page. */
export function CtaBand({
  title = 'Ready to create your first QR code?',
  text = 'Use the free generator — no account needed — or get in touch to talk about dynamic codes for your business.',
}: {
  title?: string;
  text?: string;
}) {
  const { section } = useSiteNav();
  return (
    <section className="py-16 sm:py-24">
      <div className="mx-auto max-w-7xl px-4 sm:px-6">
        <Reveal scale>
          <div className="relative overflow-hidden rounded-[32px] bg-[#0A0F0D] px-6 py-12 text-center text-white shadow-[0_45px_90px_-30px_rgba(10,15,13,0.65)] sm:p-16">
            <div className="dot-grid-light absolute inset-0 opacity-35 [mask-image:radial-gradient(ellipse_60%_70%_at_50%_40%,black,transparent)]" aria-hidden="true" />
            <div className="absolute -top-24 left-1/2 h-[280px] w-[480px] -translate-x-1/2 rounded-full bg-[#00C389]/20 blur-3xl" aria-hidden="true" />
            <div className="relative mx-auto max-w-2xl">
              <h2 className="font-display text-[34px] font-extrabold leading-[1.05] tracking-[-0.025em] sm:text-[48px]">{title}</h2>
              <p className="mx-auto mt-5 max-w-xl text-lg leading-relaxed text-white/65">{text}</p>
              <div className="mt-9 flex flex-col justify-center gap-3 sm:flex-row">
                <button onClick={() => section('generator')} className={`${btn.lime} px-8 py-4 text-[15px]`}>
                  Create a free QR code <ArrowIcon />
                </button>
                <PageLink to="contact" className={`${btn.outlineLight} px-8 py-4 text-[15px]`}>
                  Contact us
                </PageLink>
              </div>
              <p className="mt-5 text-[13px] font-medium text-white/40">Free generator · No sign-up required</p>
            </div>
          </div>
        </Reveal>
      </div>
    </section>
  );
}

/* ------------------------------------------------------------------ */
/*  Form delivery                                                      */
/* ------------------------------------------------------------------ */
export type SubmitResult = 'sent' | 'mailto' | 'unconfigured';

/**
 * Delivers a form submission:
 *  1. POSTs JSON to `site.formEndpoint` if one is configured, otherwise
 *  2. opens the visitor's email app addressed to `site.contactEmail`, otherwise
 *  3. reports that the form is not connected yet.
 */
export async function submitForm(subject: string, fields: Record<string, string>): Promise<SubmitResult> {
  if (site.formEndpoint.trim()) {
    const res = await fetch(site.formEndpoint.trim(), {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Accept: 'application/json' },
      body: JSON.stringify({ _subject: subject, ...fields }),
    });
    if (!res.ok) throw new Error(`Form endpoint responded with ${res.status}`);
    return 'sent';
  }
  if (isFilled(site.contactEmail)) {
    const body = Object.entries(fields)
      .map(([key, value]) => `${key}: ${value}`)
      .join('\n');
    window.location.href = `mailto:${site.contactEmail}?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;
    return 'mailto';
  }
  return 'unconfigured';
}
