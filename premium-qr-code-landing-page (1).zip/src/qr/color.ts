import type { ColorStop, Fill } from './types';

export function normalizeHex(input: string): string | null {
  let h = input.trim().replace(/^#/, '');
  if (/^[0-9a-f]{3}$/i.test(h)) h = h.split('').map((c) => c + c).join('');
  if (!/^[0-9a-f]{6}$/i.test(h)) return null;
  return `#${h.toUpperCase()}`;
}

export function hexToRgb(hex: string): [number, number, number] {
  const n = normalizeHex(hex);
  if (!n) return [0, 0, 0];
  const v = parseInt(n.slice(1), 16);
  return [(v >> 16) & 255, (v >> 8) & 255, v & 255];
}

export function rgbToHex(r: number, g: number, b: number): string {
  const c = (v: number) => Math.max(0, Math.min(255, Math.round(v))).toString(16).padStart(2, '0');
  return `#${c(r)}${c(g)}${c(b)}`.toUpperCase();
}

/** Relative luminance (WCAG). */
export function luminance(hex: string): number {
  const [r, g, b] = hexToRgb(hex).map((v) => {
    const c = v / 255;
    return c <= 0.03928 ? c / 12.92 : Math.pow((c + 0.055) / 1.055, 2.4);
  });
  return 0.2126 * r + 0.7152 * g + 0.0722 * b;
}

export function contrastRatio(a: string, b: string): number {
  const la = luminance(a);
  const lb = luminance(b);
  const [hi, lo] = la > lb ? [la, lb] : [lb, la];
  return (hi + 0.05) / (lo + 0.05);
}

export function mixHex(a: string, b: string, t = 0.5): string {
  const [r1, g1, b1] = hexToRgb(a);
  const [r2, g2, b2] = hexToRgb(b);
  return rgbToHex(r1 + (r2 - r1) * t, g1 + (g2 - g1) * t, b1 + (b2 - b1) * t);
}

export function fillStops(fill: Fill): ColorStop[] {
  if (fill.mode === 'solid') return [{ offset: 0, color: fill.from }];
  if (fill.stops && fill.stops.length >= 2) return fill.stops;
  return [
    { offset: 0, color: fill.from },
    { offset: 1, color: fill.to },
  ];
}

export const fillColors = (fill: Fill): string[] => fillStops(fill).map((s) => s.color);

/** Lowest contrast between any color of the fill and the background. */
export function minContrast(fill: Fill, bg: string): number {
  return Math.min(...fillColors(fill).map((c) => contrastRatio(c, bg)));
}

/** True when the pattern is darker than its background (standard QR polarity). */
export function isDarkOnLight(fill: Fill, bg: string): boolean {
  const colors = fillColors(fill);
  const avg = colors.reduce((sum, c) => sum + luminance(c), 0) / colors.length;
  return avg < luminance(bg);
}

export const idealTextColor = (bg: string): string => (luminance(bg) > 0.45 ? '#0A0F0D' : '#FFFFFF');
