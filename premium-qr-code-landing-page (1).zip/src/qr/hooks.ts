import { useCallback, useEffect, useRef, useState } from 'react';
import { site } from '../config/site';
import { SAMPLE_PAYLOAD, loadImage, renderSvg, renderToCanvas } from './engine';
import { applyPreset, type StylePreset } from './presets';
import type { QrDesign } from './types';
import { verifyDesign, type ScanStatus } from './verify';

/* ---------------- Live scan check ---------------- */
export function useScanCheck(payload: string, design: QrDesign): ScanStatus {
  const [status, setStatus] = useState<ScanStatus>('checking');
  const seq = useRef(0);
  useEffect(() => {
    const id = ++seq.current;
    setStatus('checking');
    const timer = window.setTimeout(() => {
      verifyDesign(payload, design)
        .then((s) => seq.current === id && setStatus(s))
        .catch(() => seq.current === id && setStatus('error'));
    }, 350);
    return () => window.clearTimeout(timer);
  }, [payload, design]);
  return status;
}

export function useMediaQuery(query: string): boolean {
  const [matches, setMatches] = useState(() => (typeof window !== 'undefined' ? window.matchMedia(query).matches : false));
  useEffect(() => {
    const mql = window.matchMedia(query);
    const onChange = () => setMatches(mql.matches);
    onChange();
    mql.addEventListener('change', onChange);
    return () => mql.removeEventListener('change', onChange);
  }, [query]);
  return matches;
}

/* ---------------- Downloads ---------------- */
function triggerDownload(href: string, filename: string, revoke = false) {
  const a = document.createElement('a');
  a.href = href;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  if (revoke) window.setTimeout(() => URL.revokeObjectURL(href), 2000);
}

async function downloadPng(payload: string, design: QrDesign, panelWidth: number, transparent: boolean, filename: string) {
  const canvas = document.createElement('canvas');
  await renderToCanvas(canvas, payload, design, { panelWidth, transparent });
  const blob = await new Promise<Blob | null>((resolve) => canvas.toBlob(resolve, 'image/png'));
  if (!blob) throw new Error('PNG encoding failed');
  triggerDownload(URL.createObjectURL(blob), filename, true);
}

export type DownloadKind = 'png' | 'hires' | 'transparent' | 'svg';
export interface Downloads {
  busy: DownloadKind | null;
  run: (kind: DownloadKind) => void;
}

const DOWNLOAD_LABELS: Record<DownloadKind, string> = { png: 'PNG', hires: 'High-resolution PNG', transparent: 'Transparent PNG', svg: 'SVG' };

export function useQrDownloads(payload: string, design: QrDesign, scan: ScanStatus, toast: (m: string) => void): Downloads {
  const [busy, setBusy] = useState<DownloadKind | null>(null);
  const run = useCallback(
    async (kind: DownloadKind) => {
      if (busy) return;
      setBusy(kind);
      const base = `${site.brand.toLowerCase()}-qr-${design.styleId}`;
      try {
        if (kind === 'png') await downloadPng(payload, design, 1200, false, `${base}.png`);
        else if (kind === 'hires') await downloadPng(payload, design, 3000, false, `${base}-hires.png`);
        else if (kind === 'transparent') await downloadPng(payload, design, 1200, true, `${base}-transparent.png`);
        else triggerDownload(URL.createObjectURL(new Blob([renderSvg(payload, design)], { type: 'image/svg+xml;charset=utf-8' })), `${base}.svg`, true);
        toast(scan === 'fail' ? `${DOWNLOAD_LABELS[kind]} downloaded — note: this design failed the scan test` : `${DOWNLOAD_LABELS[kind]} downloaded`);
      } catch {
        toast('Sorry, the file could not be created. Please try again.');
      } finally {
        setBusy(null);
      }
    },
    [busy, payload, design, scan, toast],
  );
  return { busy, run };
}

/* ---------------- Uploads ---------------- */
const readAsDataUrl = (file: File) =>
  new Promise<string>((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result));
    reader.onerror = () => reject(reader.error);
    reader.readAsDataURL(file);
  });

/** Reads an image file as a data URL, downscaling large bitmaps so exports stay fast. SVG files are kept as vectors. */
export async function fileToDataUrl(file: File, maxSide = 1024): Promise<string> {
  const original = await readAsDataUrl(file);
  if (file.type === 'image/svg+xml') return original;
  const img = await loadImage(original);
  const w = img.naturalWidth || img.width;
  const h = img.naturalHeight || img.height;
  const scale = Math.min(1, maxSide / Math.max(w, h));
  if (scale === 1 && file.size < 700_000) return original;
  const canvas = document.createElement('canvas');
  canvas.width = Math.max(1, Math.round(w * scale));
  canvas.height = Math.max(1, Math.round(h * scale));
  const ctx = canvas.getContext('2d');
  if (!ctx) return original;
  ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
  return canvas.toDataURL(file.type === 'image/jpeg' ? 'image/jpeg' : 'image/png', 0.92);
}

/* ---------------- Style thumbnails ---------------- */
const thumbCache = new Map<string, string>();
const thumbPending = new Map<string, Promise<string>>();

export const peekThumbnail = (id: string): string | null => thumbCache.get(id) ?? null;

export function getThumbnail(preset: StylePreset): Promise<string> {
  const hit = thumbCache.get(preset.id);
  if (hit) return Promise.resolve(hit);
  let pending = thumbPending.get(preset.id);
  if (!pending) {
    pending = (async () => {
      const canvas = document.createElement('canvas');
      await renderToCanvas(canvas, SAMPLE_PAYLOAD, applyPreset(null, preset), { panelWidth: 176 });
      const url = canvas.toDataURL('image/png');
      thumbCache.set(preset.id, url);
      thumbPending.delete(preset.id);
      return url;
    })();
    thumbPending.set(preset.id, pending);
  }
  return pending;
}
