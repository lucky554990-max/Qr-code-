/* ------------------------------------------------------------------ */
/*  Styled QR rendering engine                                         */
/*  - Module data comes from the existing `qrcode` library             */
/*  - One PathBuilder feeds both Canvas (PNG) and SVG, so exports are  */
/*    geometrically identical to the live preview                      */
/* ------------------------------------------------------------------ */
import QRCode from 'qrcode';
import { fillStops, mixHex } from './color';
import type { DotShape, EcLevel, EyeKey, EyeShape, EyeStyle, Fill, QrDesign } from './types';

export const QUIET_ZONE = 4; // modules of clear space around the code (spec minimum)
export const FONT_FAMILY = "Sora, Inter, 'Helvetica Neue', Arial, sans-serif";
export const FONT_WEIGHT = 800;
export const SAMPLE_PAYLOAD = 'https://example.com/scan';
const FINDER = 7;
const GLOW_ALPHA = 0.85;
const LOW_COVERAGE = new Set<DotShape>(['diamond', 'flower', 'pixel', 'bubble', 'mosaic', 'geometric', 'abstract']);

/* ---------------- Matrix ---------------- */
export interface Matrix {
  size: number;
  version: number;
  ec: EcLevel;
  data: Uint8Array;
}

const matrixCache = new Map<string, Matrix>();

/** Encodes the payload with the real QR algorithm and returns its module matrix. */
export function createMatrix(payload: string, ec: EcLevel): Matrix {
  const key = `${ec}\u0000${payload}`;
  const cached = matrixCache.get(key);
  if (cached) return cached;
  const code = QRCode.create(payload, { errorCorrectionLevel: ec });
  const matrix: Matrix = { size: code.modules.size, version: code.version, ec, data: code.modules.data };
  if (matrixCache.size > 60) matrixCache.clear();
  matrixCache.set(key, matrix);
  return matrix;
}

/** Error correction actually used: H with a logo, otherwise the user's choice or a sensible automatic level. */
export function effectiveEc(d: QrDesign): EcLevel {
  if (d.logo) return 'H';
  if (d.ec !== 'auto') return d.ec;
  if (LOW_COVERAGE.has(d.dots) || d.dotScale < 0.8) return 'Q';
  return 'M';
}

/* ---------------- Path builder (Canvas + SVG) ---------------- */
const nf = (v: number): string => {
  const r = Math.round(v * 100) / 100;
  return r === 0 ? '0' : String(r);
};

export class PathBuilder {
  private parts: string[] = [];
  readonly path2d: Path2D | null;

  constructor(withCanvas = false) {
    this.path2d = withCanvas && typeof Path2D !== 'undefined' ? new Path2D() : null;
  }
  get d(): string {
    return this.parts.join('');
  }
  moveTo(x: number, y: number): this {
    this.parts.push(`M${nf(x)} ${nf(y)}`);
    this.path2d?.moveTo(x, y);
    return this;
  }
  lineTo(x: number, y: number): this {
    this.parts.push(`L${nf(x)} ${nf(y)}`);
    this.path2d?.lineTo(x, y);
    return this;
  }
  close(): this {
    this.parts.push('Z');
    this.path2d?.closePath();
    return this;
  }
  /** Arc around (cx, cy) from angle a0 to a1 (radians), taking the shorter direction. The current point must be at the arc start. */
  arc(cx: number, cy: number, r: number, a0: number, a1: number): this {
    let delta = a1 - a0;
    while (delta > Math.PI) delta -= 2 * Math.PI;
    while (delta < -Math.PI) delta += 2 * Math.PI;
    const ex = cx + r * Math.cos(a1);
    const ey = cy + r * Math.sin(a1);
    this.parts.push(`A${nf(r)} ${nf(r)} 0 0 ${delta >= 0 ? 1 : 0} ${nf(ex)} ${nf(ey)}`);
    this.path2d?.arc(cx, cy, r, a0, a1, delta < 0);
    return this;
  }
  rect(x: number, y: number, w: number, h: number): this {
    return this.moveTo(x, y).lineTo(x + w, y).lineTo(x + w, y + h).lineTo(x, y + h).close();
  }
  roundRect(x: number, y: number, w: number, h: number, radius: number | [number, number, number, number]): this {
    const max = Math.min(w, h) / 2;
    const [tl, tr, br, bl] = (typeof radius === 'number' ? [radius, radius, radius, radius] : radius).map((r) => Math.max(0, Math.min(r, max)));
    if (!tl && !tr && !br && !bl) return this.rect(x, y, w, h);
    this.moveTo(x + tl, y);
    this.lineTo(x + w - tr, y);
    if (tr) this.arc(x + w - tr, y + tr, tr, -Math.PI / 2, 0);
    this.lineTo(x + w, y + h - br);
    if (br) this.arc(x + w - br, y + h - br, br, 0, Math.PI / 2);
    this.lineTo(x + bl, y + h);
    if (bl) this.arc(x + bl, y + h - bl, bl, Math.PI / 2, Math.PI);
    this.lineTo(x, y + tl);
    if (tl) this.arc(x + tl, y + tl, tl, Math.PI, Math.PI * 1.5);
    return this.close();
  }
  circle(cx: number, cy: number, r: number): this {
    if (r <= 0) return this;
    return this.moveTo(cx + r, cy).arc(cx, cy, r, 0, Math.PI).arc(cx, cy, r, Math.PI, 2 * Math.PI).close();
  }
  polygon(points: ReadonlyArray<readonly [number, number]>): this {
    points.forEach(([x, y], i) => (i === 0 ? this.moveTo(x, y) : this.lineTo(x, y)));
    return this.close();
  }
  /** Concave fillet filling the corner (px, py) of an empty cell; (sx, sy) point into that cell. */
  fillet(px: number, py: number, r: number, sx: number, sy: number): this {
    const a: [number, number] = [px + sx * r, py];
    const b: [number, number] = [px, py + sy * r];
    const [first, second] = sx * sy > 0 ? [a, b] : [b, a];
    const cx = px + sx * r;
    const cy = py + sy * r;
    this.moveTo(px, py).lineTo(first[0], first[1]);
    this.arc(cx, cy, r, Math.atan2(first[1] - cy, first[0] - cx), Math.atan2(second[1] - cy, second[0] - cx));
    return this.close();
  }
}

/* ---------------- Data modules ---------------- */
export type DarkFn = (x: number, y: number) => boolean;

function hash01(x: number, y: number): number {
  let h = (Math.imul(x, 374761393) + Math.imul(y, 668265263)) | 0;
  h = Math.imul(h ^ (h >>> 13), 1274126177);
  h ^= h >>> 16;
  return (h >>> 0) / 4294967296;
}

export function addModules(pb: PathBuilder, n: number, m: number, ox: number, oy: number, dark: DarkFn, shape: DotShape, scale: number): void {
  const s = Math.max(0.5, Math.min(1, scale));
  for (let y = 0; y < n; y++) {
    for (let x = 0; x < n; x++) {
      const px = ox + x * m;
      const py = oy + y * m;
      if (!dark(x, y)) {
        if (shape === 'liquid') addFillets(pb, x, y, px, py, m, dark);
        continue;
      }
      const cx = px + m / 2;
      const cy = py + m / 2;
      const size = m * s;
      const half = size / 2;
      switch (shape) {
        case 'square':
          pb.rect(cx - half, cy - half, size, size);
          break;
        case 'rounded':
          pb.roundRect(cx - half, cy - half, size, size, size * 0.3);
          break;
        case 'dot':
          pb.circle(cx, cy, half);
          break;
        case 'classy':
          pb.roundRect(cx - half, cy - half, size, size, [half, 0, half, 0]);
          break;
        case 'pixel': {
          const ps = size * 0.78;
          pb.rect(cx - ps / 2, cy - ps / 2, ps, ps);
          break;
        }
        case 'mosaic': {
          const ms = size * (0.7 + 0.3 * hash01(x, y));
          pb.rect(cx - ms / 2, cy - ms / 2, ms, ms);
          break;
        }
        case 'bubble':
          pb.circle(cx, cy, half * (0.72 + 0.28 * hash01(x, y)));
          break;
        case 'diamond': {
          const dd = half * 1.15;
          pb.polygon([
            [cx, cy - dd],
            [cx + dd, cy],
            [cx, cy + dd],
            [cx - dd, cy],
          ]);
          break;
        }
        case 'hexagon': {
          const R = half * 1.12;
          const pts: [number, number][] = [];
          for (let k = 0; k < 6; k++) {
            const a = (k * Math.PI) / 3;
            pts.push([cx + R * Math.cos(a), cy + R * Math.sin(a)]);
          }
          pb.polygon(pts);
          break;
        }
        case 'flower': {
          const pr = half * 0.6;
          const o = half * 0.42;
          pb.circle(cx - o, cy, pr);
          pb.circle(cx + o, cy, pr);
          pb.circle(cx, cy - o, pr);
          pb.circle(cx, cy + o, pr);
          break;
        }
        case 'geometric': {
          const k = (x + y) % 3;
          if (k === 0) {
            const gs = size * 0.92;
            pb.rect(cx - gs / 2, cy - gs / 2, gs, gs);
          } else if (k === 1) {
            pb.circle(cx, cy, half * 0.98);
          } else {
            const dd = half * 1.12;
            pb.polygon([
              [cx, cy - dd],
              [cx + dd, cy],
              [cx, cy + dd],
              [cx - dd, cy],
            ]);
          }
          break;
        }
        case 'abstract': {
          const k = Math.floor(hash01(x, y) * 4);
          if (k === 0) pb.roundRect(cx - half, cy - half, size, size, size * 0.3);
          else if (k === 1) pb.roundRect(cx - half, cy - half, size, size, [half, 0, half, 0]);
          else if (k === 2) pb.roundRect(cx - half, cy - half, size, size, [0, half, 0, half]);
          else pb.circle(cx, cy, half);
          break;
        }
        case 'extra-rounded':
        case 'liquid': {
          const L = dark(x - 1, y);
          const R = dark(x + 1, y);
          const T = dark(x, y - 1);
          const B = dark(x, y + 1);
          const inset = (m - size) / 2;
          const x0 = L ? px : px + inset;
          const x1 = R ? px + m : px + m - inset;
          const y0 = T ? py : py + inset;
          const y1 = B ? py + m : py + m - inset;
          const w = x1 - x0;
          const h = y1 - y0;
          const r = Math.min(w, h) / 2;
          pb.roundRect(x0, y0, w, h, [!L && !T ? r : 0, !R && !T ? r : 0, !R && !B ? r : 0, !L && !B ? r : 0]);
          break;
        }
        case 'wave': {
          const L = dark(x - 1, y);
          const R = dark(x + 1, y);
          const h = size * 0.82;
          const r = h / 2;
          pb.roundRect(px, cy - h / 2, m, h, [L ? 0 : r, R ? 0 : r, R ? 0 : r, L ? 0 : r]);
          break;
        }
        case 'stripe': {
          const T = dark(x, y - 1);
          const B = dark(x, y + 1);
          const w = size * 0.82;
          const r = w / 2;
          pb.roundRect(cx - w / 2, py, w, m, [T ? 0 : r, T ? 0 : r, B ? 0 : r, B ? 0 : r]);
          break;
        }
      }
    }
  }
}

function addFillets(pb: PathBuilder, x: number, y: number, px: number, py: number, m: number, dark: DarkFn): void {
  const r = m * 0.28;
  if (dark(x - 1, y) && dark(x, y - 1) && dark(x - 1, y - 1)) pb.fillet(px, py, r, 1, 1);
  if (dark(x + 1, y) && dark(x, y - 1) && dark(x + 1, y - 1)) pb.fillet(px + m, py, r, -1, 1);
  if (dark(x + 1, y) && dark(x, y + 1) && dark(x + 1, y + 1)) pb.fillet(px + m, py + m, r, -1, -1);
  if (dark(x - 1, y) && dark(x, y + 1) && dark(x - 1, y + 1)) pb.fillet(px, py + m, r, 1, -1);
}

/* ---------------- Finder patterns (eyes) ---------------- */
/** Adds one 7×7 finder pattern (ring + ball). Fill the resulting path with the even-odd rule. */
export function addEye(pb: PathBuilder, key: EyeKey, style: EyeStyle, x: number, y: number, m: number): void {
  const sharp: [boolean, boolean, boolean, boolean] = key === 'tl' ? [true, false, false, false] : key === 'tr' ? [false, true, false, false] : [false, false, false, true];
  const shape = (kind: EyeShape, sx: number, sy: number, size: number) => {
    switch (kind) {
      case 'square':
        pb.rect(sx, sy, size, size);
        break;
      case 'rounded':
        pb.roundRect(sx, sy, size, size, size * 0.28);
        break;
      case 'extra-rounded':
        pb.roundRect(sx, sy, size, size, size * 0.45);
        break;
      case 'circle':
        pb.circle(sx + size / 2, sy + size / 2, size / 2);
        break;
      case 'geometric': {
        const r = size * 0.42;
        pb.roundRect(sx, sy, size, size, sharp.map((s) => (s ? 0 : r)) as [number, number, number, number]);
        break;
      }
    }
  };
  shape(style.frame, x, y, FINDER * m);
  shape(style.frame, x + m, y + m, (FINDER - 2) * m);
  shape(style.ball, x + 2 * m, y + 2 * m, (FINDER - 4) * m);
}

/* ---------------- Layout ---------------- */
export type Measure = (text: string, px: number) => number;
export interface Box {
  x: number;
  y: number;
  w: number;
  h: number;
}
export interface Layout {
  n: number;
  m: number;
  P: number;
  W: number;
  H: number;
  panel: Box;
  panelRadius: number;
  qr: Box;
  card: { box: Box; radius: number } | null;
  badge: { box: Box; radius: number } | null;
  text: { x: number; y: number; size: number; content: string; color: string; width: number; maxWidth: number } | null;
  logo: { box: Box; plate: Box; round: boolean; radius: number } | null;
  version: number;
  ec: EcLevel;
}

export const frameText = (d: QrDesign): string => (d.frame.text.trim() || 'SCAN ME').toUpperCase().slice(0, 28);
export const fontString = (px: number): string => `${FONT_WEIGHT} ${px}px ${FONT_FAMILY}`;

export function computeLayout(matrix: Matrix, d: QrDesign, P: number, measure: Measure): Layout {
  const n = matrix.size;
  const m = P / (n + 2 * QUIET_ZONE);
  const style = d.frame.style;
  const framed = style !== 'none';
  const b = framed ? P * 0.03 : 0;
  const cr = Math.max(0, d.cardRadius) * P;
  const W = P + 2 * b;
  let H = P + 2 * b;
  let panelY = b;
  let card: Layout['card'] = null;
  let badge: Layout['badge'] = null;
  let text: Layout['text'] = null;

  if (framed) {
    const content = frameText(d);
    const maxWidth = P * 0.9;
    const spec = (x: number, y: number, size: number, color: string) => ({ x, y, size, content, color, width: Math.min(measure(content, size), maxWidth), maxWidth });
    if (style === 'label-bottom' || style === 'label-top') {
      const lh = P * 0.15;
      H = P + b + lh;
      if (style === 'label-top') panelY = lh;
      card = { box: { x: 0, y: 0, w: W, h: H }, radius: cr + b };
      text = spec(W / 2, style === 'label-top' ? lh / 2 : b + P + lh / 2, P * 0.062, d.frame.textColor);
    } else if (style === 'badge') {
      const bh = P * 0.115;
      const t = spec(W / 2, P + 2 * b, P * 0.05, d.frame.textColor);
      const bw = Math.min(W - bh, t.width + bh * 1.2);
      H = P + 2 * b + bh / 2;
      card = { box: { x: 0, y: 0, w: W, h: P + 2 * b }, radius: cr + b };
      badge = { box: { x: W / 2 - bw / 2, y: P + 2 * b - bh / 2, w: bw, h: bh }, radius: bh / 2 };
      text = t;
    } else {
      const th = P * 0.13;
      H = P + 2 * b + th;
      card = { box: { x: 0, y: 0, w: W, h: P + 2 * b }, radius: cr + b };
      text = spec(W / 2, P + 2 * b + th / 2, P * 0.056, d.frame.color);
    }
  }

  const panel: Box = { x: b, y: panelY, w: P, h: P };
  const qr: Box = { x: b + QUIET_ZONE * m, y: panelY + QUIET_ZONE * m, w: n * m, h: n * m };
  let logo: Layout['logo'] = null;
  if (d.logo) {
    const size = Math.max(m * 3, Math.min(0.32, d.logoScale) * qr.w);
    const pad = Math.max(m * 0.55, size * 0.1);
    const cx = qr.x + qr.w / 2;
    const cy = qr.y + qr.h / 2;
    const ps = size + 2 * pad;
    logo = {
      box: { x: cx - size / 2, y: cy - size / 2, w: size, h: size },
      plate: { x: cx - ps / 2, y: cy - ps / 2, w: ps, h: ps },
      round: d.logoRound,
      radius: d.logoRound ? ps / 2 : ps * 0.22,
    };
  }
  return { n, m, P, W, H, panel, panelRadius: cr, qr, card, badge, text, logo, version: matrix.version, ec: matrix.ec };
}

/* ---------------- Geometry (shared by both back ends) ---------------- */
export interface Geometry {
  layout: Layout;
  panel: PathBuilder;
  card: PathBuilder | null;
  badge: PathBuilder | null;
  plate: PathBuilder | null;
  data: PathBuilder;
  eyes: PathBuilder;
}

export function buildGeometry(matrix: Matrix, d: QrDesign, P: number, measure: Measure, withCanvas: boolean): Geometry {
  const L = computeLayout(matrix, d, P, measure);
  const { n, m } = L;
  const panel = new PathBuilder(withCanvas).roundRect(L.panel.x, L.panel.y, L.panel.w, L.panel.h, L.panelRadius);
  let card: PathBuilder | null = null;
  if (L.card) {
    card = new PathBuilder(withCanvas);
    card.roundRect(L.card.box.x, L.card.box.y, L.card.box.w, L.card.box.h, L.card.radius);
    card.roundRect(L.panel.x, L.panel.y, L.panel.w, L.panel.h, L.panelRadius); // even-odd hole
  }
  const badge = L.badge ? new PathBuilder(withCanvas).roundRect(L.badge.box.x, L.badge.box.y, L.badge.box.w, L.badge.box.h, L.badge.radius) : null;

  const knockout = L.logo && d.logoKnockout ? L.logo : null;
  let plate: PathBuilder | null = null;
  if (knockout) {
    plate = new PathBuilder(withCanvas);
    if (knockout.round) plate.circle(knockout.plate.x + knockout.plate.w / 2, knockout.plate.y + knockout.plate.h / 2, knockout.plate.w / 2);
    else plate.roundRect(knockout.plate.x, knockout.plate.y, knockout.plate.w, knockout.plate.h, knockout.radius);
  }

  const inFinder = (x: number, y: number) => (x < FINDER && y < FINDER) || (x >= n - FINDER && y < FINDER) || (x < FINDER && y >= n - FINDER);
  const hidden = (x: number, y: number): boolean => {
    if (!knockout) return false;
    const cx = L.qr.x + (x + 0.5) * m;
    const cy = L.qr.y + (y + 0.5) * m;
    const p = knockout.plate;
    const grow = m * 0.15;
    if (knockout.round) {
      const r = p.w / 2;
      return Math.hypot(cx - (p.x + r), cy - (p.y + r)) < r + grow;
    }
    return cx > p.x - grow && cx < p.x + p.w + grow && cy > p.y - grow && cy < p.y + p.h + grow;
  };
  const dark: DarkFn = (x, y) => x >= 0 && y >= 0 && x < n && y < n && matrix.data[y * n + x] === 1 && !inFinder(x, y) && !hidden(x, y);

  const data = new PathBuilder(withCanvas);
  addModules(data, n, m, L.qr.x, L.qr.y, dark, d.dots, d.dots === 'liquid' ? 1 : d.dotScale);

  const eyes = new PathBuilder(withCanvas);
  const eyeStyle = (k: EyeKey): EyeStyle => (d.eyesIndependent ? d.eyes[k] : d.eye);
  addEye(eyes, 'tl', eyeStyle('tl'), L.qr.x, L.qr.y, m);
  addEye(eyes, 'tr', eyeStyle('tr'), L.qr.x + (n - FINDER) * m, L.qr.y, m);
  addEye(eyes, 'bl', eyeStyle('bl'), L.qr.x, L.qr.y + (n - FINDER) * m, m);

  return { layout: L, panel, card, badge, plate, data, eyes };
}

/* ---------------- Paint helpers ---------------- */
const clamp01 = (v: number) => Math.max(0, Math.min(1, v));

function gradientLine(angle: number, box: Box) {
  const a = (angle * Math.PI) / 180;
  const dx = Math.cos(a);
  const dy = Math.sin(a);
  const half = (Math.abs(box.w * dx) + Math.abs(box.h * dy)) / 2;
  const cx = box.x + box.w / 2;
  const cy = box.y + box.h / 2;
  return { x1: cx - dx * half, y1: cy - dy * half, x2: cx + dx * half, y2: cy + dy * half };
}

const SHEEN_STOPS: ReadonlyArray<{ offset: number; color: string; opacity: number }> = [
  { offset: 0, color: '#FFFFFF', opacity: 0.45 },
  { offset: 0.45, color: '#FFFFFF', opacity: 0.12 },
  { offset: 0.5, color: '#FFFFFF', opacity: 0 },
  { offset: 1, color: '#000000', opacity: 0.16 },
];

const glowDeviation = (glow: number, m: number) => clamp01(glow) * m * 0.9;
const glowColor = (d: QrDesign) => {
  const c = fillStops(d.fg);
  return c.length > 1 ? mixHex(c[0].color, c[c.length - 1].color) : c[0].color;
};

function canvasPaint(ctx: CanvasRenderingContext2D, fill: Fill, box: Box): string | CanvasGradient {
  const stops = fillStops(fill);
  if (fill.mode === 'solid' || stops.length < 2) return stops[0].color;
  let g: CanvasGradient;
  if (fill.mode === 'radial') {
    const cx = box.x + box.w / 2;
    const cy = box.y + box.h / 2;
    g = ctx.createRadialGradient(cx, cy, 0, cx, cy, (Math.hypot(box.w, box.h) / 2) * 0.8);
  } else {
    const l = gradientLine(fill.angle, box);
    g = ctx.createLinearGradient(l.x1, l.y1, l.x2, l.y2);
  }
  stops.forEach((s) => g.addColorStop(clamp01(s.offset), s.color));
  return g;
}

function canvasSheen(ctx: CanvasRenderingContext2D, box: Box): CanvasGradient {
  const l = gradientLine(45, box);
  const g = ctx.createLinearGradient(l.x1, l.y1, l.x2, l.y2);
  SHEEN_STOPS.forEach((s) => {
    const v = s.color === '#FFFFFF' ? 255 : 0;
    g.addColorStop(s.offset, `rgba(${v},${v},${v},${s.opacity})`);
  });
  return g;
}

let filterSupport: boolean | null = null;
function canvasFilterSupported(ctx: CanvasRenderingContext2D): boolean {
  if (filterSupport === null) {
    try {
      if (!('filter' in CanvasRenderingContext2D.prototype)) filterSupport = false;
      else {
        ctx.filter = 'blur(2px)';
        filterSupport = ctx.filter === 'blur(2px)';
        ctx.filter = 'none';
      }
    } catch {
      filterSupport = false;
    }
  }
  return filterSupport;
}

/* ---------------- Images ---------------- */
const imageCache = new Map<string, Promise<HTMLImageElement>>();
export function loadImage(src: string): Promise<HTMLImageElement> {
  let p = imageCache.get(src);
  if (!p) {
    p = new Promise((resolve, reject) => {
      const img = new Image();
      img.onload = () => resolve(img);
      img.onerror = () => reject(new Error('Image failed to load'));
      img.src = src;
    });
    if (imageCache.size > 16) imageCache.clear();
    imageCache.set(src, p);
  }
  return p;
}

function drawImageFit(ctx: CanvasRenderingContext2D, img: HTMLImageElement, box: Box, mode: 'cover' | 'contain'): void {
  const iw = img.naturalWidth || img.width;
  const ih = img.naturalHeight || img.height;
  try {
    if (!iw || !ih) {
      ctx.drawImage(img, box.x, box.y, box.w, box.h);
      return;
    }
    const s = mode === 'cover' ? Math.max(box.w / iw, box.h / ih) : Math.min(box.w / iw, box.h / ih);
    const w = iw * s;
    const h = ih * s;
    ctx.drawImage(img, box.x + (box.w - w) / 2, box.y + (box.h - h) / 2, w, h);
  } catch {
    /* an undecodable image should never break the code itself */
  }
}

let measureCtx: CanvasRenderingContext2D | null | undefined;
export function getMeasure(): Measure {
  if (measureCtx === undefined) measureCtx = typeof document !== 'undefined' ? document.createElement('canvas').getContext('2d') : null;
  const ctx = measureCtx;
  if (!ctx) return (text, px) => text.length * px * 0.68;
  return (text, px) => {
    ctx.font = fontString(px);
    return ctx.measureText(text).width;
  };
}

/* ---------------- Canvas renderer ---------------- */
export interface RenderOptions {
  /** Width in pixels of the code panel (code + quiet zone). Frames add to the final size. */
  panelWidth: number;
  transparent?: boolean;
}
export interface RenderInfo {
  width: number;
  height: number;
  modules: number;
  version: number;
  ec: EcLevel;
}

export async function renderToCanvas(canvas: HTMLCanvasElement, payload: string, input: QrDesign, opts: RenderOptions): Promise<RenderInfo> {
  const design = opts.transparent ? { ...input, transparent: true } : input;
  const ec = effectiveEc(design);
  const matrix = createMatrix(payload, ec);
  const ctx = canvas.getContext('2d');
  if (!ctx) throw new Error('Canvas 2D is not supported');
  const measure: Measure = (text, px) => {
    ctx.font = fontString(px);
    return ctx.measureText(text).width;
  };
  const g = buildGeometry(matrix, design, opts.panelWidth, measure, true);
  const [logoImg, bgImg] = await Promise.all([
    design.logo ? loadImage(design.logo).catch(() => null) : Promise.resolve(null),
    design.bgImage && !design.transparent ? loadImage(design.bgImage).catch(() => null) : Promise.resolve(null),
  ]);
  const L = g.layout;
  canvas.width = Math.max(1, Math.round(L.W));
  canvas.height = Math.max(1, Math.round(L.H));
  ctx.clearRect(0, 0, canvas.width, canvas.height);
  ctx.imageSmoothingEnabled = true;
  ctx.imageSmoothingQuality = 'high';
  const p = (b: PathBuilder) => b.path2d as Path2D;

  if (g.card) {
    ctx.fillStyle = design.frame.color;
    ctx.fill(p(g.card), 'evenodd');
  }
  if (!design.transparent) {
    ctx.fillStyle = design.bgColor;
    ctx.fill(p(g.panel));
    if (bgImg) {
      ctx.save();
      ctx.clip(p(g.panel));
      ctx.globalAlpha = clamp01(design.bgImageOpacity);
      drawImageFit(ctx, bgImg, L.panel, 'cover');
      ctx.restore();
    }
  }

  const fgPaint = canvasPaint(ctx, design.fg, L.qr);
  const eyePaint: string | CanvasGradient = design.eyeColor ?? fgPaint;
  const paintModules = () => {
    ctx.fillStyle = fgPaint;
    ctx.fill(p(g.data));
    ctx.fillStyle = eyePaint;
    ctx.fill(p(g.eyes), 'evenodd');
  };
  if (design.glow > 0) {
    const sd = glowDeviation(design.glow, L.m);
    ctx.save();
    ctx.globalAlpha = GLOW_ALPHA;
    if (canvasFilterSupported(ctx)) {
      ctx.filter = `blur(${sd}px)`;
    } else {
      ctx.shadowColor = glowColor(design);
      ctx.shadowBlur = sd * 2;
    }
    paintModules();
    ctx.restore();
  }
  paintModules();
  if (design.glass) {
    ctx.fillStyle = canvasSheen(ctx, L.qr);
    ctx.fill(p(g.data));
    ctx.fill(p(g.eyes), 'evenodd');
  }

  if (g.plate && !design.transparent) {
    ctx.fillStyle = design.bgColor;
    ctx.fill(p(g.plate));
  }
  if (logoImg && L.logo) drawImageFit(ctx, logoImg, L.logo.box, 'contain');

  if (g.badge) {
    ctx.fillStyle = design.frame.color;
    ctx.fill(p(g.badge));
  }
  if (L.text) {
    ctx.fillStyle = L.text.color;
    ctx.font = fontString(L.text.size);
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText(L.text.content, L.text.x, L.text.y, L.text.maxWidth);
  }
  return { width: canvas.width, height: canvas.height, modules: L.n, version: L.version, ec };
}

/* ---------------- SVG renderer ---------------- */
const escXml = (s: string) => s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');

function svgPaint(defs: string[], id: string, fill: Fill, box: Box): string {
  const stops = fillStops(fill);
  if (fill.mode === 'solid' || stops.length < 2) return stops[0].color;
  const stopEls = stops.map((s) => `<stop offset="${nf(clamp01(s.offset) * 100)}%" stop-color="${s.color}"/>`).join('');
  if (fill.mode === 'radial') {
    const cx = box.x + box.w / 2;
    const cy = box.y + box.h / 2;
    defs.push(`<radialGradient id="${id}" gradientUnits="userSpaceOnUse" cx="${nf(cx)}" cy="${nf(cy)}" r="${nf((Math.hypot(box.w, box.h) / 2) * 0.8)}">${stopEls}</radialGradient>`);
  } else {
    const l = gradientLine(fill.angle, box);
    defs.push(`<linearGradient id="${id}" gradientUnits="userSpaceOnUse" x1="${nf(l.x1)}" y1="${nf(l.y1)}" x2="${nf(l.x2)}" y2="${nf(l.y2)}">${stopEls}</linearGradient>`);
  }
  return `url(#${id})`;
}

export function renderSvg(payload: string, input: QrDesign, opts: { transparent?: boolean } = {}): string {
  const design = opts.transparent ? { ...input, transparent: true } : input;
  const matrix = createMatrix(payload, effectiveEc(design));
  const g = buildGeometry(matrix, design, 1000, getMeasure(), false);
  const L = g.layout;
  const uid = Math.random().toString(36).slice(2, 7);
  const defs: string[] = [];
  const body: string[] = [];
  const img = (href: string, box: Box, extra: string) => `<image href="${escXml(href)}" xlink:href="${escXml(href)}" x="${nf(box.x)}" y="${nf(box.y)}" width="${nf(box.w)}" height="${nf(box.h)}" ${extra}/>`;

  if (g.card) body.push(`<path d="${g.card.d}" fill="${design.frame.color}" fill-rule="evenodd"/>`);
  if (!design.transparent) {
    body.push(`<path d="${g.panel.d}" fill="${design.bgColor}"/>`);
    if (design.bgImage) {
      defs.push(`<clipPath id="clip-${uid}"><path d="${g.panel.d}"/></clipPath>`);
      body.push(img(design.bgImage, L.panel, `preserveAspectRatio="xMidYMid slice" clip-path="url(#clip-${uid})" opacity="${nf(clamp01(design.bgImageOpacity))}"`));
    }
  }

  const fgPaint = svgPaint(defs, `fg-${uid}`, design.fg, L.qr);
  const eyePaint = design.eyeColor ?? fgPaint;
  const modules = `<path d="${g.data.d}" fill="${fgPaint}"/><path d="${g.eyes.d}" fill="${eyePaint}" fill-rule="evenodd"/>`;
  if (design.glow > 0) {
    defs.push(`<filter id="glow-${uid}" x="-15%" y="-15%" width="130%" height="130%"><feGaussianBlur stdDeviation="${nf(glowDeviation(design.glow, L.m))}"/></filter>`);
    body.push(`<g filter="url(#glow-${uid})" opacity="${GLOW_ALPHA}">${modules}</g>`);
  }
  body.push(modules);
  if (design.glass) {
    const l = gradientLine(45, L.qr);
    defs.push(
      `<linearGradient id="sheen-${uid}" gradientUnits="userSpaceOnUse" x1="${nf(l.x1)}" y1="${nf(l.y1)}" x2="${nf(l.x2)}" y2="${nf(l.y2)}">${SHEEN_STOPS.map(
        (s) => `<stop offset="${nf(s.offset * 100)}%" stop-color="${s.color}" stop-opacity="${s.opacity}"/>`,
      ).join('')}</linearGradient>`,
    );
    body.push(`<path d="${g.data.d}" fill="url(#sheen-${uid})"/><path d="${g.eyes.d}" fill="url(#sheen-${uid})" fill-rule="evenodd"/>`);
  }
  if (g.plate && !design.transparent) body.push(`<path d="${g.plate.d}" fill="${design.bgColor}"/>`);
  if (design.logo && L.logo) body.push(img(design.logo, L.logo.box, 'preserveAspectRatio="xMidYMid meet"'));
  if (g.badge) body.push(`<path d="${g.badge.d}" fill="${design.frame.color}"/>`);
  if (L.text) {
    body.push(
      `<text x="${nf(L.text.x)}" y="${nf(L.text.y)}" font-family="${FONT_FAMILY}" font-weight="${FONT_WEIGHT}" font-size="${nf(L.text.size)}" text-anchor="middle" dominant-baseline="central" textLength="${nf(
        L.text.width,
      )}" lengthAdjust="spacingAndGlyphs" fill="${L.text.color}">${escXml(L.text.content)}</text>`,
    );
  }
  return `<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 ${nf(L.W)} ${nf(L.H)}" width="${nf(L.W)}" height="${nf(L.H)}">${defs.length ? `<defs>${defs.join('')}</defs>` : ''}${body.join('')}</svg>`;
}

/* ---------------- Small SVG glyphs for the option pickers ---------------- */
const GLYPH_PATTERN = ['11010', '10111', '01101', '11010', '01111'];

export function dotGlyphSvg(shape: DotShape): string {
  const n = 5;
  const dark: DarkFn = (x, y) => x >= 0 && y >= 0 && x < n && y < n && GLYPH_PATTERN[y][x] === '1';
  const pb = new PathBuilder(false);
  addModules(pb, n, 10, 0, 0, dark, shape, shape === 'liquid' ? 1 : 0.95);
  return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="-3 -3 56 56" width="100%" height="100%" aria-hidden="true"><path d="${pb.d}" fill="currentColor"/></svg>`;
}

export function eyeGlyphSvg(frame: EyeShape, ball: EyeShape): string {
  const pb = new PathBuilder(false);
  addEye(pb, 'tl', { frame, ball }, 0, 0, 10);
  return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="-4 -4 78 78" width="100%" height="100%" aria-hidden="true"><path d="${pb.d}" fill="currentColor" fill-rule="evenodd"/></svg>`;
}

/* ---------------- Camera-like softening for scan tests ---------------- */
/** In-place separable box blur (3 passes ≈ Gaussian) on RGBA pixels. Emulates lens/sensor blur so sharp 1px gaps are judged like a camera sees them. */
export function softenRgba(px: Uint8ClampedArray, w: number, h: number, radius: number): void {
  const r = Math.max(0, Math.round(radius));
  if (!r) return;
  const tmp = new Float32Array(w * h * 3);
  const src = new Float32Array(w * h * 3);
  for (let i = 0; i < w * h; i++) {
    src[i * 3] = px[i * 4];
    src[i * 3 + 1] = px[i * 4 + 1];
    src[i * 3 + 2] = px[i * 4 + 2];
  }
  const pass = (from: Float32Array, to: Float32Array, horizontal: boolean) => {
    const len = horizontal ? w : h;
    const lines = horizontal ? h : w;
    const norm = 1 / (2 * r + 1);
    for (let line = 0; line < lines; line++) {
      const idx = (i: number) => (horizontal ? line * w + i : i * w + line) * 3;
      for (let c = 0; c < 3; c++) {
        let acc = 0;
        for (let i = -r; i <= r; i++) acc += from[idx(Math.min(len - 1, Math.max(0, i))) + c];
        for (let i = 0; i < len; i++) {
          to[idx(i) + c] = acc * norm;
          acc += from[idx(Math.min(len - 1, i + r + 1)) + c] - from[idx(Math.max(0, i - r)) + c];
        }
      }
    }
  };
  for (let k = 0; k < 3; k++) {
    pass(src, tmp, true);
    pass(tmp, src, false);
  }
  for (let i = 0; i < w * h; i++) {
    px[i * 4] = src[i * 3];
    px[i * 4 + 1] = src[i * 3 + 1];
    px[i * 4 + 2] = src[i * 3 + 2];
  }
}
