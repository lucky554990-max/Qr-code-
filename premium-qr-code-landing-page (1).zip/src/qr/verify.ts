import jsQR from 'jsqr';
import { QUIET_ZONE, createMatrix, effectiveEc, renderToCanvas, softenRgba } from './engine';
import type { QrDesign } from './types';

export type ScanStatus = 'checking' | 'ok' | 'inverted' | 'fail' | 'error';

const PX_PER_MODULE = 10;
/** Blur radii (in modules) tried in turn — 0 = pixel-sharp, others emulate camera optics. */
const SOFTEN_LEVELS = [0, 0.2, 0.3];

/**
 * Renders the design exactly as exported, places it on a white surface and decodes it
 * with a real QR decoder. Returns:
 *  - 'ok'       decoded with standard polarity and the data matches
 *  - 'inverted' decodes only as a light-on-dark code (modern phones read these, some scanners do not)
 *  - 'fail'     could not be decoded
 */
export async function verifyDesign(payload: string, design: QrDesign): Promise<ScanStatus> {
  const modules = createMatrix(payload, effectiveEc(design)).size; // throws when the content is too long
  const canvas = document.createElement('canvas');
  await renderToCanvas(canvas, payload, design, { panelWidth: (modules + 2 * QUIET_ZONE) * PX_PER_MODULE });

  const flat = document.createElement('canvas');
  flat.width = canvas.width;
  flat.height = canvas.height;
  const ctx = flat.getContext('2d', { willReadFrequently: true });
  if (!ctx) return 'error';
  ctx.fillStyle = '#FFFFFF';
  ctx.fillRect(0, 0, flat.width, flat.height);
  ctx.drawImage(canvas, 0, 0);
  const { data, width, height } = ctx.getImageData(0, 0, flat.width, flat.height);

  let inverted = false;
  for (const level of SOFTEN_LEVELS) {
    const px = level ? new Uint8ClampedArray(data) : data;
    if (level) softenRgba(px, width, height, PX_PER_MODULE * level);
    if (jsQR(px, width, height, { inversionAttempts: 'dontInvert' })?.data === payload) return 'ok';
    if (!inverted && jsQR(px, width, height, { inversionAttempts: 'attemptBoth' })?.data === payload) inverted = true;
  }
  return inverted ? 'inverted' : 'fail';
}
