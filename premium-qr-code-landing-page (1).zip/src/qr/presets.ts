import type { EyeShape, EyeStyle, Fill, FrameOptions, FrameStyle, QrDesign } from './types';

export type StyleCategory = 'modern' | 'creative' | 'premium';

export interface StylePreset {
  id: string;
  name: string;
  category: StyleCategory;
  blurb: string;
  design: Partial<QrDesign>;
}

export const CATEGORY_LABELS: Record<StyleCategory, string> = { modern: 'Modern', creative: 'Creative', premium: 'Premium' };

const solid = (c: string): Fill => ({ mode: 'solid', from: c, to: c, angle: 45 });
const linear = (from: string, to: string, angle = 45): Fill => ({ mode: 'linear', from, to, angle });
const radial = (from: string, to: string): Fill => ({ mode: 'radial', from, to, angle: 45 });
const multi = (angle: number, colors: [number, string][]): Fill => ({
  mode: 'linear',
  from: colors[0][1],
  to: colors[colors.length - 1][1],
  angle,
  stops: colors.map(([offset, color]) => ({ offset, color })),
});
const eye = (frame: EyeShape, ball: EyeShape = frame): EyeStyle => ({ frame, ball });
const frame = (style: FrameStyle, text: string, color: string, textColor: string): FrameOptions => ({ style, text, color, textColor });

export const BASE_DESIGN: QrDesign = {
  styleId: 'classic',
  dots: 'square',
  dotScale: 1,
  eye: eye('square'),
  eyesIndependent: false,
  eyes: { tl: eye('square'), tr: eye('square'), bl: eye('square') },
  eyeColor: null,
  fg: solid('#0A0F0D'),
  bgColor: '#FFFFFF',
  transparent: false,
  bgImage: null,
  bgImageOpacity: 0.25,
  glow: 0,
  glass: false,
  logo: null,
  logoScale: 0.22,
  logoKnockout: true,
  logoRound: false,
  frame: frame('none', 'SCAN ME', '#0A0F0D', '#FFFFFF'),
  cardRadius: 0.06,
  ec: 'auto',
};

export const STYLE_PRESETS: StylePreset[] = [
  /* ---------- Modern ---------- */
  { id: 'classic', name: 'Classic Square', category: 'modern', blurb: 'The original look. Maximum compatibility.', design: { dots: 'square', eye: eye('square'), fg: solid('#0A0F0D'), cardRadius: 0.04 } },
  { id: 'rounded-dot', name: 'Rounded Dot', category: 'modern', blurb: 'Friendly circular modules with soft eyes.', design: { dots: 'dot', dotScale: 0.92, eye: eye('rounded'), fg: solid('#111827') } },
  { id: 'rounded-square', name: 'Rounded Square', category: 'modern', blurb: 'Softened corners, classic structure.', design: { dots: 'rounded', dotScale: 0.95, eye: eye('rounded'), fg: solid('#0F172A') } },
  { id: 'circle-dot', name: 'Circle Dot', category: 'modern', blurb: 'Dots with fully circular eyes.', design: { dots: 'dot', dotScale: 0.88, eye: eye('circle'), fg: solid('#1E1B4B') } },
  { id: 'soft-rounded', name: 'Soft Rounded', category: 'modern', blurb: 'Connected pills with a smooth flow.', design: { dots: 'extra-rounded', eye: eye('extra-rounded'), fg: solid('#134E4A') } },
  { id: 'minimalist', name: 'Minimalist', category: 'modern', blurb: 'Light, airy and understated.', design: { dots: 'square', dotScale: 0.8, eye: eye('square', 'rounded'), fg: solid('#27272A'), bgColor: '#FAFAFA', cardRadius: 0 } },
  { id: 'pixel-art', name: 'Pixel Art', category: 'modern', blurb: 'Retro 8-bit texture.', design: { dots: 'pixel', eye: eye('square'), fg: solid('#3730A3'), bgColor: '#EEF2FF' } },
  { id: 'diamond', name: 'Diamond Pattern', category: 'modern', blurb: 'Faceted, jewel-like modules.', design: { dots: 'diamond', eye: eye('rounded'), fg: solid('#7F1D1D'), bgColor: '#FFF7F7' } },
  { id: 'gradient', name: 'Gradient', category: 'modern', blurb: 'Two-tone linear blend.', design: { dots: 'rounded', dotScale: 0.95, eye: eye('rounded'), fg: linear('#047857', '#1D4ED8', 45) } },
  { id: 'futuristic', name: 'Futuristic', category: 'modern', blurb: 'Hex cells with a cool glow.', design: { dots: 'hexagon', dotScale: 0.95, eye: eye('geometric'), fg: linear('#0F172A', '#0E7490', 135), glow: 0.25 } },
  { id: 'leaf', name: 'Leaf', category: 'modern', blurb: 'Classy leaf-shaped modules.', design: { dots: 'classy', dotScale: 0.96, eye: eye('geometric'), fg: solid('#14532D') } },

  /* ---------- Creative ---------- */
  { id: 'circular', name: 'Circular Pattern', category: 'creative', blurb: 'Radial gradient with round eyes.', design: { dots: 'dot', dotScale: 0.9, eye: eye('circle'), fg: radial('#1D4ED8', '#0F172A') } },
  { id: 'flower-dot', name: 'Flower Dot', category: 'creative', blurb: 'Four-petal blossoms.', design: { dots: 'flower', eye: eye('extra-rounded', 'circle'), fg: linear('#9D174D', '#6D28D9', 90), bgColor: '#FDF2F8' } },
  { id: 'liquid-dot', name: 'Liquid Dot', category: 'creative', blurb: 'Merged, fluid blobs.', design: { dots: 'liquid', eye: eye('extra-rounded'), fg: solid('#1E40AF') } },
  { id: 'bubble', name: 'Bubble', category: 'creative', blurb: 'Playful circles of varying size.', design: { dots: 'bubble', eye: eye('circle'), fg: solid('#0F766E'), bgColor: '#F0FDFA' } },
  { id: 'mosaic', name: 'Mosaic', category: 'creative', blurb: 'Tiles of varying size.', design: { dots: 'mosaic', eye: eye('square'), fg: linear('#9A3412', '#7C2D12', 45), bgColor: '#FFF7ED' } },
  { id: 'geometric', name: 'Geometric', category: 'creative', blurb: 'Squares, circles and diamonds.', design: { dots: 'geometric', eye: eye('geometric', 'square'), fg: solid('#1C1917') } },
  { id: 'wave', name: 'Wave Pattern', category: 'creative', blurb: 'Horizontal flowing strands.', design: { dots: 'wave', eye: eye('rounded'), fg: linear('#0C4A6E', '#0369A1', 0) } },
  { id: 'hexagon', name: 'Hexagon-Inspired', category: 'creative', blurb: 'Honeycomb modules.', design: { dots: 'hexagon', dotScale: 0.92, eye: eye('rounded', 'circle'), fg: solid('#713F12'), bgColor: '#FFFBEB' } },
  {
    id: 'abstract',
    name: 'Abstract',
    category: 'creative',
    blurb: 'Mixed shapes and three different eyes.',
    design: { dots: 'abstract', eyesIndependent: true, eyes: { tl: eye('rounded'), tr: eye('circle'), bl: eye('geometric') }, fg: linear('#4C1D95', '#1E3A8A', 90) },
  },
  { id: 'artistic', name: 'Premium Artistic', category: 'creative', blurb: 'Leaf modules with a glossy gradient.', design: { dots: 'classy', dotScale: 0.96, eye: eye('geometric'), fg: linear('#6D28D9', '#BE185D', 135), glass: true } },
  { id: 'stripe', name: 'Vertical Stripe', category: 'creative', blurb: 'Vertical flowing lines.', design: { dots: 'stripe', eye: eye('rounded'), fg: solid('#312E81') } },

  /* ---------- Premium ---------- */
  { id: 'glass', name: 'Glass Effect', category: 'premium', blurb: 'Frosted highlights on slate.', design: { dots: 'rounded', dotScale: 0.94, glass: true, fg: linear('#0F172A', '#334155', 135), eye: eye('rounded'), bgColor: '#F1F5F9', cardRadius: 0.08 } },
  { id: 'neon', name: 'Neon', category: 'premium', blurb: 'Glowing cyan on near-black (inverted).', design: { dots: 'rounded', dotScale: 0.9, fg: solid('#22D3EE'), bgColor: '#050816', glow: 0.5, eye: eye('extra-rounded', 'circle'), cardRadius: 0.08 } },
  {
    id: 'metallic',
    name: 'Metallic',
    category: 'premium',
    blurb: 'Brushed steel sheen.',
    design: {
      dots: 'rounded',
      dotScale: 0.96,
      fg: multi(135, [
        [0, '#0F0F10'],
        [0.3, '#4B4F55'],
        [0.5, '#1C1E22'],
        [0.75, '#5A5F66'],
        [1, '#0F0F10'],
      ]),
      glass: true,
      eye: eye('rounded'),
      bgColor: '#F4F4F5',
    },
  },
  {
    id: 'gold',
    name: 'Luxury Gold',
    category: 'premium',
    blurb: 'Rich gold on ivory with a fine border.',
    design: {
      dots: 'classy',
      dotScale: 0.96,
      fg: multi(45, [
        [0, '#4A3306'],
        [0.35, '#8A6508'],
        [0.55, '#5A3E08'],
        [0.8, '#8F6B06'],
        [1, '#4A3306'],
      ]),
      eye: eye('geometric'),
      bgColor: '#FFFBF0',
      frame: frame('outline', 'SCAN ME', '#9A7209', '#6B4A0A'),
      cardRadius: 0.05,
    },
  },
  { id: 'cyberpunk', name: 'Cyberpunk', category: 'premium', blurb: 'Magenta-to-cyan on deep black (inverted).', design: { dots: 'square', dotScale: 0.88, fg: linear('#FF2BD6', '#00F0FF', 135), bgColor: '#0B0014', glow: 0.4, eye: eye('geometric', 'square'), cardRadius: 0.03 } },
  { id: 'gradient-glow', name: 'Gradient Glow', category: 'premium', blurb: 'Warm gradient with a soft halo.', design: { dots: 'rounded', dotScale: 0.92, fg: linear('#BE123C', '#7E22CE', 45), glow: 0.45, eye: eye('rounded', 'circle') } },
  { id: 'business', name: 'Professional Business', category: 'premium', blurb: 'Navy with a clean "Scan me" label.', design: { dots: 'square', dotScale: 0.94, fg: solid('#1E3A8A'), eye: eye('rounded', 'square'), frame: frame('label-bottom', 'SCAN ME', '#1E3A8A', '#FFFFFF'), cardRadius: 0.08 } },
  { id: 'minimal-premium', name: 'Minimal Premium', category: 'premium', blurb: 'Fine dots with generous space.', design: { dots: 'dot', dotScale: 0.74, eye: eye('circle'), fg: solid('#18181B'), bgColor: '#FAFAFA', cardRadius: 0.12 } },
  { id: 'ink-blot', name: 'Ink Blot', category: 'premium', blurb: 'Liquid black with a bright badge.', design: { dots: 'liquid', eye: eye('extra-rounded'), fg: solid('#0A0F0D'), frame: frame('badge', 'SCAN HERE', '#0A0F0D', '#C8F169'), cardRadius: 0.08 } },
];

/** Styles shown in the quick strip on the generator card. */
export const FEATURED_STYLE_IDS = ['classic', 'rounded-dot', 'gradient', 'liquid-dot', 'glass', 'business'];

export const findPreset = (id: string): StylePreset => STYLE_PRESETS.find((p) => p.id === id) ?? STYLE_PRESETS[0];

/** Applies a preset. Uploaded logo and background image are kept; everything visual comes from the preset. */
export function applyPreset(current: QrDesign | null, preset: StylePreset): QrDesign {
  const next: QrDesign = { ...BASE_DESIGN, ...preset.design, styleId: preset.id };
  if (current) {
    next.logo = current.logo;
    next.logoScale = current.logoScale;
    next.logoKnockout = current.logoKnockout;
    next.logoRound = current.logoRound;
    next.bgImage = current.bgImage;
    next.bgImageOpacity = current.bgImageOpacity;
  }
  return next;
}
