/* ------------------------------------------------------------------ */
/*  QR design model — every option here is rendered by src/qr/engine  */
/* ------------------------------------------------------------------ */

export type DotShape =
  | 'square'
  | 'rounded'
  | 'dot'
  | 'extra-rounded'
  | 'classy'
  | 'liquid'
  | 'diamond'
  | 'hexagon'
  | 'flower'
  | 'pixel'
  | 'mosaic'
  | 'bubble'
  | 'wave'
  | 'stripe'
  | 'geometric'
  | 'abstract';

export const DOT_SHAPES: ReadonlyArray<{ value: DotShape; label: string }> = [
  { value: 'square', label: 'Square' },
  { value: 'rounded', label: 'Rounded' },
  { value: 'dot', label: 'Dot' },
  { value: 'extra-rounded', label: 'Extra rounded' },
  { value: 'classy', label: 'Classy' },
  { value: 'liquid', label: 'Liquid' },
  { value: 'diamond', label: 'Diamond' },
  { value: 'hexagon', label: 'Hexagon' },
  { value: 'flower', label: 'Flower' },
  { value: 'pixel', label: 'Pixel' },
  { value: 'mosaic', label: 'Mosaic' },
  { value: 'bubble', label: 'Bubble' },
  { value: 'wave', label: 'Wave' },
  { value: 'stripe', label: 'Stripe' },
  { value: 'geometric', label: 'Geometric' },
  { value: 'abstract', label: 'Abstract' },
];

export type EyeShape = 'square' | 'rounded' | 'circle' | 'extra-rounded' | 'geometric';

export const EYE_SHAPES: ReadonlyArray<{ value: EyeShape; label: string }> = [
  { value: 'square', label: 'Square' },
  { value: 'rounded', label: 'Rounded' },
  { value: 'circle', label: 'Circle' },
  { value: 'extra-rounded', label: 'Extra rounded' },
  { value: 'geometric', label: 'Geometric' },
];

export type EyeKey = 'tl' | 'tr' | 'bl';
export const EYE_LABELS: Record<EyeKey, string> = { tl: 'Top left eye', tr: 'Top right eye', bl: 'Bottom left eye' };

export interface EyeStyle {
  frame: EyeShape;
  ball: EyeShape;
}

export type FillMode = 'solid' | 'linear' | 'radial';
export interface ColorStop {
  offset: number;
  color: string;
}
export interface Fill {
  mode: FillMode;
  from: string;
  to: string;
  /** Linear gradient direction in degrees: 0 = left→right, 90 = top→bottom. */
  angle: number;
  /** Optional multi-stop gradient (used by metallic styles). Overrides from/to. */
  stops?: ColorStop[];
}

export type FrameStyle = 'none' | 'label-bottom' | 'label-top' | 'badge' | 'outline';
export const FRAME_STYLES: ReadonlyArray<{ value: FrameStyle; label: string }> = [
  { value: 'none', label: 'None' },
  { value: 'label-bottom', label: 'Label below' },
  { value: 'label-top', label: 'Label above' },
  { value: 'badge', label: 'Badge' },
  { value: 'outline', label: 'Outline' },
];
export const FRAME_TEXTS = ['SCAN ME', 'SCAN HERE', 'OPEN WEBSITE', 'FOLLOW US', 'CONTACT US'] as const;

export interface FrameOptions {
  style: FrameStyle;
  text: string;
  color: string;
  textColor: string;
}

export type EcLevel = 'L' | 'M' | 'Q' | 'H';

export interface QrDesign {
  /** Id of the style preset this design is based on. */
  styleId: string;
  dots: DotShape;
  /** Module size relative to the grid cell (0.65–1). */
  dotScale: number;
  /** Eye style applied to all three finder patterns. */
  eye: EyeStyle;
  /** When true, `eyes` is used instead of `eye`. */
  eyesIndependent: boolean;
  eyes: Record<EyeKey, EyeStyle>;
  /** Optional solid color override for the eyes. */
  eyeColor: string | null;
  fg: Fill;
  bgColor: string;
  transparent: boolean;
  bgImage: string | null;
  bgImageOpacity: number;
  /** Glow strength 0–1. */
  glow: number;
  glass: boolean;
  logo: string | null;
  /** Logo width relative to the code width (0.14–0.3). */
  logoScale: number;
  logoKnockout: boolean;
  logoRound: boolean;
  frame: FrameOptions;
  /** Corner radius of the code panel, relative to its width (0–0.15). */
  cardRadius: number;
  ec: 'auto' | EcLevel;
}
